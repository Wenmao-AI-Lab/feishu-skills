"""
PDF 生成器 — 渲染 HTML 并用 Chrome 合并为单个 PDF（含附件独立页）
"""

import os
import base64
import shutil
import subprocess
import json
import platform
from datetime import datetime, timezone, timedelta
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from config import TEMPLATE_DIR, OUTPUT_DIR

# --- 自动检测 Node.js / Puppeteer / Chrome 路径（跨平台兼容） ---

_NODE_BIN = None
_CHROME_PATH = None


def _find_node_bin() -> str | None:
    """自动检测 Node.js 路径，返回 None 表示未找到"""
    import shutil as _shutil
    # 1. 优先用 which（PATH 环境变量）
    found = _shutil.which("node")
    if found:
        return found
    # 2. 常见安装路径
    candidates = [
        # Homebrew (macOS)
        "/opt/homebrew/bin/node",
        "/usr/local/bin/node",
        # nvm
        os.path.expanduser("~/.nvm/versions/node") + "/*/bin/node",
        # fnm
        os.path.expanduser("~/Library/Application Support/fnm/node-versions") + "/*/installation/bin/node",
        # Linux
        "/usr/bin/node",
        # Windows
        os.path.expandvars(r"%ProgramFiles%\nodejs\node.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\nodejs\node.exe"),
    ]
    for c in candidates:
        if "*" in c:
            matches = sorted(Path(os.path.dirname(c)).glob(os.path.basename(c)), reverse=True)
            if matches:
                return str(matches[0])
        elif os.path.isfile(c):
            return c
    return None


def _find_chrome_path() -> str | None:
    """自动检测 Chrome/Chromium 路径，返回 None 表示未找到"""
    import shutil as _shutil
    system = platform.system()
    candidates = []
    if system == "Darwin":
        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]
    elif system == "Linux":
        candidates = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
            "/snap/bin/chromium",
        ]
    elif system == "Windows":
        candidates = [
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    # 最后尝试 which
    found = _shutil.which("google-chrome") or _shutil.which("chromium-browser") or _shutil.which("chromium")
    return found


def _detect_puppeteer_node_path() -> str | None:
    """自动检测 puppeteer 所在 node_modules 路径"""
    search_paths = [
        os.path.expanduser("~/.AI助手/binaries/node/workspace/node_modules"),
        os.path.expanduser("./node_modules"),
        os.path.join(os.path.dirname(_find_node_bin() or ""), "../lib/node_modules"),
        "/usr/local/lib/node_modules",
        "/usr/lib/node_modules",
    ]
    # 也尝试 npm root -g
    try:
        result = subprocess.run(
            ["npm", "root", "-g"], capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            search_paths.insert(0, result.stdout.strip())
    except Exception:
        pass
    for np in search_paths:
        if np and os.path.isdir(os.path.join(np, "puppeteer")):
            return np
    return None


def _get_node_bin() -> str:
    """懒加载获取 Node.js 路径"""
    global _NODE_BIN
    if _NODE_BIN is None:
        _NODE_BIN = _find_node_bin()
        if _NODE_BIN is None:
            raise RuntimeError("未找到 Node.js，请安装 Node.js 22+ 并确保 node 命令在 PATH 中")
    return _NODE_BIN


def _get_chrome_path() -> str:
    """懒加载获取 Chrome 路径"""
    global _CHROME_PATH
    if _CHROME_PATH is None:
        _CHROME_PATH = _find_chrome_path()
        if _CHROME_PATH is None:
            raise RuntimeError("未找到 Chrome 浏览器，请安装 Google Chrome 或 Chromium")
    return _CHROME_PATH


# Jinja2 环境
_jinja_env = Environment(
    loader=FileSystemLoader(str(TEMPLATE_DIR)),
    autoescape=False,
)

# 加载时区
TZ_CST = timezone(timedelta(hours=8))


def _format_ts(ts, fmt: str = "%Y-%m-%d %H:%M") -> str:
    """格式化时间戳为可读字符串，兼容毫秒时间戳"""
    if not ts:
        return ""
    try:
        ts_int = int(ts)
        # 毫秒时间戳 (> 999999999999)
        if ts_int > 999999999999:
            ts_int = ts_int // 1000
        dt = datetime.fromtimestamp(ts_int, tz=TZ_CST)
        return dt.strftime(fmt)
    except (ValueError, TypeError, OSError):
        return str(ts)


def _match_template(approval_name: str) -> str:
    """根据审批名称匹配最适合的模板"""
    from difflib import SequenceMatcher

    if not TEMPLATE_DIR.exists():
        return "default_template.html"

    templates = [f for f in os.listdir(TEMPLATE_DIR) if f.endswith(".html")]
    if not templates:
        return "default_template.html"

    for t in templates:
        if approval_name.replace(" ", "") in t.replace("_template.html", "").replace(".html", ""):
            return t

    best_match, best_score = None, 0
    for t in templates:
        t_name = t.replace("_template.html", "").replace(".html", "")
        score = SequenceMatcher(None, approval_name, t_name).ratio()
        if score > best_score:
            best_score = score
            best_match = t

    if best_match and best_score > 0.3:
        return best_match
    return "default_template.html"


def _render_main_html(instance: dict) -> str:
    """渲染审批单主HTML（不包含附件图）"""
    approval_name = instance.get("definition_name", "") or instance.get("approval_name", "")
    template_file = _match_template(approval_name)

    template = _jinja_env.get_template(template_file)
    all_attachments = instance.get("attachments", [])
    # 分离评论附件
    comment_attachments = [a for a in all_attachments if a.get("field_name", "").startswith("评论:")]
    # 统计打款图片数量
    payment_img_count = sum(1 for a in all_attachments if a.get("field_name") == "打款图片")
    return template.render(
        title=approval_name,
        print_time=datetime.now(TZ_CST).strftime("%Y-%m-%d %H:%M:%S"),
        fields=instance.get("fields", {}),
        form=instance.get("form", []),
        initiator=instance.get("initiator_name", ""),
        department=instance.get("department_name", ""),
        status=instance.get("status_label", ""),
        start_time=_format_ts(instance.get("start_time")),
        end_time=_format_ts(instance.get("end_time")),
        instance_code=instance.get("instance_code", ""),
        serial_no=instance.get("serial_no", ""),
        comment_list=instance.get("comment_list", []),
        timeline=instance.get("timeline", []),
        attachments=all_attachments,
        comment_attachments=comment_attachments,
        payment_img_count=payment_img_count,
    )


def _render_attachment_html(att: dict, index: int) -> str:
    """为单个图片附件生成独立的 HTML 页面"""
    title = att.get("field_name", "附件")
    filename = att.get("filename", "")
    b64 = att.get("base64", "")
    mime = att.get("mime", "image/jpeg")
    size_kb = att.get("size", 0) / 1024

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  @page {{ size: A4; margin: 1.5cm; }}
  body {{ font-family: "PingFang SC", "Microsoft YaHei", "SimHei", sans-serif;
         margin: 0; padding: 0; }}
  .header {{ text-align: center; border-bottom: 2px solid #000;
             padding-bottom: 8px; margin-bottom: 16px; }}
  .header h1 {{ font-size: 18px; margin: 0 0 4px 0; }}
  .header .meta {{ font-size: 12px; color: #555; }}
  .image-wrap {{ text-align: center; padding: 10px; }}
  .image-wrap img {{ max-width: 100%; max-height: 24cm;
                     border: 1px solid #ddd; }}
  .footer {{ position: fixed; bottom: 0.5cm; left: 0; right: 0;
             text-align: center; font-size: 11px; color: #999; }}
</style>
</head>
<body>
  <div class="header">
    <h1>附件 {index} — {title}</h1>
    <div class="meta">文件名：{filename}（{size_kb:.1f} KB）</div>
  </div>
  <div class="image-wrap">
    <img src="{b64}" alt="{filename}" />
  </div>
  <div class="footer">附件 {index}</div>
</body>
</html>"""


def _render_pdf_attachment_html(att: dict, index: int) -> str:
    """为 PDF 附件生成嵌入页面（用 iframe/embed 显示）"""
    title = att.get("field_name", "附件")
    filename = att.get("filename", "")
    b64 = att.get("base64", "")
    size_kb = att.get("size", 0) / 1024

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  @page {{ size: A4; margin: 0.5cm; }}
  body {{ font-family: "PingFang SC", "Microsoft YaHei", "SimHei", sans-serif;
         margin: 0; padding: 0; }}
  .header {{ text-align: center; border-bottom: 2px solid #000;
             padding-bottom: 8px; margin-bottom: 16px; }}
  .header h1 {{ font-size: 18px; margin: 0 0 4px 0; }}
  .header .meta {{ font-size: 12px; color: #555; }}
  .pdf-wrap {{ width: 100%; height: 95vh; }}
  .pdf-wrap embed {{ width: 100%; height: 100%; border: 1px solid #ddd; }}
</style>
</head>
<body>
  <div class="header">
    <h1>附件 {index} — {title}</h1>
    <div class="meta">文件名：{filename}（{size_kb:.1f} KB）</div>
  </div>
  <div class="pdf-wrap">
    <embed src="{b64}" type="application/pdf" width="100%" height="100%" />
  </div>
</body>
</html>"""


def _render_excel_html(att: dict, index: int) -> str:
    """将 Excel 附件渲染为 HTML（每个 sheet 一个表格页面）"""
    import io
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter

    title = att.get("field_name", "附件")
    filename = att.get("filename", "")
    b64 = att.get("base64", "")
    size_kb = att.get("size", 0) / 1024

    if not b64:
        return _render_attachment_html(att, index)

    try:
        raw_bytes = base64.b64decode(b64)
        wb = load_workbook(io.BytesIO(raw_bytes), data_only=True)
    except Exception as e:
        return f'<html><body><p>无法解析 Excel 文件: {e}</p></body></html>'

    # 收集每个 sheet 的 HTML 片段
    sheets_html = []
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        if ws.max_row < 1 or ws.max_column < 1:
            continue

        # 判断是否需要横向布局（列数 > 6）
        use_landscape = ws.max_column > 6
        page_css = '@page { size: A4 landscape; margin: 0.8cm; }' if use_landscape else '@page { size: A4; margin: 1cm; }'

        # 获取合并单元格信息
        merged_ranges = {}
        for merged_range in ws.merged_cells.ranges:
            for row in range(merged_range.min_row, merged_range.max_row + 1):
                for col in range(merged_range.min_col, merged_range.max_col + 1):
                    merged_ranges[(row, col)] = merged_range

        # 渲染表格
        rows_html = []
        for row_idx in range(1, ws.max_row + 1):
            cells_html = []
            col_idx = 1
            while col_idx <= ws.max_column:
                cell = ws.cell(row=row_idx, column=col_idx)
                cell_value = cell.value

                # 格式化值
                if cell_value is None:
                    display = ""
                elif isinstance(cell_value, float):
                    # 财务数字保留 2 位小数
                    display = f"{cell_value:,.2f}"
                elif isinstance(cell_value, int):
                    display = f"{cell_value:,}"
                else:
                    display = str(cell_value).replace("\n", "<br>")

                # 检查合并单元格
                if (row_idx, col_idx) in merged_ranges:
                    mr = merged_ranges[(row_idx, col_idx)]
                    col_span = mr.max_col - mr.min_col + 1
                    row_span = mr.max_row - mr.min_row + 1

                    # 只在合并区域左上角输出完整 cell
                    if row_idx == mr.min_row and col_idx == mr.min_col:
                        col_span_attr = f' colspan="{col_span}"' if col_span > 1 else ""
                        row_span_attr = f' rowspan="{row_span}"' if row_span > 1 else ""
                        cells_html.append(f'<td{col_span_attr}{row_span_attr} class="merged">{display}</td>')
                        col_idx = mr.max_col + 1
                        continue
                    else:
                        col_idx += 1
                        continue

                cells_html.append(f"<td>{display}</td>")
                col_idx += 1

            if cells_html:
                rows_html.append(f"<tr>{''.join(cells_html)}</tr>")

        # 列宽提示
        col_width_hints = ""
        if use_landscape:
            total_cols = ws.max_column
            for ci in range(1, total_cols + 1):
                col_letter = get_column_letter(ci)
                # 取列中前几行最长内容估算宽度
                max_len = 4
                for ri in range(1, min(ws.max_row + 1, 6)):
                    cv = ws.cell(row=ri, column=ci).value
                    if cv:
                        max_len = max(max_len, len(str(cv)))
                width_pct = min(max_len * 2.5, 25)
                col_width_hints += f"    td:nth-child({ci}) {{ min-width: {width_pct:.0f}px; max-width: {width_pct * 2:.0f}px; }}\n"

        sheet_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  {page_css}
  body {{
    font-family: "PingFang SC", "Microsoft YaHei", "SimHei", sans-serif;
    margin: 0; padding: 0; font-size: 10px;
  }}
  .sheet-header {{
    text-align: center; border-bottom: 1.5px solid #000;
    padding-bottom: 4px; margin-bottom: 8px;
  }}
  .sheet-header h2 {{ font-size: 14px; margin: 0 0 2px 0; }}
  .sheet-header .meta {{ font-size: 10px; color: #555; }}
  table {{
    width: 100%; border-collapse: collapse;
    table-layout: auto; word-break: break-all;
  }}
  th, td {{
    border: 1px solid #333; padding: 3px 5px;
    text-align: left; vertical-align: top;
    font-size: 9px; line-height: 1.3;
  }}
  th {{ background-color: #d9e2f3; font-weight: bold; }}
  tr:first-child td {{ background-color: #d9e2f3; font-weight: bold; }}
  tr:first-child td.merged {{ font-size: 13px; text-align: center;
    background-color: #002060; color: #fff; font-weight: bold; }}
  td.merged {{ text-align: center; font-weight: bold; }}
  .footer {{ margin-top: 4px; text-align: center; font-size: 9px; color: #999; }}
{col_width_hints}
</style>
</head>
<body>
  <div class="sheet-header">
    <h2>Sheet: {sheet_name}</h2>
    <div class="meta">文件: {filename} | 共 {ws.max_row} 行 x {ws.max_column} 列</div>
  </div>
  <table>
    {''.join(rows_html)}
  </table>
  <div class="footer">— Sheet "{sheet_name}" —</div>
</body>
</html>"""
        sheets_html.append(sheet_html)

    if not sheets_html:
        return f'<html><body><p>Excel 文件中没有可渲染的数据表。</p></body></html>'

    # 合并所有 sheet HTML（每个 sheet 独立分页）
    combined = "".join(sheets_html)
    return combined


def _generate_pdf_chrome(html_files: list[str], pdf_path: str) -> bool:
    """调用 Chrome 把多个 HTML 合并为单个 PDF"""
    # Node 脚本：依次打开每个 HTML，追加到同一个 PDF
    chrome_path = _get_chrome_path()
    node_script = f"""
const puppeteer = require('puppeteer');
const path = require('path');

(async () => {{
  const browser = await puppeteer.launch({{
    headless: true,
    executablePath: '{chrome_path}',
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  }});

  const htmlFiles = {json.dumps(html_files)};
  const pdfPath = {json.dumps(pdf_path)};

  let mergedPdf = null;

  for (let i = 0; i < htmlFiles.length; i++) {{
    const htmlFile = htmlFiles[i];
    const page = await browser.newPage();
    await page.goto('file://' + path.resolve(htmlFile), {{
      waitUntil: 'load', timeout: 60000
    }});
    const tmpPdf = pdfPath.replace('.pdf', `__part${{i}}.pdf`);
    await page.pdf({{
      path: tmpPdf,
      format: 'A4',
      printBackground: true,
      margin: {{ top: '1cm', bottom: '1cm', left: '1cm', right: '1cm' }}
    }});
    await page.close();
    console.log('  ✓ part ' + (i+1) + '/' + htmlFiles.length);
  }}

  await browser.close();
  console.log('Chrome PDF generation complete');
}})();
"""
    script_path = OUTPUT_DIR / "_merge_pdf.js"
    script_path.write_text(node_script, encoding="utf-8")

    env = os.environ.copy()
    # 自动检测 puppeteer 所在 node_modules 路径
    puppeteer_path = _detect_puppeteer_node_path()
    if puppeteer_path:
        env["NODE_PATH"] = puppeteer_path

    node_bin = _get_node_bin()
    result = subprocess.run(
        [node_bin, str(script_path)],
        env=env, capture_output=True, text=True, timeout=180
    )
    if result.stdout:
        print(result.stdout)
    if result.returncode != 0:
        print(f"[Chrome 错误] {result.stderr}")
        return False
    return True


def _merge_pdfs_with_pypdf(pdf_parts: list[str], output_pdf: str) -> bool:
    """用 pypdf 合并多个 PDF"""
    try:
        from pypdf import PdfWriter
    except ImportError:
        try:
            from PyPDF2 import PdfMerger
            merger = PdfMerger()
            for p in pdf_parts:
                merger.append(p)
            merger.write(output_pdf)
            merger.close()
            return True
        except ImportError:
            return False

    writer = PdfWriter()
    for p in pdf_parts:
        writer.append(p)
    with open(output_pdf, "wb") as f:
        writer.write(f)
    return True


def _cleanup_temp(temp_files: list[str]):
    """清理中间临时文件"""
    for p in temp_files:
        try:
            os.remove(p)
        except OSError:
            pass


def generate_pdf(instance: dict, output_name: str | None = None) -> str:
    """
    根据审批实例数据生成 PDF

    Args:
        instance: 审批实例详情
        output_name: 输出文件名（不含扩展名）

    Returns:
        PDF 文件路径
    """
    output_name = output_name or instance.get("instance_code", "审批单")
    safe_name = "".join(c for c in output_name if c.isalnum() or c in "._-（）()")

    # 1. 渲染主 HTML
    main_html = _render_main_html(instance)
    main_html_path = OUTPUT_DIR / f"{safe_name}_main.html"
    main_html_path.write_text(main_html, encoding="utf-8")
    _temp_files = [str(main_html_path)]  # 记录所有中间文件，最后统一清理

    # 2. 分离附件：图片/Excel 走 Chrome 渲染，PDF 直接保存为文件
    attachments = instance.get("attachments", [])
    image_atts = [a for a in attachments if a.get("type") == "image" and a.get("base64")]
    excel_atts = [a for a in attachments if a.get("type") == "excel" and a.get("base64")]
    pdf_atts = [a for a in attachments if a.get("type") == "pdf" and a.get("base64")]

    # 3. 图片附件渲染为独立 HTML 页面
    html_files = [str(main_html_path)]
    for i, att in enumerate(image_atts, 1):
        att_html = _render_attachment_html(att, i)
        att_path = OUTPUT_DIR / f"{safe_name}_att{i}.html"
        att_path.write_text(att_html, encoding="utf-8")
        html_files.append(str(att_path))
        _temp_files.append(str(att_path))

    # 3.5. Excel 附件渲染为独立 HTML 页面（每个 sheet 一个表格）
    offset = len(image_atts)
    for i, att in enumerate(excel_atts, 1):
        att_html = _render_excel_html(att, offset + i)
        att_path = OUTPUT_DIR / f"{safe_name}_excel{i}.html"
        att_path.write_text(att_html, encoding="utf-8")
        html_files.append(str(att_path))
        _temp_files.append(str(att_path))
        print(f"  [Excel] {att.get('filename', '')} ({att.get('size', 0) / 1024:.1f} KB)")

    # 4. PDF 附件直接保存为 .pdf 文件（用于后续 pypdf 合并）
    pdf_att_files = []
    for i, att in enumerate(pdf_atts, 1):
        data_uri = att.get("base64", "")
        try:
            # 从 data URI 中提取原始 PDF 字节
            if data_uri.startswith("data:"):
                b64_part = data_uri.split(",", 1)[1]
                raw_bytes = base64.b64decode(b64_part)
            else:
                raw_bytes = base64.b64decode(data_uri)
            att_pdf_path = OUTPUT_DIR / f"{safe_name}_att_pdf{i}.pdf"
            att_pdf_path.write_bytes(raw_bytes)
            pdf_att_files.append(str(att_pdf_path))
            _temp_files.append(str(att_pdf_path))
            print(f"  [PDF附件] 已保存: {att.get('filename', '')} ({len(raw_bytes) / 1024:.1f} KB)")
        except Exception as e:
            print(f"  [PDF附件] 解码失败: {att.get('filename', '')} - {e}")

    # 5. 用 Chrome 生成主 HTML + 图片附件的 PDF 部分
    pdf_path = OUTPUT_DIR / f"{safe_name}.pdf"
    _temp_files.append(str(OUTPUT_DIR / "_merge_pdf.js"))
    if not _generate_pdf_chrome(html_files, str(pdf_path)):
        # Chrome 失败时回退到 WeasyPrint（仅主页）
        try:
            from weasyprint import HTML
            HTML(string=main_html).write_pdf(str(pdf_path))
            _cleanup_temp(_temp_files)
            return str(pdf_path)
        except Exception:
            return str(main_html_path)  # 保留 HTML 作为回退产物

    # 6. 收集所有 PDF 部分：Chrome 生成的部分 + 原始 PDF 附件
    part_pdfs = [str(pdf_path).replace(".pdf", f"__part{i}.pdf") for i in range(len(html_files))]
    all_parts = part_pdfs + pdf_att_files

    if all(Path(p).exists() for p in all_parts):
        if _merge_pdfs_with_pypdf(all_parts, str(pdf_path)):
            # 清理中间文件
            _temp_files_all = _temp_files + all_parts
            _cleanup_temp(_temp_files_all)
            return str(pdf_path)

    # 合并失败时返回第一部分
    if Path(part_pdfs[0]).exists():
        shutil.move(part_pdfs[0], str(pdf_path))
    for p in part_pdfs[1:] + pdf_att_files:
        try:
            os.remove(p)
        except OSError:
            pass
    _cleanup_temp(_temp_files)

    return str(pdf_path)


def generate_batch_pdfs(instances: list[dict], approval_name: str = "") -> list[str]:
    """
    批量生成 PDF
    """
    pdf_paths = []
    total = len(instances)

    for i, inst in enumerate(instances):
        try:
            serial_no = inst.get('serial_no', '') or inst.get('instance_code', '')
            output_name = f"{approval_name}_{serial_no}" if approval_name else None
            pdf_path = generate_pdf(inst, output_name=output_name)
            pdf_paths.append(pdf_path)
            pct = (i + 1) / total * 100
            bar_width = 20
            filled = int(bar_width * (i + 1) / total)
            bar = "█" * filled + "░" * (bar_width - filled)
            print(f"\r[{bar}] {i + 1}/{total} ({pct:.0f}%) | {serial_no}", end="", flush=True)
        except Exception as e:
            print(f"\n[错误] 生成 PDF 失败: {inst.get('instance_code', '')} - {e}")

    print()
    return pdf_paths
