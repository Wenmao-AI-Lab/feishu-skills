"""
指令解析器 — 从用户自然语言输入中提取审批类型、日期范围等参数

支持格式：
  - "批量打印采购审批 7月"
  - "打印6.1-6.30的报销单"
  - "打印审批"
  - "打印最近3天 的请假审批"
  - "打印今 天的加班审批"
"""

import re
import json
from datetime import datetime, timedelta, timezone
from config import resolve_type_from_input, get_month_timestamps


class CommandParseResult:
    """指令解析结果"""
    def __init__(self):
        self.type_keyword: str | None = None   # 审批类型关键词，如 "采购"
        self.start_ts: int | None = None        # 起始时间戳（秒）
        self.end_ts: int | None = None          # 结束时间戳（秒）
        self.needs_type_selection: bool = False  # 是否需要让用户选择审批类型
        self.errors: list[str] = []

    def to_dict(self) -> dict:
        return {
            "type_keyword": self.type_keyword,
            "start_ts": self.start_ts,
            "end_ts": self.end_ts,
            "needs_type_selection": self.needs_type_selection,
            "errors": self.errors,
        }

    def __repr__(self):
        return json.dumps(self.to_dict(), ensure_ascii=False)


def parse_command(text: str) -> CommandParseResult:
    """
    解析用户指令

    Args:
        text: 用户输入文本

    Returns:
        CommandParseResult
    """
    result = CommandParseResult()
    text = text.strip()

    # 1. 提取审批类型
    result.type_keyword = resolve_type_from_input(text)

    # 2. 提取日期范围
    _parse_date_range(text, result)

    # 3. 判断是否需要选择审批类型
    if result.type_keyword is None:
        result.needs_type_selection = True

    return result


def _parse_date_range(text: str, result: CommandParseResult) -> None:
    """从文本中解析日期范围，设置 result.start_ts, result.end_ts"""
    tz = timezone(timedelta(hours=8))  # CST

    # 模式1: "X月" — 整月
    m = re.search(r"(\d{1,2})\s*月", text)
    if m:
        month = int(m.group(1))
        year = datetime.now(tz).year
        # 如果指定月份大于当前月份，视为上一年
        if month > datetime.now(tz).month:
            year -= 1
        result.start_ts, result.end_ts = get_month_timestamps(year, month)
        return

    # 模式2: "X.Y-Z.W" 或 "X月Y日-Z月W日"
    m = re.search(r"(\d{1,2})[\.月](\d{1,2})[日号]?\s*[-~到]\s*(\d{1,2})[\.月](\d{1,2})[日号]?", text)
    if m:
        year = datetime.now(tz).year
        start = datetime(year, int(m.group(1)), int(m.group(2)), tzinfo=tz)
        end = datetime(year, int(m.group(3)), int(m.group(4)), 23, 59, 59, tzinfo=tz)
        result.start_ts = int(start.timestamp())
        result.end_ts = int(end.timestamp())
        return

    # 模式3: "最近N天"
    m = re.search(r"最近\s*(\d+)\s*天", text)
    if m:
        n = int(m.group(1))
        now = datetime.now(tz)
        result.start_ts = int((now - timedelta(days=n)).replace(hour=0, minute=0, second=0, tzinfo=tz).timestamp())
        result.end_ts = int(now.timestamp())
        return

    # 模式3b: "最近N个月"
    m = re.search(r"最近\s*(\d+)\s*个?\s*月", text)
    if m:
        from dateutil.relativedelta import relativedelta
        n = int(m.group(1))
        now = datetime.now(tz)
        result.start_ts = int((now - relativedelta(months=n)).replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=tz).timestamp())
        result.end_ts = int(now.timestamp())
        return

    # 模式3c: "最近N周"
    m = re.search(r"最近\s*(\d+)\s*周", text)
    if m:
        n = int(m.group(1))
        now = datetime.now(tz)
        result.start_ts = int((now - timedelta(weeks=n)).replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=tz).timestamp())
        result.end_ts = int(now.timestamp())
        return

    # 模式4: "今天"
    if "今天" in text or "今日" in text:
        now = datetime.now(tz)
        result.start_ts = int(now.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=tz).timestamp())
        result.end_ts = int(now.timestamp())
        return

    # 模式5: "昨天"
    if "昨天" in text or "昨日" in text:
        now = datetime.now(tz)
        yesterday = now - timedelta(days=1)
        result.start_ts = int(yesterday.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=tz).timestamp())
        result.end_ts = int(yesterday.replace(hour=23, minute=59, second=59, tzinfo=tz).timestamp())
        return

    # 模式6: "本周"
    if "本周" in text or "这周" in text:
        now = datetime.now(tz)
        monday = now - timedelta(days=now.weekday())
        result.start_ts = int(monday.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=tz).timestamp())
        result.end_ts = int(now.timestamp())
        return

    # 默认: 本月
    now = datetime.now(tz)
    result.start_ts, result.end_ts = get_month_timestamps(now.year, now.month)


if __name__ == "__main__":
    # 测试用例
    cases = [
        "批量打印采购审批 7月",
        "打印6.1-6.30的报销单",
        "打印审批",
        "打印最近3天的请假审批",
        "打印今天的加班审批",
        "打印本周的出差审批",
    ]
    for case in cases:
        result = parse_command(case)
        print(f"输入: {case}")
        print(f"结果: {result}")
        print()
