"""
审批查询模块 — 通过 lark-cli 调用飞书审批 API
"""

import subprocess
import json
import sys
import urllib.request
import base64
from datetime import datetime, timezone, timedelta
from typing import Any
from config import LARK_CLI, PAGE_SIZE, INSTANCE_STATUS, STATUS_STR_MAP, SKIP_STATUSES, MAX_PRINT_COUNT

TZ_CST = timezone(timedelta(hours=8))

# 操作类型中文映射
OP_TYPE_LABELS = {
    "START": "发起审批",
    "PASS": "审批通过",
    "AUTO_PASS": "自动通过",
    "REJECT": "审批拒绝",
    "TRANSFER": "转交",
    "ADD_SIGN": "加签",
    "ADD_SIGN_AND_APPROVE": "加签并同意",
    "ROLLBACK": "退回",
    "CANCEL": "撤销",
    "CC": "抄送",
    "FORWARD": "转发",
    "REMIND": "催办",
}

# 用户名称缓存
_user_name_cache: dict[str, str] = {}

# 部门名称缓存
_dept_name_cache: dict[str, str] = {}


def _lookup_user_name(user_id: str) -> str:
    """通过 open_id 查找用户名"""
    if not user_id or not user_id.startswith("ou_"):
        return user_id
    if user_id in _user_name_cache:
        return _user_name_cache[user_id]

    try:
        result = subprocess.run(
            [LARK_CLI, "contact", "+search-user",
             "--user-ids", user_id,
             "--as", "user"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout)
            users = data.get("data", {}).get("users", [])
            if users:
                name = users[0].get("localized_name", "")
                dept = users[0].get("department", "")
                if name:
                    _user_name_cache[user_id] = name
                if dept:
                    # 顺手缓存部门（可能对应多个 open_id）
                    _dept_name_cache.setdefault(f"user:{user_id}", dept)
                if name:
                    return name
    except Exception:
        pass

    _user_name_cache[user_id] = user_id
    return user_id


def _lookup_department_name(dept_id: str, user_id: str = "") -> str:
    """通过 open_department_id 或 user_id 查找部门名称。
    部门 API 需要 contact:contact.base:readonly 权限，可能缺失；
    优先用 +search-user 获取部门信息。
    """
    # 先查缓存
    if dept_id and dept_id in _dept_name_cache:
        return _dept_name_cache[dept_id]
    cache_key = f"user:{user_id}"
    if user_id and cache_key in _dept_name_cache:
        return _dept_name_cache[cache_key]

    # 尝试通过 +search-user 获取部门
    if user_id:
        try:
            result = subprocess.run(
                [LARK_CLI, "contact", "+search-user",
                 "--user-ids", user_id,
                 "--as", "user"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0 and result.stdout.strip():
                data = json.loads(result.stdout)
                users = data.get("data", {}).get("users", [])
                if users:
                    dept = users[0].get("department", "")
                    if dept:
                        _dept_name_cache[cache_key] = dept
                        if dept_id:
                            _dept_name_cache[dept_id] = dept
                        return dept
        except Exception:
            pass

    # 回退：尝试部门 API（需要 contact:contact.base:readonly 权限）
    if dept_id and dept_id.startswith("od_"):
        try:
            result = subprocess.run(
                [LARK_CLI, "api", "GET", f"/open-apis/contact/v3/departments/{dept_id}",
                 "--as", "user"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0 and result.stdout.strip():
                data = json.loads(result.stdout)
                dept = data.get("data", {}).get("department", {})
                name = dept.get("name", "")
                if name:
                    _dept_name_cache[dept_id] = name
                    return name
        except Exception:
            pass

    _dept_name_cache[dept_id] = dept_id or ""
    return dept_id or ""


def _format_ts(ts, fmt: str = "%Y-%m-%d") -> str:
    """格式化时间戳为日期字符串，兼容毫秒时间戳"""
    if not ts:
        return ""
    try:
        ts_int = int(ts)
        # 毫秒时间戳 (> 999999999999)
        if ts_int > 999999999999:
            ts_int = ts_int // 1000
        dt = datetime.fromtimestamp(ts_int, tz=TZ_CST)
        return dt.strftime(fmt)
    except (ValueError, TypeError, OSError):
        return str(ts)


def _format_iso_date(val: str) -> str:
    """将 ISO 日期字符串格式化为 YYYY-MM-DD"""
    if not val:
        return ""
    try:
        # 尝试解析 ISO 格式 "2026-07-21T00:00:00+08:00"
        if "T" in val:
            dt = datetime.fromisoformat(val)
            return dt.strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        pass
    return val


def _format_timeline(ops: list[dict], tasks: list[dict] | None = None) -> list[dict]:
    """格式化审批操作记录为时间线（合并 tasks 拿到节点名）"""
    tasks = tasks or []

    # 用 (user_id, time_bucket) 作为匹配 key，把 node_name 关联到 op
    def find_node_name(user_id: str, ts_ms: int) -> str:
        """通过 user_id + 时间找到对应 task 的节点名"""
        # 找出最匹配的 task
        best_name = ""
        best_score = 0
        for t in tasks:
            if t.get("user_id") != user_id:
                continue
            t_start = int(t.get("start_time") or 0)
            t_end = int(t.get("end_time") or 0)
            # 如果操作时间在 task 的 [start, end] 区间内
            if t_start <= ts_ms <= (t_end or t_start):
                return t.get("node_name", "") or ""
            # 或者时间差不超过 60s
            diff = min(abs(ts_ms - t_start), abs(ts_ms - t_end)) if t_end else abs(ts_ms - t_start)
            if diff < 60000 and diff > best_score:
                best_score = diff
                best_name = t.get("node_name", "")
        return best_name

    timeline = []
    for op in ops:
        create_time = op.get("create_time", "")
        try:
            ts_ms = int(create_time)
            if ts_ms < 1000000000000:
                ts_ms = ts_ms * 1000
            dt = datetime.fromtimestamp(ts_ms / 1000, tz=TZ_CST)
            time_str = dt.strftime("%Y-%m-%d %H:%M")
        except (ValueError, TypeError):
            time_str = str(create_time)
            ts_ms = 0

        op_type = op.get("type", "")
        label = OP_TYPE_LABELS.get(op_type, op_type)

        user_id = op.get("user_id", "")
        user_name = _lookup_user_name(user_id) if user_id else "系统"

        comment = op.get("comment", "") or op.get("approval_comment", "")

        # 关联节点名
        node_name = find_node_name(user_id, ts_ms) if user_id else ""

        timeline.append({
            "time": time_str,
            "type": op_type,
            "label": label,
            "action": label,
            "node_name": node_name,
            "user_name": user_name,
            "comment": comment,
        })
    return timeline


def _download_attachment(url: str, output_dir: str = "") -> dict | None:
    """下载单个附件，返回 {filename, type, size, base64}"""
    try:
        import urllib.parse
        req = urllib.request.Request(url)
        resp = urllib.request.urlopen(req, timeout=30)
        content_type = resp.headers.get("Content-Type", "")
        disposition = resp.headers.get("Content-Disposition", "")
        data = resp.read()

        filename = "attachment"
        if "filename=" in disposition:
            import re
            m = re.search(r'filename\*?=(?:UTF-8\'\')?([^\";]+)', disposition)
            if m:
                filename = urllib.parse.unquote(m.group(1).strip('"'))

        if content_type.startswith("image/"):
            ext = content_type.split("/")[-1]
            if ext == "jpeg":
                ext = "jpg"
            filename = f"{filename}.{ext}" if "." not in filename else filename
            b64 = base64.b64encode(data).decode("ascii")
            data_uri = f"data:{content_type};base64,{b64}"
            return {"filename": filename, "type": "image", "size": len(data), "base64": data_uri}
        elif "pdf" in content_type:
            filename = f"{filename}.pdf" if not filename.endswith(".pdf") else filename
            b64 = base64.b64encode(data).decode("ascii")
            data_uri = f"data:application/pdf;base64,{b64}"
            return {"filename": filename, "type": "pdf", "size": len(data), "base64": data_uri}
        elif "spreadsheetml" in content_type or "ms-excel" in content_type or filename.lower().endswith((".xlsx", ".xls")):
            if not filename.lower().endswith((".xlsx", ".xls")):
                filename = f"{filename}.xlsx"
            b64 = base64.b64encode(data).decode("ascii")
            return {"filename": filename, "type": "excel", "size": len(data), "base64": b64}
        else:
            return {"filename": filename, "type": "file", "size": len(data), "base64": ""}
    except Exception as e:
        print(f"[附件下载失败] {url[:80]}...: {e}")
        return None


def _extract_attachments(form_data: list[dict]) -> list[dict]:
    """从表单数据中提取并下载所有附件（attachmentV2 + image 类型）"""
    attachments = []
    for item in form_data:
        item_type = item.get("type", "")
        if item_type not in ("attachmentV2", "image") or not item.get("value"):
            continue
        urls = item["value"]
        if isinstance(urls, str):
            urls = [urls]
        for url in urls:
            if isinstance(url, str) and url.startswith("http"):
                result = _download_attachment(url)
                if result:
                    result["field_name"] = item.get("name", "附件")
                    attachments.append(result)
    return attachments


def _extract_comment_attachments(comment_list: list) -> list[dict]:
    """从评论列表中提取并下载附件（评论中的文件）"""
    attachments = []
    for c in comment_list:
        files = c.get("files", [])
        if not files:
            continue
        for f in files:
            url = f.get("url", "")
            if not url:
                continue
            original_title = f.get("title", "附件")
            result = _download_attachment(url)
            if result:
                # 用原始标题覆盖从URL提取的文件名
                if original_title and original_title != "附件":
                    result["filename"] = original_title
                result["field_name"] = f"评论: {original_title}"
                attachments.append(result)
    return attachments



def _run_lark(command: list[str], timeout: int = 30) -> dict:
    """运行 lark-cli 命令并返回 JSON 结果"""
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        # lark-cli 正常结果在 stdout，错误在 stderr
        if proc.stdout.strip():
            result = json.loads(proc.stdout)
        elif proc.stderr.strip():
            result = json.loads(proc.stderr)
        else:
            return {"ok": False, "error": "empty response"}

        # 跳过 _notice 等元数据干扰
        if isinstance(result, dict) and not result.get("ok", False) and "error" in result:
            return result

        return result
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"命令超时 ({timeout}s)"}
    except json.JSONDecodeError as e:
        return {"ok": False, "error": f"JSON 解析失败: {e}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def search_approval_definitions(keyword: str) -> list[dict]:
    """
    搜索可发起的审批定义

    Args:
        keyword: 搜索关键词，如 "采购"、"报销"

    Returns:
        [{"approval_code": "...", "approval_name": "...", "is_external": false}, ...]
    """
    cmd = [
        LARK_CLI, "approval", "approvals", "search",
        "--data", json.dumps({"keyword": keyword, "page_size": 10}),
        "--as", "user",
    ]
    result = _run_lark(cmd)

    if not result.get("ok"):
        return []

    data = result.get("data", {})
    definitions = data.get("approvals", []) or data.get("items", [])

    # 标准化字段名
    normalized = []
    for item in definitions:
        normalized.append({
            "approval_code": item.get("approval_code") or item.get("code", ""),
            "approval_name": item.get("approval_name") or item.get("name", ""),
            "is_external": item.get("is_external", False),
            "icon_url": item.get("icon_url", ""),
        })
    return normalized


def query_initiated_instances(
    definition_code: str,
    start_ts: int,
    end_ts: int,
    page_size: int = PAGE_SIZE,
) -> list[dict]:
    """
    查询用户发起的审批实例列表

    Args:
        definition_code: 审批定义 Code
        start_ts: 起始时间戳（秒）
        end_ts: 结束时间戳（秒）
        page_size: 每页数量

    Returns:
        [{"instance_code": "...", "definition_name": "...", "instance_status": 2, ...}, ...]
    """
    instances = []
    page_token = None

    while len(instances) < MAX_PRINT_COUNT:
        params = {
            "definition_code": definition_code,
            "start_timestamp": str(int(start_ts)),
            "end_timestamp": str(int(end_ts)),
            "page_size": page_size,
        }
        if page_token:
            params["page_token"] = page_token

        cmd = [
            LARK_CLI, "approval", "instances", "initiated",
            "--params", json.dumps(params),
            "--as", "user",
        ]
        result = _run_lark(cmd)

        if not result.get("ok"):
            break

        data = result.get("data", {})
        page_instances = data.get("instances", []) or data.get("items", [])

        for inst in page_instances:
            status = inst.get("instance_status", 0)
            # 跳过已撤销等不需要打印的状态
            if status in SKIP_STATUSES:
                continue
            instances.append({
                "instance_code": inst.get("instance_code", ""),
                "definition_code": inst.get("definition_code", definition_code),
                "definition_name": inst.get("definition_name", ""),
                "initiator_name": inst.get("initiator_name", ""),
                "instance_status": status,
                "status_label": INSTANCE_STATUS.get(status, "未知"),
                "summaries": inst.get("summaries", []),
                "start_time": inst.get("start_time", 0),
                "end_time": inst.get("end_time", 0),
            })

        has_more = data.get("has_more", False)
        page_token = data.get("page_token", "")

        if not has_more or not page_token:
            break

    return instances


def _format_field_value(value) -> str:
    """
    将飞书审批字段值格式化为可读文本

    处理场景：
    - 简单字符串 → 直接返回
    - 列表 → 逗号拼接
    - 嵌套字典（如收款账户widget） → 提取关键信息拼接
    - 字典的 text 字段可能是 JSON 字符串 → 解析提取

    特殊字段规则：
    - 收款账户 (widgetAccount*) → 格式化为 "公司名 / 银行名+支行 / 账号"
    - 银行选择 → 提取 bankNameZh
    - 省市选择 → 提取名称
    """
    if value is None or value == "":
        return ""

    # 简单字符串
    if isinstance(value, str):
        return value

    # 列表
    if isinstance(value, list):
        parts = []
        for v in value:
            if isinstance(v, dict):
                parts.append(_format_field_value(v))
            else:
                parts.append(str(v))
        return ", ".join(parts)

    # 字典
    if isinstance(value, dict):
        # 检查是否是收款账户这类 widget 嵌套结构
        is_account = any(k.startswith("widgetAccount") for k in value)

        if is_account:
            return _format_account_value(value)

        # 普通字典：优先用 text 或 name 字段
        if "text" in value:
            text_val = value["text"]
            # text 可能是 JSON 字符串
            if isinstance(text_val, str):
                try:
                    parsed = json.loads(text_val)
                    if isinstance(parsed, dict):
                        return _extract_name_from_json(parsed)
                    if isinstance(parsed, list):
                        return ", ".join(p.get("name", p.get("text", str(p))) for p in parsed)
                    return str(text_val)
                except (json.JSONDecodeError, TypeError):
                    return str(text_val)
            return str(text_val)
        if "name" in value:
            return str(value["name"])
        # 兜底：显示 value 字段
        if "value" in value:
            v = value["value"]
            if isinstance(v, str):
                return v
            return str(v)
        return str(value)

    return str(value)


def _format_account_value(acct: dict) -> str:
    """格式化收款账户为可读字符串"""
    parts = []

    # 公司名称
    name = acct.get("widgetAccountName")
    if name:
        parts.append(str(name))

    # 银行名称
    bank = acct.get("widgetAccountBankName", {})
    if isinstance(bank, dict):
        text_val = bank.get("text", "")
        if isinstance(text_val, str):
            try:
                parsed = json.loads(text_val)
                bank_name = parsed.get("bankNameZh", "")
            except (json.JSONDecodeError, TypeError):
                bank_name = text_val
        else:
            bank_name = str(text_val)
        if bank_name:
            parts.append(bank_name)

    # 支行
    branch = acct.get("widgetAccountBankBranch", {})
    if isinstance(branch, dict):
        text_val = branch.get("text", "")
        if isinstance(text_val, str):
            try:
                parsed = json.loads(text_val)
                branch_name = parsed.get("bankBranchNameZh", "")
            except (json.JSONDecodeError, TypeError):
                branch_name = text_val
        else:
            branch_name = str(text_val)
        if branch_name:
            parts.append(branch_name)

    # 账号
    number = acct.get("widgetAccountNumber")
    if number:
        parts.append(str(number))

    # 备注
    remark = acct.get("widgetAccountRemark")
    if remark:
        parts.append(f"({remark})")

    return " / ".join(parts)


def _extract_name_from_json(obj: dict) -> str:
    """从 JSON 对象中提取名称"""
    for key in ("bankNameZh", "bankBranchNameZh", "name", "text", "bankNameEn"):
        val = obj.get(key)
        if val:
            return str(val)
    return str(obj)


def get_instance_detail(instance_code: str) -> dict | None:
    """
    获取审批实例详情

    Args:
        instance_code: 审批实例 Code

    Returns:
        实例详情 dict，包含 form 字段
    """
    cmd = [
        LARK_CLI, "approval", "instances", "get",
        "--params", json.dumps({"instance_code": instance_code}),
        "--as", "user",
    ]
    result = _run_lark(cmd, timeout=30)

    if not result.get("ok"):
        return None

    data = result.get("data", {})
    instance = data

    # 解析 form JSON
    form_raw = instance.get("form", "[]")
    if isinstance(form_raw, str):
        try:
            form_data = json.loads(form_raw)
        except json.JSONDecodeError:
            form_data = []
    else:
        form_data = form_raw if isinstance(form_raw, list) else []

    # 标准化字段值
    fields = {}
    for item in form_data:
        name = item.get("name", "")
        item_type = item.get("type", "")
        value = item.get("value", "")

        # mutableGroup（引用多维表格）— 展开内部 widget 为独立字段
        if item_type == "mutableGroup":
            widgets = value
            if isinstance(widgets, str):
                try:
                    widgets = json.loads(widgets)
                except json.JSONDecodeError:
                    widgets = []
            if isinstance(widgets, list):
                for widget in widgets:
                    wname = widget.get("name", "")
                    wvalue = widget.get("value", "")
                    if wname:
                        fields[wname] = _format_field_value(wvalue)
            continue

        fields[name] = _format_field_value(value)

    # 评论
    comments_raw = instance.get("comments", "[]")
    if isinstance(comments_raw, str):
        try:
            comment_list = json.loads(comments_raw)
        except json.JSONDecodeError:
            comment_list = []
    else:
        comment_list = comments_raw if isinstance(comments_raw, list) else []

    # 操作记录 -> 时间线（含节点名）
    ops_raw = instance.get("operation_records", "[]")
    if isinstance(ops_raw, str):
        try:
            ops = json.loads(ops_raw)
        except json.JSONDecodeError:
            ops = []
    else:
        ops = ops_raw if isinstance(ops_raw, list) else []

    # 解析 tasks（包含节点名、节点状态）
    tasks_raw = instance.get("tasks", "[]")
    if isinstance(tasks_raw, str):
        try:
            tasks = json.loads(tasks_raw)
        except json.JSONDecodeError:
            tasks = []
    else:
        tasks = tasks_raw if isinstance(tasks_raw, list) else []

    timeline = _format_timeline(ops, tasks)

    # 附件处理 — 表单附件 + 评论附件
    attachments = _extract_attachments(form_data)
    attachments.extend(_extract_comment_attachments(comment_list))

    # 将文件型字段的值替换为附件文件名（而非 URL）
    _file_field_names: dict[str, list[str]] = {}  # field_name -> [filename, ...]
    for a in attachments:
        fn = a.get("field_name", "")
        if fn and not fn.startswith("评论:"):
            _file_field_names.setdefault(fn, []).append(a.get("filename", ""))
    for fn, names in _file_field_names.items():
        if fn in fields:
            fields[fn] = "、".join(names)

    # 申请人
    user_id = instance.get("user_id", "")
    initiator_name = _lookup_user_name(user_id) if user_id else ""

    # 所属部门 — 优先通过 +search-user 获取（不需要额外权限）
    dept_id = instance.get("department_id", "")
    department_name = _lookup_department_name(dept_id, user_id) if dept_id or user_id else ""

    # 格式化时间
    start_time_raw = instance.get("start_time", 0)
    end_time_raw = instance.get("end_time", 0)

    # 状态 — 可能返回字符串 (PENDING/APPROVED) 或数字
    status_raw = instance.get("status", "0")
    if isinstance(status_raw, str):
        status_code = STATUS_STR_MAP.get(status_raw.upper(), 0)
    else:
        try:
            status_code = int(status_raw)
        except (ValueError, TypeError):
            status_code = 0

    # 对日期类字段值进行格式化
    for name, val in fields.items():
        if isinstance(val, str) and "T" in val:
            fields[name] = _format_iso_date(val)

    return {
        "instance_code": instance.get("instance_code", instance_code),
        "serial_no": instance.get("serial_number", "") or instance.get("instance_code", ""),
        "definition_name": instance.get("definition_name", ""),
        "initiator_name": initiator_name,
        "department_name": department_name,
        "instance_status": status_code,
        "status_label": INSTANCE_STATUS.get(status_code, "未知"),
        "start_time": start_time_raw,
        "end_time": end_time_raw,
        "form": form_data,
        "fields": fields,
        "comment_list": comment_list,
        "timeline": timeline,
        "attachments": attachments,
    }


def format_instance_summary(instance: dict, index: int) -> str:
    """格式化审批实例摘要为一行文本"""
    # 从 summaries 中提取金额
    amount = ""
    for s in instance.get("summaries", []):
        if "金额" in s.get("name", ""):
            amount = s.get("text", "")
            break

    status = instance.get("status_label", "未知")
    name = instance.get("definition_name", "") or instance.get("approval_name", "")
    initiator = instance.get("initiator_name", "我")

    parts = [f"{index}. {instance['instance_code'][:12] if instance.get('instance_code') else '-'}"]
    if name:
        parts.append(name)
    if amount:
        parts.append(f"¥{amount}")
    parts.append(status)
    parts.append(initiator)

    return "  ".join(parts)


if __name__ == "__main__":
    # 快速自测：搜索审批定义
    print("=== 搜索审批定义 ===")
    results = search_approval_definitions("采购")
    print(json.dumps(results, ensure_ascii=False, indent=2))
