"""
交互卡片构建器 — 生成飞书交互卡片 JSON

飞书卡片文档: https://open.feishu.cn/document/uAjLw4CM/ukzMukzMukzM/feishu-cards/card-components
"""

import json


def build_type_selector_card(definitions: list[dict]) -> dict:
    """
    审批类型选择卡片
    当用户输入中未指定审批类型，或搜索到多个匹配时使用

    Args:
        definitions: [{"approval_code": "...", "approval_name": "..."}, ...]
    """
    if not definitions:
        return {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": "未找到审批类型"},
                "template": "red",
            },
            "elements": [
                {"tag": "div", "text": {"tag": "lark_md", "content": "没有找到可打印的审批类型，请检查审批名称是否正确。"}}
            ],
        }

    actions = []
    for d in definitions[:5]:  # 最多显示 5 个
        actions.append({
            "tag": "button",
            "text": {"tag": "plain_text", "content": d.get("approval_name", "未知审批")},
            "type": "primary",
            "value": json.dumps({"action": "select_type", "code": d.get("approval_code", ""), "name": d.get("approval_name", "")}, ensure_ascii=False),
        })

    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "请选择要打印的审批类型"},
            "template": "blue",
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": f"找到 **{len(definitions)}** 个匹配的审批类型，请点击选择："}},
            {"tag": "action", "actions": actions},
            {"tag": "hr"},
            {"tag": "note", "elements": [{"tag": "plain_text", "content": "提示：也可以直接输入「打印XX审批」来快速定位"}]},
        ],
    }


def build_preview_card(
    definition_name: str,
    instances: list[dict],
    date_range_label: str,
) -> dict:
    """
    预览确认卡片 — 展示待打印审批列表

    Args:
        definition_name: 审批类型名称
        instances: 审批实例列表
        date_range_label: 日期范围描述，如 "2026年7月"
    """
    total = len(instances)

    if total == 0:
        return {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": f"{definition_name} — {date_range_label}"},
                "template": "yellow",
            },
            "elements": [
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**{date_range_label}** 期间没有符合打印条件的审批记录。"}},
            ],
        }

    # 构建摘要列表
    lines = [f"**共 {total} 条审批记录**（仅显示前 8 条）\n"]
    for i, inst in enumerate(instances[:8]):
        code = inst.get("instance_code", "-")[:16]
        status = inst.get("status_label", "未知")
        name = inst.get("definition_name", "")
        initiator = inst.get("initiator_name", "")
        # 提取金额
        amount_str = ""
        for s in inst.get("summaries", []):
            if "金额" in s.get("name", ""):
                amount_str = f" ¥{s.get('text', '')}"
                break

        status_emoji = {"已通过": "✅", "进行中": "⏳", "已拒绝": "❌", "已撤销": "↩️"}.get(status, "📋")
        lines.append(f"{status_emoji} {i+1}. {code} {amount_str}  {initiator}")

    # 超过 8 条的提示
    if total > 8:
        lines.append(f"\n...及其他 {total - 8} 条记录")

    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": f"批量打印预览 — {definition_name}"},
            "template": "blue",
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": "\n".join(lines)}},
            {"tag": "hr"},
            {"tag": "div", "text": {"tag": "lark_md", "content": f"📅 日期范围：{date_range_label}"}},
            {"tag": "action", "actions": [
                {
                    "tag": "button",
                    "text": {"tag": "plain_text", "content": f"确认打印（{total}条）"},
                    "type": "primary",
                    "value": json.dumps({"action": "confirm_print", "count": total}, ensure_ascii=False),
                    "confirm": {
                        "title": {"tag": "plain_text", "content": "确认批量打印？"},
                        "text": {"tag": "plain_text", "content": f"将为 {total} 条审批生成 PDF 文件，预计需要几秒到几分钟。"},
                    },
                },
                {
                    "tag": "button",
                    "text": {"tag": "plain_text", "content": "取消"},
                    "type": "default",
                    "value": json.dumps({"action": "cancel"}, ensure_ascii=False),
                },
            ]},
            {"tag": "note", "elements": [{"tag": "plain_text", "content": "提示：已自动跳过「已撤销」的审批记录"}]},
        ],
    }


def build_progress_card(
    definition_name: str,
    current: int,
    total: int,
    current_code: str = "",
) -> dict:
    """
    处理进度卡片

    Args:
        definition_name: 审批类型名称
        current: 当前处理序号
        total: 总数
        current_code: 当前处理的审批编号
    """
    pct = int(current / total * 100) if total > 0 else 0
    bar_width = 20
    filled = int(bar_width * current / total) if total > 0 else 0
    bar = "█" * filled + "░" * (bar_width - filled)

    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": f"生成 PDF 中... — {definition_name}"},
            "template": "blue",
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": f"```\n[{bar}] {current}/{total} ({pct}%)\n```"}},
            {"tag": "div", "text": {"tag": "lark_md", "content": f"当前处理: {current_code}"}},
            {"tag": "note", "elements": [{"tag": "plain_text", "content": "处理完成后会自动推送 PDF 文件"}]},
        ],
    }


def build_result_card(
    definition_name: str,
    success_count: int,
    fail_count: int,
    total: int,
) -> dict:
    """
    结果汇总卡片

    Args:
        definition_name: 审批类型名称
        success_count: 成功生成数
        fail_count: 失败数
        total: 总数
    """
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": f"打印完成 — {definition_name}"},
            "template": "green" if fail_count == 0 else "yellow",
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": f"✅ 成功生成：**{success_count}** 个 PDF\n❌ 失败：**{fail_count}** 个\n📊 总计：**{total}** 条"}},
            {"tag": "hr"},
            {"tag": "div", "text": {"tag": "lark_md", "content": "PDF 文件将陆续发送，请查收。"}},
        ],
    }
