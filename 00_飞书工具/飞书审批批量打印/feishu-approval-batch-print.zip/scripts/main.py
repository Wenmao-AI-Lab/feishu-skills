#!/usr/bin/env python3
"""
飞书审批批量打印机器人 — 主入口

用法:
  # 交互模式 — 传入用户消息
  python main.py --message "批量打印采购审批 7月"

  # 直接查询模式
  python main.py --definition-code XXX --start 2026-07-01 --end 2026-07-31

  # 列出可打印的审批类型
  python main.py --list-types "采购"

流程:
  用户消息 → 指令解析 → 搜索审批定义 → 查询实例 → 预览确认 → 生成PDF → 推送结果
"""

import argparse
import json
import sys
import os
from datetime import datetime, timezone, timedelta

# 确保项目根目录在 path 中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import PAGE_SIZE, INSTANCE_STATUS, LARK_CLI
from handlers.command_parser import parse_command
from handlers.approval_query import (
    search_approval_definitions,
    query_initiated_instances,
    get_instance_detail,
    _run_lark,
)
from handlers.card_builder import (
    build_type_selector_card,
    build_preview_card,
    build_result_card,
)
from handlers.pdf_generator import generate_batch_pdfs

TZ_CST = timezone(timedelta(hours=8))


def parse_date_str(date_str: str) -> int:
    """将 YYYY-MM-DD 格式转为秒级时间戳"""
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=TZ_CST)
    return int(dt.timestamp())


class PrintSession:
    """单次打印会话的状态管理"""
    def __init__(self):
        self.approval_code: str | None = None
        self.approval_name: str | None = None
        self.start_ts: int | None = None
        self.end_ts: int | None = None
        self.instances: list = []
        self.instances_detail: list = []
        self.state: str = "init"  # init → preview → printing → done


def step_search_definitions(keyword: str) -> dict:
    """
    步骤1：搜索审批定义

    Returns:
        {"ok": bool, "type": "single"|"multiple"|"none", ...}
    """
    definitions = search_approval_definitions(keyword)

    if not definitions:
        return {"ok": False, "type": "none", "message": f"未找到与「{keyword}」相关的审批类型"}

    # 过滤掉三方定义
    native_defs = [d for d in definitions if not d.get("is_external")]
    if not native_defs:
        return {
            "ok": False,
            "type": "none",
            "message": f"找到的「{keyword}」相关审批均为外部审批，暂不支持打印",
        }

    if len(native_defs) == 1:
        return {"ok": True, "type": "single", "definitions": native_defs}
    else:
        return {"ok": True, "type": "multiple", "definitions": native_defs}


def step_query_instances(
    approval_code: str,
    approval_name: str,
    start_ts: int,
    end_ts: int,
) -> dict:
    """
    步骤2：查询审批实例列表
    """
    instances = query_initiated_instances(
        definition_code=approval_code,
        start_ts=start_ts,
        end_ts=end_ts,
    )
    return {
        "ok": True,
        "approval_name": approval_name,
        "instances": instances,
        "total": len(instances),
        "start_ts": start_ts,
        "end_ts": end_ts,
    }


def step_generate_pdfs(instances: list[dict], approval_name: str = "") -> dict:
    """
    步骤3：批量生成 PDF
    """
    # 逐条获取详情
    details = []
    for inst in instances:
        detail = get_instance_detail(inst["instance_code"])
        if detail:
            details.append(detail)
        else:
            details.append(inst)  # 回退到列表数据

    # 批量生成 PDF
    pdf_paths = generate_batch_pdfs(details, approval_name=approval_name)

    return {
        "ok": True,
        "pdf_paths": pdf_paths,
        "total": len(instances),
        "success": len(pdf_paths),
        "fail": len(instances) - len(pdf_paths),
    }


def format_date_range(start_ts: int, end_ts: int) -> str:
    """格式化日期范围为人可读格式"""
    start_date = datetime.fromtimestamp(start_ts, tz=TZ_CST)
    end_date = datetime.fromtimestamp(end_ts, tz=TZ_CST)

    if start_date.month == end_date.month:
        return f"{start_date.year}年{start_date.month}月"
    else:
        return f"{start_date.strftime('%Y-%m-%d')} 至 {end_date.strftime('%Y-%m-%d')}"


def process_message_command(message: str) -> dict:
    """
    处理用户消息，完整流程

    返回格式:
    {
        "ok": bool,
        "step": "type_selection" | "preview" | "printing" | "done" | "error",
        "card": dict | None,         # 飞书交互卡片
        "message": str | None,       # 纯文本消息
        "result": dict | None,       # 结构化结果
    }
    """
    # 1. 解析指令
    parsed = parse_command(message)

    if parsed.errors:
        return {"ok": False, "step": "error", "message": "；".join(parsed.errors)}

    # 2. 确定日期范围
    start_ts = parsed.start_ts
    end_ts = parsed.end_ts
    date_label = format_date_range(start_ts, end_ts)

    # 3. 是否需要选择审批类型
    if parsed.needs_type_selection:
        return {
            "ok": True,
            "step": "type_selection",
            "message": "请告诉我需要打印哪种审批？例如：采购审批、报销审批、请假审批...",
        }

    # 4. 搜索审批定义
    search_result = step_search_definitions(parsed.type_keyword)

    if not search_result["ok"]:
        return {
            "ok": False,
            "step": "error",
            "message": search_result.get("message", "搜索审批类型失败"),
        }

    # 5. 多个结果 → 返回选择卡片
    if search_result["type"] == "multiple":
        card = build_type_selector_card(search_result["definitions"])
        return {"ok": True, "step": "type_selection", "card": card, "message": None}

    # 6. 单个结果 → 查询实例
    definition = search_result["definitions"][0]
    approval_code = definition["approval_code"]
    approval_name = definition["approval_name"]

    query_result = step_query_instances(
        approval_code=approval_code,
        approval_name=approval_name,
        start_ts=start_ts,
        end_ts=end_ts,
    )

    instances = query_result["instances"]

    # 7. 无实例
    if not instances:
        return {
            "ok": True,
            "step": "done",
            "message": f"「{approval_name}」在 {date_label} 期间没有符合打印条件的审批记录。",
        }

    # 8. 返回预览卡片
    card = build_preview_card(
        definition_name=approval_name,
        instances=instances,
        date_range_label=date_label,
    )

    return {
        "ok": True,
        "step": "preview",
        "card": card,
        "message": None,
        "result": {
            "approval_code": approval_code,
            "approval_name": approval_name,
            "instances": instances,
            "start_ts": start_ts,
            "end_ts": end_ts,
        },
    }


def confirm_and_print(instances: list[dict], approval_name: str) -> dict:
    """
    确认后执行打印

    Returns:
        包含 PDF 路径列表的结果
    """
    print(f"\n{'='*50}")
    print(f"开始批量打印「{approval_name}」共 {len(instances)} 条审批")
    print(f"{'='*50}")

    result = step_generate_pdfs(instances, approval_name=approval_name)

    print(f"{'='*50}")
    print(f"打印完成: 成功 {result['success']}/{result['total']}")
    if result["fail"] > 0:
        print(f"失败: {result['fail']} 条")
    print(f"{'='*50}")

    return result


def list_available_types(keyword: str = "") -> dict:
    """列出可用的审批类型"""
    if keyword:
        definitions = search_approval_definitions(keyword)
    else:
        # 搜索常用类型
        definitions = []
        for kw in ["采购", "报销", "请假", "出差", "加班", "合同", "用章"]:
            defs = search_approval_definitions(kw)
            definitions.extend(defs)

    # 去重（按 approval_code）
    seen = set()
    unique = []
    for d in definitions:
        if d["approval_code"] not in seen:
            seen.add(d["approval_code"])
            unique.append(d)

    return {
        "ok": True,
        "definitions": unique,
        "total": len(unique),
    }


def main():
    parser = argparse.ArgumentParser(
        description="飞书审批批量打印机器人",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python main.py --message "批量打印采购审批 7月"
  python main.py --message "打印最近3天的报销单"
  python main.py --definition-code XXX --start 2026-07-01 --end 2026-07-31
  python main.py --list-types "采购"
        """,
    )
    parser.add_argument("--message", "-m", type=str, help="用户消息文本")
    parser.add_argument("--definition-code", type=str, help="直接指定审批定义 code")
    parser.add_argument("--start", type=str, help="起始日期 (YYYY-MM-DD)")
    parser.add_argument("--end", type=str, help="结束日期 (YYYY-MM-DD)")
    parser.add_argument("--list-types", type=str, nargs="?", const="", help="列出可打印的审批类型")
    parser.add_argument("--no-confirm", action="store_true", help="跳过确认，直接打印")
    parser.add_argument("--output-json", action="store_true", help="以 JSON 格式输出")

    args = parser.parse_args()

    # 命令1: 列出审批类型
    if args.list_types is not None:
        result = list_available_types(args.list_types or "")
        if args.output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"\n找到 {result['total']} 个可打印的审批类型：")
            for d in result["definitions"]:
                external = " [外部]" if d.get("is_external") else ""
                print(f"  • {d['approval_name']}{external}  (code: {d['approval_code'][:20]}...)")
        return

    # 命令2: 直接指定参数
    if args.definition_code and args.start and args.end:
        start_ts = parse_date_str(args.start)
        end_ts = parse_date_str(args.end)

        # 通过 API 查询审批定义获取真实名称
        approval_name = args.definition_code
        try:
            get_result = _run_lark([
                LARK_CLI, "approval", "approvals", "get",
                "--approval-code", args.definition_code,
                "--as", "user",
            ])
            if get_result.get("ok"):
                def_data = get_result.get("data", {})
                approval_name = def_data.get("approval_name") or def_data.get("name") or approval_name
        except Exception:
            pass

        result = step_query_instances(
            approval_code=args.definition_code,
            approval_name=approval_name,
            start_ts=start_ts,
            end_ts=end_ts,
        )

        if not result["instances"]:
            print("没有找到审批实例")
            return

        if not args.no_confirm:
            print(f"找到 {result['total']} 条审批记录")
            confirm = input("确认打印？(y/n): ")
            if confirm.lower() != "y":
                print("已取消")
                return

        print_result = confirm_and_print(result["instances"], approval_name)
        if args.output_json:
            print(json.dumps(print_result, ensure_ascii=False, indent=2))
        else:
            print(f"\nPDF 已生成到 output/ 目录")
            for path in print_result.get("pdf_paths", []):
                print(f"  {path}")
        return

    # 命令3: 消息处理
    if args.message:
        result = process_message_command(args.message)

        if args.output_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return

        if result["step"] == "error":
            print(f"❌ {result.get('message', '处理失败')}")
            return

        if result["step"] == "type_selection":
            print(f"🤖 {result.get('message', '请选择审批类型')}")
            if result.get("card"):
                print("\n— 交互卡片 —")
                print(json.dumps(result["card"], ensure_ascii=False, indent=2))
            return

        if result["step"] == "preview":
            print("📋 预览卡片已生成：")
            if result.get("card"):
                print(json.dumps(result["card"], ensure_ascii=False, indent=2))
            print()

            if args.no_confirm:
                instances = result.get("result", {}).get("instances", [])
                approval_name = result.get("result", {}).get("approval_name", "")
                confirm_and_print(instances, approval_name)
            return

        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    parser.print_help()


if __name__ == "__main__":
    main()
