"""
飞书审批批量打印机器人 - 应用配置
"""

import os
import json
from pathlib import Path

# 项目根目录（scripts/ 的父目录）
PROJECT_ROOT = Path(__file__).parent.parent

# 技能根目录（scripts/ 目录）
SCRIPTS_DIR = Path(__file__).parent

# 模板目录（assets/templates/）
TEMPLATE_DIR = PROJECT_ROOT / "assets" / "templates"

# 输出目录
OUTPUT_DIR = Path(os.environ.get("APPROVAL_PRINT_OUTPUT", SCRIPTS_DIR / "output"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 飞书 CLI 路径 (通过 AI助手 环境可用)
LARK_CLI = "lark-cli"

# 审批实例状态枚举
INSTANCE_STATUS = {
    0: "无状态",
    1: "进行中",
    2: "已通过",
    3: "已拒绝",
    4: "已撤销",
    5: "已终止",
}

# 字符串状态映射（飞书 API 可能返回字符串状态）
STATUS_STR_MAP = {
    "PENDING":    1,  # 审批中
    "APPROVED":   2,  # 已通过
    "REJECTED":   3,  # 已拒绝
    "CANCELED":   4,  # 已撤销
    "TERMINATED": 5,  # 已终止
    "DELETED":    6,  # 已删除
}

# 需要跳过的状态（不打印）
SKIP_STATUSES = {4}  # 已撤销

# 每页查询数量
PAGE_SIZE = 50

# 最大打印数量（防止一次打印过多）
MAX_PRINT_COUNT = 100

# 支持的审批类型关键词映射
TYPE_KEYWORDS = {
    "采购": ["采购", "购买", "下单"],
    "报销": ["报销", "差旅", "费用"],
    "请假": ["请假", "休假", "调休", "年假", "事假", "病假"],
    "出差": ["出差", "差旅外出"],
    "加班": ["加班"],
    "合同": ["合同", "协议"],
    "用章": ["用章", "盖章"],
}


def get_month_timestamps(year: int, month: int) -> tuple:
    """获取指定年月的起止时间戳（秒级）"""
    import calendar
    from datetime import datetime, timezone, timedelta

    tz = timezone(timedelta(hours=8))  # CST
    start = int(datetime(year, month, 1, tzinfo=tz).timestamp())
    last_day = calendar.monthrange(year, month)[1]
    end = int(datetime(year, month, last_day, 23, 59, 59, tzinfo=tz).timestamp())
    return start, end


def resolve_type_from_input(text: str) -> str | None:
    """从用户输入中识别审批类型关键词"""
    for category, keywords in TYPE_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                return kw
    return None
