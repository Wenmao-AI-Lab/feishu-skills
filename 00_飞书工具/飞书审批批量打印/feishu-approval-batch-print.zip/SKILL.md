---
name: feishu-approval-batch-print
description: "飞书审批批量打印。通过自然语言指令在飞书中批量查询、预览并打印个人发起的审批单据为 PDF。当用户需要在飞书中打印审批单、将审批记录导出 PDF 时使用。触发词：批量打印审批、打印审批单、审批导出PDF、打印XX审批、打印最近N天审批。"
agent_created: true
---

# 飞书审批批量打印

## 概述

通过自然语言指令在飞书中批量打印个人发起的审批单据。解析用户指令 → 搜索审批定义 → 查询实例列表 → 生成预览卡片 → 一键生成 PDF。

仅支持打印**当前用户自己发起**的审批实例（通过 `approval instances initiated` API）。

## 触发条件

当用户提及以下任一场景时使用本技能：

- "批量打印审批" / "打印审批单"
- "打印 XX 审批"（如：打印采购审批、打印报销审批）
- "打印最近 N 天的 XX 审批"
- "打印 X 月的 XX 审批"
- "审批导出 PDF"

## 工作流程

### 步骤 1：解析用户指令

使用 `scripts/handlers/command_parser.py` 中的 `parse_command()` 从用户消息中提取：
- 审批类型关键词（采购、报销、请假、出差、加班等）
- 日期范围（月份、日期范围、最近N天、今天/本周）

支持的指令格式：

| 格式 | 示例 |
|------|------|
| 审批类型 + 月份 | `批量打印采购审批 7月` |
| 审批类型 + 日期范围 | `打印6.1-6.30的报销单` |
| 审批类型 + 最近N天 | `打印最近3天的请假审批` |
| 审批类型 + 今天/本周 | `打印今天的加班审批` |
| 无类型 | `打印审批`（需二次确认） |

若 command_parser 无法识别审批类型（如"售货机付款申请"等自定义审批），直接使用 `--definition-code` 和 `--start` / `--end` 参数跳过解析步骤。

### 步骤 2：搜索审批定义

通过 lark-cli 搜索审批定义：

```bash
lark-cli approval approvals search --data '{"keyword":"<关键词>"}' --as user
```

- 使用 `scripts/handlers/approval_query.py` 中的 `search_approval_definitions()`
- 过滤掉三方审批定义（`is_external=true`）
- 单个结果 → 直接进入步骤 3
- 多个结果 → 调用 `scripts/handlers/card_builder.py` 中的 `build_type_selector_card()` 生成选择卡片
- 无结果 → 提示用户换关键词

### 步骤 3：查询审批实例

```bash
lark-cli approval instances initiated \
  --params '{"definition_code":"<CODE>","start_timestamp":"<TS>","end_timestamp":"<TS>","page_size":50}' \
  --as user
```

- 使用 `scripts/handlers/approval_query.py` 中的 `query_initiated_instances()`
- 自动跳过 `instance_status=4`（已撤销）的记录
- 最多查询 100 条
- 支持分页（通过 `page_token`）

**获取实例详情时的关键处理：**

| 功能 | 实现 |
|------|------|
| 用户姓名 & 部门 | 通过 `lark-cli contact +search-user` 查询 `localized_name` 和 `department` |
| 操作记录 → 时间线 | `_format_timeline()` 将 `operation_records` 转为含中文标签的时间线 |
| 字段值格式化 | `_format_field_value()` 递归解析嵌套 JSON、列表、收款账户 widget |
| mutableGroup 字段 | 展开内嵌 widget 注入到 `fields` 字典（解决费用分类等字段缺失） |
| 审批状态 | 兼容数字（0/1/2/3/4）和字符串（"PENDING"/"APPROVED"/"REJECTED"） |
| 评论附件 | `_extract_comment_attachments()` 从评论 `files` 字段提取附件 |
| 表单附件 | `_extract_attachments()` 下载 `attachmentV2` 和 `image` 类型字段 |
| 时间戳处理 | 自动识别秒/毫秒（> 1e12 时除以 1000），格式化为 `YYYY-MM-DD HH:MM` |

### 步骤 4：生成预览卡片

调用 `scripts/handlers/card_builder.py` 中的 `build_preview_card()` 生成飞书交互卡片，包含：
- 审批类型名称、日期范围
- 实例摘要列表（编号、金额、发起人、状态）
- 「确认打印」和「取消」按钮

### 步骤 5：用户确认后生成 PDF

用户点击确认后，执行以下操作：

1. 调用 `scripts/handlers/approval_query.py` 中的 `get_instance_detail()` 逐条获取实例详情
2. 调用 `scripts/handlers/pdf_generator.py` 中的 `generate_batch_pdfs()` 批量生成 PDF
   - 通过 Jinja2 渲染 `assets/templates/` 中的 HTML 模板
   - 默认使用 `default_template.html`，支持按审批名称自动匹配专用模板
   - **PDF 文件命名规则**：`{审批类型}_{serial_number}.pdf`（如 `售货机付款申请_202608030009.pdf`，serial_number 取自飞书审批系统编号）
3. 输出到 `scripts/output/` 目录

**HTML → PDF 转换降级链（内置，无需手动干预）：**
1. WeasyPrint（优先）
2. pdfkit（备用）
3. **Chrome headless**（自动检测路径，macOS/Linux/Windows 全平台支持）

**附件合并策略（内置）：**
| 附件类型 | 处理方式 |
|----------|----------|
| 图片 (PNG/JPG) | base64 嵌入 HTML，Chrome 渲染为 PDF 页面 |
| PDF 文档 | 直接从 base64 解码，使用 pypdf 合并到末尾 |
| Excel (xlsx) | openpyxl 读取每个 sheet → 渲染为独立 HTML 表格（支持合并单元格、千分位数字） → Chrome 转 PDF → pypdf 合并 |

### 步骤 6：输出结果

- 使用 `scripts/handlers/card_builder.py` 中的 `build_result_card()` 生成结果汇总卡片
- 显示成功/失败数量
- PDF 文件路径列表

## 快速使用

### 命令行方式

```bash
# 进入技能脚本目录
cd scripts/

# 自然语言指令
python main.py --message "批量打印采购审批 7月"

# 跳过确认直接打印
python main.py --message "打印报销审批 6月" --no-confirm

# 直接指定参数（command_parser 无法识别自定义审批名称时用此方式）
python main.py --definition-code <CODE> --start 2026-07-01 --end 2026-07-31

# 列出可打印的审批类型
python main.py --list-types "采购"
```

### 作为技能调用

用户输入消息后，技能自动：
1. 解析消息提取审批类型和日期
2. 查询审批实例
3. 返回预览卡片
4. 等待用户确认后生成 PDF

如果 `main.py --message` 返回「请告诉我需要打印哪种审批」，说明 command_parser 无法识别审批名称，改为直接用 `--definition-code` 指定（从对话历史或搜索结果获取 code）。

## 脚本说明

### scripts/main.py
主入口，组装完整处理流程。读取 `--message` 参数，依次调用解析、查询、预览、生成模块。

### scripts/handlers/command_parser.py
自然语言指令解析器。`parse_command(text)` 返回 `CommandParseResult`，包含审批类型关键词和日期时间戳范围。支持常见审批类型（采购、报销、请假、出差、加班等），但对自定义审批名称可能需要直接指定 `--definition-code`。

### scripts/handlers/approval_query.py
飞书审批 API 查询模块。封装 lark-cli 调用：
- `search_approval_definitions(keyword)` — 搜索审批定义
- `query_initiated_instances(code, start_ts, end_ts)` — 查询发起实例列表
- `get_instance_detail(instance_code)` — 获取实例详情
- `_lookup_user_name(user_id)` — 通过 `contact +search-user` 获取用户名
- `_format_field_value(value)` — 递归格式化字段值（JSON/列表/收款账户等）
- `_extract_attachments(form_data)` — 提取表单附件（attachmentV2 + image）
- `_extract_comment_attachments(comment_list)` — 提取评论附件
- `_format_timeline(ops)` — 操作记录转时间线
- `_download_attachment(url)` — 下载并区分附件类型

### scripts/handlers/pdf_generator.py
PDF 生成器。核心函数：
- `generate_pdf(instance, output_name)` — 单个实例 → PDF
- `generate_batch_pdfs(instances)` — 批量生成
- `_render_html(instance)` — Jinja2 模板渲染，附带附件列表
- `_match_template(approval_name)` — 模板自动匹配（精确 + 模糊）
- `_format_ts(ts, fmt)` — 时间戳格式化（自动识别秒/毫秒）
- `_find_chrome()` — 跨平台 Chrome 路径检测（macOS/Linux/Windows）
- `_html_to_pdf_chrome(html_path, pdf_path)` — Chrome headless HTML→PDF

HTML→PDF 降级链（全内置）：WeasyPrint → pdfkit → Chrome headless → 返回 HTML

### scripts/handlers/card_builder.py
飞书交互卡片构建器：
- `build_type_selector_card()` — 类型选择
- `build_preview_card()` — 预览确认
- `build_progress_card()` — 处理进度
- `build_result_card()` — 结果汇总

## 模板自定义

在 `assets/templates/` 下放置 HTML 文件。模板文件名关键词与审批类型名称匹配：
- `采购审批模板.html` → 精确匹配"采购审批"
- 无匹配时使用 `default_template.html`

模板变量：`{{ title }}`, `{{ fields }}`, `{{ status }}`, `{{ initiator }}`, `{{ instance_code }}`, `{{ print_time }}`, `{{ timeline }}`, `{{ comment_list }}`, `{{ attachments }}`

## 环境要求

### 运行环境
- **Python** 3.10+
- **Node.js** 18+（用于 Puppeteer / Chrome headless PDF 渲染）

### Python 依赖

安装方式一（推荐，使用 requirements.txt）：

```bash
pip install -r requirements.txt
```

安装方式二（手动指定）：

```bash
pip install jinja2 pypdf openpyxl python-dateutil
```

可选依赖（HTML→PDF 降级链备用，非必需）：

```bash
pip install weasyprint     # 降级链第一选项（macOS 需额外 brew install weasyprint）
pip install pdfkit         # 降级链第二选项（需额外 brew install wkhtmltopdf）
```

### Node.js 依赖

需要安装 puppeteer（Chrome headless PDF 渲染核心）：

```bash
npm install puppeteer
# 或全局安装
npm install -g puppeteer
```

脚本会自动检测 puppeteer 所在路径（支持全局安装、本地安装、nvm 等多种场景）。

### 系统依赖
- **Google Chrome** 或 **Chromium**（HTML→PDF 渲染，跨平台自动检测路径）
- **lark-cli**（飞书 CLI，需配置飞书应用认证）

### 飞书权限要求

需要在飞书应用中开通以下 scope：

- `approval:approval:read` — 搜索审批定义
- `approval:instance:read` — 查询审批实例
- `contact:user.basic_profile:readonly` — 查询用户姓名和部门

通过 `lark-cli auth login --scope "<scope>"` 授权。

## 常见问题

### WeasyPrint 报错 "cannot load library libgobject-2.0-0"

macOS venv 环境下 WeasyPrint 常无法找到系统动态库。代码已内置自动降级，会依次尝试 pdfkit 和 Chrome headless。无需手动干预。

如需根治，安装系统级 WeasyPrint：`brew install weasyprint`

### 打印出的 PDF 缺少申请人姓名/部门

检查是否已授权 `contact:user.basic_profile:readonly` scope，重新扫码授权：
```bash
lark-cli auth login --scope "approval:approval:read approval:instance:read contact:user.basic_profile:readonly"
```

### 费用分类或项目名称为空

部分审批定义的字段嵌套在 `mutableGroup` widget 结构中。`get_instance_detail()` 已自动展开处理。如果仍然缺失，检查 `form` 原始 JSON 确认字段路径。

### Excel 附件未打印到 PDF

确认已安装 `openpyxl` 和 `pypdf`：`pip install openpyxl pypdf`
