# 飞书对话排版 · 对照示例

## 示例 1：新闻科普

### 输入

```markdown
# 蚊子学会了无视驱蚊水？

每到夏天，购买带有避蚊胺（DEET）的驱蚊剂，是很多人对抗蚊子的「标配」。

> 那只咬你的蚊子，可能不是不怕驱蚊水，而是学会了无视它。

## 正确做法

- **定时补涂**
- 不要一次性大量涂抹
```

### 输出

【蚊子学会了无视驱蚊水？】

每到夏天，DEET 驱蚊水是很多人的标配。
但喷了仍被咬，很常见。

「那只咬你的蚊子，可能不是不怕驱蚊水，而是学会了无视它。」

■ 正确做法

· 定时补涂
· 不要一次性大量涂抹

——
撰文 / 张佳欣 | 来源 / 科技日报

---

## 示例 2：工作汇报

### 输入

项目本周进展：**前端完成 80%**，后端接口还有 3 个 blocker。建议下周一联调。

### 输出

【项目周报】

■ 进展

· 前端完成 80%
· 后端仍有 3 个 blocker

■ 建议

下周一启动联调。

---

## 示例 3：超短版（随手转发）

### 输入

同上蚊子文章 + 用户要求「超短」

### 输出

【蚊子学会无视驱蚊水了】

科学家用巴甫洛夫训练法发现：蚊子重复接触低浓度避蚊胺后，反而会主动飞向涂了药的手臂。

结论：避蚊胺还要用，但一定要定时补涂。

——

---

## 示例 4：英文长文（演示长句拆短 + 缩写不误判）

### 输入

```markdown
Our Q3 retention dropped to 42%, which is below the 50% target we set in January, and although the product team shipped the onboarding redesign that was supposed to fix the leak, new users still churn before day 7 because the welcome email — e.g. the one sent at signup — never actually triggers for about 1 in 3 signups.

> Fix the email before chasing new features.
```

### 输出

【Q3 Retention Slipped to 42%】

Q3 retention dropped to 42%, below the 50%
target we set in January. The product team
shipped the onboarding redesign that was
supposed to fix the leak.

But new users still churn before day 7. The
welcome email — e.g. the one sent at signup —
never actually triggers for about 1 in 3
signups.

"Fix the email before chasing new features."

——

要点：约 60 词的长复合句被拆成 4 句、分两段，原文信息零删除；`e.g.` 的点没被断行；em dash `—` 作句内插入保留；每段 1–3 句；符号用 `【】" "`。