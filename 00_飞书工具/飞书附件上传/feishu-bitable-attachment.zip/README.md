# Feishu Bitable Attachment Skill

Upload files to Feishu (Lark) Bitable attachment fields.

## Quick Start

### 1. Set Environment Variables

```bash
export FEISHU_APP_ID=your_app_id
export FEISHU_APP_SECRET=your_app_secret
export FEISHU_BASE_URL=https://open.feishu.cn  # optional
```

### 2. Prepare Input JSON

Create a payload file (see `payload.*.json` for examples):

```json
{
  "target": {
    "app_token": "bascxxxxxxxxxxxxx",
    "table_id": "tblxxxxxxxxxx",
    "record_id": "recxxxxxxxxxx",
    "field_name": "附件"
  },
  "source": {
    "type": "local",
    "ref": "/path/to/file.pdf"
  },
  "append": true
}
```

### 3. Run

```bash
python scripts/main.py --input payload.local.json
```

## Supported Source Types

| Type | Description | Example |
|------|-------------|---------|
| `local` | Local file path | `{"type": "local", "ref": "/tmp/file.pdf"}` |
| `url` | Download from URL | `{"type": "url", "ref": "https://example.com/file.pdf"}` |
| `feishu_message` | Feishu message attachment | `{"type": "feishu_message", "ref": {"file_key": "file_xxx"}}` |

## Target Resolution

The skill supports flexible target specification:

- **Table**: Provide `table_id` directly OR `table_name` for automatic lookup
- **Field**: Provide `field_id` directly OR `field_name` for automatic lookup
- **Record**: Provide `record_id`, use `lookup` to search, or omit to create new record

## Examples

See payload files for complete examples:

- `payload.local.json` - Upload local file
- `payload.url.json` - Download from URL and upload
- `payload.feishu_message.json` - Upload Feishu message attachment
- `payload.table_name.json` - Auto-resolve table by name
- `payload.lookup.json` - Lookup record by field value
- `payload.create_record.json` - Create new record with attachment

## Output

```json
{
  "ok": true,
  "file_token": "vobxxxxxxxxxx",
  "app_token": "bascxxxxxxxxxx",
  "table_id": "tblxxxxxxxxxx",
  "record_id": "recxxxxxxxxxx",
  "field_name": "附件",
  "upload_type": "direct",
  "message": "Successfully uploaded..."
}
```

## Package

To create a distributable zip:

```bash
python package_skill.py
```

This generates `skill.zip` ready for upload.
