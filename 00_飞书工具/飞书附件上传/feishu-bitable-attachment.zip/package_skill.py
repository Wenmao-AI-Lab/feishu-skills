#!/usr/bin/env python3
"""
Package Feishu Bitable Attachment Skill into skill.zip

Usage:
    python package_skill.py

Output:
    skill.zip - Ready for upload
"""

import os
import zipfile
import shutil

SKILL_NAME = "feishu-bitable-attachment"
# ROOT_DIR is the skill directory itself (where this script lives)
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = ROOT_DIR  # The current directory is the skill root
# Output skill.zip to parent directory to avoid including it in the skill
OUTPUT_ZIP = os.path.join(os.path.dirname(ROOT_DIR), "skill.zip")

# Files and directories to include
INCLUDE_PATTERNS = [
    "SKILL.md",
    "agents/*.yaml",
    "scripts/*.py",
    "references/*.md",
    "payload.*.json",
]

# Directories to include
INCLUDE_DIRS = [
    "agents",
    "scripts",
    "references",
]

# Files to exclude
EXCLUDE_FILES = [
    "__pycache__",
    "*.pyc",
    ".DS_Store",
    "package_skill.py",
    "README.md",
    "self_check.py",
]


def should_exclude(path: str) -> bool:
    """Check if path should be excluded."""
    for pattern in EXCLUDE_FILES:
        if pattern in path:
            return True
    return False


def add_directory_to_zip(zipf: zipfile.ZipFile, dirpath: str, arcname: str):
    """Add directory to zip file recursively."""
    for root, dirs, files in os.walk(dirpath):
        # Filter out excluded directories
        dirs[:] = [d for d in dirs if not should_exclude(d)]

        for file in files:
            if should_exclude(file):
                continue

            file_path = os.path.join(root, file)
            arc_path = os.path.join(arcname, os.path.relpath(file_path, dirpath))

            # Skip __pycache__ and .pyc files
            if "__pycache__" in file_path or file.endswith(".pyc"):
                continue

            zipf.write(file_path, arc_path)
            print(f"  Added: {arc_path}")


def main():
    print(f"Packing skill: {SKILL_NAME}")
    print(f"Source directory: {SKILL_DIR}")
    print(f"Output file: {OUTPUT_ZIP}")

    # Remove existing zip if exists
    if os.path.exists(OUTPUT_ZIP):
        os.remove(OUTPUT_ZIP)
        print(f"Removed existing {OUTPUT_ZIP}")

    # Create zip file
    with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add SKILL.md (required)
        skill_md_path = os.path.join(SKILL_DIR, "SKILL.md")
        if os.path.exists(skill_md_path):
            zipf.write(skill_md_path, "SKILL.md")
            print(f"  Added: SKILL.md")
        else:
            print("  WARNING: SKILL.md not found!")

        # Add agents directory
        agents_dir = os.path.join(SKILL_DIR, "agents")
        if os.path.exists(agents_dir):
            add_directory_to_zip(zipf, agents_dir, "agents")

        # Add scripts directory
        scripts_dir = os.path.join(SKILL_DIR, "scripts")
        if os.path.exists(scripts_dir):
            add_directory_to_zip(zipf, scripts_dir, "scripts")

        # Add references directory
        references_dir = os.path.join(SKILL_DIR, "references")
        if os.path.exists(references_dir):
            add_directory_to_zip(zipf, references_dir, "references")

        # Add payload examples
        for filename in os.listdir(SKILL_DIR):
            if filename.startswith("payload.") and filename.endswith(".json"):
                file_path = os.path.join(SKILL_DIR, filename)
                zipf.write(file_path, filename)
                print(f"  Added: {filename}")

    # Verify zip
    print(f"\nVerifying {OUTPUT_ZIP}...")
    with zipfile.ZipFile(OUTPUT_ZIP, 'r') as zipf:
        file_list = zipf.namelist()
        print(f"Total files: {len(file_list)}")
        for f in sorted(file_list):
            print(f"  {f}")

    # Print size
    zip_size = os.path.getsize(OUTPUT_ZIP)
    print(f"\nPackage size: {zip_size / 1024:.2f} KB")
    print(f"\nDone! {OUTPUT_ZIP} is ready for upload.")


if __name__ == "__main__":
    main()
