#!/usr/bin/env python3
"""
Minimal self-check script for feishu-bitable-attachment Skill.

Runs basic verification tests without requiring Feishu credentials.

Usage:
    python self_check.py
"""

import sys
import os

# Add scripts directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "scripts"))

def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")

    try:
        from common import (
            SkillError, SkillInputError, SkillFileNotFoundError,
            SkillDownloadError, FeishuAuthError, FeishuUploadError,
            BitableResolveError, BitableUpdateError, FeishuAPIError,
        )
        print("  [OK] common.py imports OK")
    except Exception as e:
        print(f"  [FAIL] common.py import failed: {e}")
        return False

    try:
        from upload_to_bitable import upload_to_bitable, SkillFileNotFoundError
        print("  [OK] upload_to_bitable.py imports OK")
    except Exception as e:
        print(f"  [FAIL] upload_to_bitable.py import failed: {e}")
        return False

    try:
        from fetch_source_file import fetch_source_file
        print("  [OK] fetch_source_file.py imports OK")
    except Exception as e:
        print(f"  [FAIL] fetch_source_file.py import failed: {e}")
        return False

    try:
        from resolve_bitable_target import resolve_bitable_target
        print("  [OK] resolve_bitable_target.py imports OK")
    except Exception as e:
        print(f"  [FAIL] resolve_bitable_target.py import failed: {e}")
        return False

    try:
        from update_bitable_record import update_bitable_record
        print("  [OK] update_bitable_record.py imports OK")
    except Exception as e:
        print(f"  [FAIL] update_bitable_record.py import failed: {e}")
        return False

    return True


def test_file_not_found_error():
    """Test that nonexistent file raises SkillFileNotFoundError, not NameError."""
    print("\nTesting file not found error handling...")

    from upload_to_bitable import upload_to_bitable
    from common import SkillFileNotFoundError

    try:
        # Try to upload a file that doesn't exist
        upload_to_bitable(
            file_path="/nonexistent/path/file.txt",
            app_token="basc_test",
            app_id="test",
            app_secret="test",
            filename="test.txt"
        )
        print("  [FAIL] Expected SkillFileNotFoundError but no error was raised")
        return False
    except SkillFileNotFoundError as e:
        print(f"  [OK] SkillFileNotFoundError raised correctly: {e.message}")
        return True
    except NameError as e:
        print(f"  [FAIL] NameError raised (import issue): {e}")
        return False
    except Exception as e:
        print(f"  [FAIL] Unexpected error: {type(e).__name__}: {e}")
        return False


def test_input_validation():
    """Test input validation logic."""
    print("\nTesting input validation...")

    from resolve_bitable_target import resolve_bitable_target
    from common import SkillInputError

    # Test missing app_token
    try:
        resolve_bitable_target({}, "test_app_id", "test_secret")
        print("  [FAIL] Expected SkillInputError for missing app_token")
        return False
    except SkillInputError as e:
        print(f"  [OK] SkillInputError for missing app_token: {e.message}")

    # Test missing table
    try:
        resolve_bitable_target({"app_token": "basc_test"}, "test_app_id", "test_secret")
        print("  [FAIL] Expected SkillInputError for missing table")
        return False
    except SkillInputError as e:
        print(f"  [OK] SkillInputError for missing table: {e.message}")

    # Test missing field
    try:
        resolve_bitable_target({
            "app_token": "basc_test",
            "table_id": "tbl_test"
        }, "test_app_id", "test_secret")
        print("  [FAIL] Expected SkillInputError for missing field")
        return False
    except SkillInputError as e:
        print(f"  [OK] SkillInputError for missing field: {e.message}")

    return True


def test_payload_files():
    """Test that payload JSON files are valid."""
    print("\nTesting payload JSON files...")

    import json

    payload_files = [
        "payload.local.json",
        "payload.url.json",
        "payload.feishu_message.json",
        "payload.table_name.json",
        "payload.lookup.json",
        "payload.create_record.json",
    ]

    scripts_dir = os.path.join(os.path.dirname(__file__), "scripts")

    for filename in payload_files:
        filepath = os.path.join(scripts_dir, filename)
        if not os.path.exists(filepath):
            # Try parent directory
            filepath = os.path.join(os.path.dirname(__file__), filename)

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                json.load(f)
            print(f"  [OK] {filename} is valid JSON")
        except FileNotFoundError:
            print(f"  [FAIL] {filename} not found")
            return False
        except json.JSONDecodeError as e:
            print(f"  [FAIL] {filename} invalid JSON: {e}")
            return False

    return True


def main():
    """Run all self-check tests."""
    print("=" * 60)
    print("Feishu Bitable Attachment Skill - Self Check")
    print("=" * 60)

    results = []

    results.append(("Imports", test_imports()))
    results.append(("File Not Found Error", test_file_not_found_error()))
    results.append(("Input Validation", test_input_validation()))
    results.append(("Payload Files", test_payload_files()))

    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"  {name}: {status}")

    print(f"\nTotal: {passed}/{total} tests passed")

    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
