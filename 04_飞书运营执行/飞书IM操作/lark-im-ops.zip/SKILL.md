---
name: lark-im-ops
description: "飞书即时通讯操作指南：收发消息、管理群聊、搜索聊天记录、上传下载文件、交互卡片。需要安装lark-cli。"
version: 1.0.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  agent_created: true
  tags: [飞书, Lark, 即时通讯, IM, 消息, 群聊, 办公自动化]
  requires:
    bins: ["lark-cli"]
---

# 飞书即时通讯操作

**前置条件：需要安装 lark-cli 并完成认证（`lark-cli auth login`）。**

## 核心概念

| 概念 | 标识符 | 说明 |
|------|--------|------|
| Message | `om_xxx` | 单条消息 |
| Chat | `oc_xxx` | 群聊或单聊 |
| Thread | `omt_xxx` | 消息下的回复线程 |
| Reaction | - | 消息表情回复 |

## 身份选择

- `--as user`：以用户身份操作（发消息、搜索等）
- `--as bot`：以机器人身份操作（自动发消息、webhook等）

## 常用操作速查

### 发送消息
```bash
# 发送文本消息到群聊
lark-cli im +messages-send --chat-id "oc_xxx" --text "消息内容" --as user

# 发送Markdown格式
lark-cli im +messages-send --chat-id "oc_xxx" --markdown "**加粗** 普通" --as user

# 发送私聊（通过user_id）
lark-cli im +messages-send --user-id "ou_xxx" --text "消息内容" --as user

# 发送文件
lark-cli im +messages-send --chat-id "oc_xxx" --file ./report.pdf --as user
```

### 回复消息
```bash
# 回复指定消息
lark-cli im +messages-reply --message-id "om_xxx" --text "回复内容" --as user

# 在话题中回复
lark-cli im +messages-reply --message-id "om_xxx" --text "回复" --in-thread --as user
```

### 搜索消息
```bash
# 全局搜索
lark-cli im +messages-search --query "关键词" --as user

# 按发送者过滤
lark-cli im +messages-search --query "关键词" --sender-ids "ou_xxx" --as user

# 按时间范围
lark-cli im +messages-search --query "关键词" --start-time "2026-01-01" --as user
```

### 群聊管理
```bash
# 创建群聊
lark-cli im +chat-create --name "项目群" --user-ids "ou_xxx,ou_yyy" --as user

# 搜索群聊
lark-cli im +chat-search --query "项目名" --as user

# 查看群成员
lark-cli im +chat-members-list --chat-id "oc_xxx" --as user

# 列出我的群
lark-cli im +chat-list --as user
```

### 查看聊天记录
```bash
# 列出群内消息
lark-cli im +chat-messages-list --chat-id "oc_xxx" --as user

# 列出话题消息
lark-cli im +threads-messages-list --message-id "om_xxx" --as user

# 批量获取指定消息
lark-cli im +messages-mget --message-ids "om_xxx,om_yyy" --as user
```

### 下载文件
```bash
# 下载消息中的图片/文件
lark-cli im +messages-resources-download --message-id "om_xxx" --as user
```

## 发送文档内容作为消息

当需要将飞书文档内容发送为消息时：
1. 用 `docs +fetch --doc-format im-markdown` 获取文档内容
2. 用 `im +messages-send --markdown` 发送

## 交互卡片（Interactive Card）

发送交互卡片前，需要按卡片创建工作流生成卡片JSON，不要手写卡片payload。

## 关键 Pitfalls

### 发送相关
- ⚠️ `--markdown` 格式中 `@file` 不会展开文件内容（发送字面量），需要先 `cat file` 再传入
- ⚠️ `--file` 与 `--text`/`--markdown` 互斥，需要分开发送
- ⚠️ 音频消息只支持Opus格式（.opus/.ogg），mp3/wav需要用 `--file` 作为附件发送

### 搜索相关
- ⚠️ 消息搜索只支持user身份
- ⚠️ 搜索结果默认不包含reactions，需要额外查询

### 权限相关
- ⚠️ 发消息需要 `im:message` scope
- ⚠️ 搜索消息需要 `im:message:readonly` scope
- ⚠️ 创建群需要 `im:chat:create` scope
- ⚠️ 某些操作在bot身份下需要bot在群内

## 更多信息

```bash
lark-cli im --help
```
