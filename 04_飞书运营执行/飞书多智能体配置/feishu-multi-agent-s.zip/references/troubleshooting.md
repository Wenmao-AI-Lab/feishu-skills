# 常见问题排查

## 1. `openclaw doctor` 报 "Config invalid"

检查 `openclaw.json` 是否为合法 JSON：
- 不允许注释（JSON5 才支持，但 openclaw.json 是标准 JSON）
- 不允许 emoji 等非 ASCII 字符混在值中
- 常见错误：在 `exec.enabled` 等值后面加了 `✅ 中文注释`

验证方法：
```bash
node -e "JSON.parse(require('fs').readFileSync(process.env.HOME+'/.openclaw/openclaw.json','utf8')); console.log('OK')"
```

## 2. 机器人不回复群消息

检查顺序：
1. `openclaw gateway status` — 网关是否运行
2. `openclaw doctor` — 飞书连接状态
3. 飞书应用是否开启「机器人」能力
4. 飞书应用是否已加入群聊
5. `requireMention: true` 时，是否在群中 @了机器人

## 3. 两个机器人互相看不到

这是飞书 WebSocket 事件模型的限制：
- 飞书只将**用户**的 @mention 事件发给对应的机器人
- 机器人发出的消息**不会**触发其他机器人的事件
- 解决方案：使用 OpenClaw 内部通信（`sessions_send`）

## 4. 访问控制不生效

访问控制分两层：
- **DM 私聊**：`accounts.default.dmPolicy` + `allowFrom`
- **群聊**：`accounts.default.groupPolicy` + `groupAllowFrom` + `requireMention`

注意 `groupAllowFrom` 是**发送者 ID**（`ou_xxx`），不是群 ID（`oc_xxx`）。

群 ID 应放在 `channels.feishu.groups` 配置中。

## 5. 多账号认证问题

每个 agent 有独立的 `agentDir`，存储各自的 auth-profiles：
```
~/.openclaw/agents/<agentId>/agent/auth-profiles.json
```

两个 agent 之间不共享凭据。如果需要共享，手动复制文件。

## 6. WebSocket 连接断开

```bash
openclaw gateway restart
```

检查是否有多个 Gateway 实例在运行（端口冲突）。

## 7. Agent 间消息循环

如果两个 agent 互相触发，可能形成无限循环。在 SOUL.md 中加入防护规则：

```
- 不要回复自己发出的消息
- 不要对 sessions_send 来的消息再次 sessions_send 回去
- 对于明显是转发/协作请求的消息，直接处理并回复，不要二次转发
```
