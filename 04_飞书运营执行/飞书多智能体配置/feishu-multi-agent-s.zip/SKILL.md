---
name: feishu-multi-agent
description: |
  配置多个 OpenClaw agent 绑定多个飞书（Lark）机器人，在同一个群聊中实现多智能体协作。
  当用户要求：(1) 在飞书中部署多个 AI 智能体；(2) 多个飞书机器人共享群聊；
  (3) 飞书群聊中实现 bot 间协作或互操作；(4) 配置 openclaw-lark 多账号时使用。
---

# 飞书多智能体配置指南

将多个 OpenClaw agent 与多个飞书机器人 App 绑定，实现在同一群聊中的多智能体协作。

## 前置条件

1. 每个 agent 需要一个独立的飞书自建应用（AppID + AppSecret）
2. 每个飞书应用需要开启：机器人能力、WebSocket 长连接
3. 每个飞书应用需要添加到目标群聊中
4. 已安装 `openclaw-lark` 插件

## 配置步骤

### 1. 飞书开放平台创建应用

每个 agent 对应一个飞书应用，共需 N 个应用。

每个应用需要：
- 开启「机器人」能力
- 权限范围：`im:message`、`im:message:send_as_bot`、`im:chat:readonly` 等
- 事件订阅：`im.message.receive_v1`（通过 WebSocket 模式，无需公网回调）
- 记录 AppID 和 AppSecret

### 2. OpenClaw 配置

配置涉及 4 个关键部分：

- `agents.list` — 定义每个 agent
- `channels.feishu.accounts` — 配置每个飞书应用凭据
- `bindings` — 将飞书账号绑定到 agent
- `channels.feishu.accounts.default` — 访问控制策略

详细配置模板见 [references/config-template.md](references/config-template.md)

### 3. 重启验证

```bash
openclaw gateway restart
openclaw doctor
```

## 智能体间协作

由于飞书 WebSocket 不会将其他机器人的消息触发为事件，agent 间通信使用 OpenClaw 内部机制：

- **`sessions_send(agentId: "xxx", message: "...")`** — 向另一个 agent 发送消息并等待回复
- **`sessions_list`** — 查看活跃 session
- **`sessions_spawn`** — 启动子 agent 处理子任务

在 agent 的 SOUL.md 或 AGENTS.md 中编写协作规则，定义何时调用另一个 agent。

## 常见问题

详见 [references/troubleshooting.md](references/troubleshooting.md)
