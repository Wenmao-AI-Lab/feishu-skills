module.exports = {
  type: 'object',
  properties: {
    FEISHU_APP_ID: {
      type: 'string',
      description: '飞书自建应用的 App ID',
      required: true
    },
    FEISHU_APP_SECRET: {
      type: 'string',
      description: '飞书自建应用的 App Secret',
      required: true,
      secret: true
    }
  }
};