---
name: feishu-report
description: 查询飞书"汇报"模块的规则与提交记录。支持自然语言日期、关键词搜索、个人汇报查询。按"部门名 = 规则名"SOP 直接拉某人最近的日报/周报。
tags: [feishu, report, daily, work, sop, search]
---

# 飞书汇报查询（feishu-report）v1.1.0

直接调用飞书 **汇报开放接口**：`/open-apis/report/v1/rules/query` 与 `/tasks/query`，
拉取真实的「汇报模块」数据，不依赖多维表。

## ✨ 功能特性

| 功能 | 说明 |
|------|------|
| 🔐 **user_access_token** | 以当前登录用户身份查询自己的汇报，无需配置 app_id |
| 📅 **自然语言日期** | 支持"今天""昨天""本周""上周""本月""上月""最近N天" |
| 🔍 **关键词搜索** | 在汇报内容中搜索指定关键词，快速定位 |
| 👤 **my 命令** | 一键查询自己的汇报记录 |
| 🎯 **SOP 一键查询** | 部门名 → 汇报规则 → 人员汇报 |

## SOP（来自用户长期规则）

**查询任意人的汇报**：

1. **先查该人员所在部门**（或直接由用户提供）
2. **汇报规则名通常就是部门名**（例：张三在「融媒体部」→ 规则名「融媒体部」）
3. 用本 skill 的 `who` 一键完成

> ⚠️ 实测踩坑：规则名**不一定**带「规则」二字。优先用部门原名搜。

## 凭证优先级

1. **user_access_token**（查询 my 命令时自动从 OpenClaw 获取）
2. 环境变量 `FEISHU_APP_ID` / `FEISHU_APP_SECRET`
3. `~/.openclaw/openclaw.json` → `channels.feishu.{appId, appSecret}`

## 必需的应用权限

在飞书开发者后台开启：

- ✅ `report:rule:readonly` — 查看汇报规则
- ✅ `report:task:readonly` — 查看汇报任务
- （可选）`contact:user.base:readonly` — 获取用户姓名

## CLI 用法

```bash
cd ~/.openclaw/workspace/skills/feishu-report

# 1) 搜规则
node index.js rules 融媒体部
node index.js rules 交付运维事业部

# 2) 一键 SOP：部门 + 人员
node index.js who 融媒体部 张三 --days 14
node index.js who 融媒体部 张三 --when "上周"
node index.js who 融媒体部 ou_fcc437ec0b0970abfc471980a9273018 --brief

# 3) 查询自己的汇报（推荐）
node index.js my --when "本周"
node index.js my --when "上月" --brief

# 4) 关键词搜索
node index.js search 项目进度 --days 30
node index.js search 风险 --rule 7594409431966829500 --when "最近7天"

# 5) 自由组合
node index.js tasks --rule 7594409431966829500 --user ou_xxx --start 2026-05-01 --end 2026-05-25

# 6) 帮助
node index.js --help