#!/usr/bin/env node
/**
 * feishu-report CLI v1.1.0
 * 
 * 功能：
 *   - 查询汇报规则 (rules)
 *   - 查询汇报任务 (tasks)
 *   - 一键部门查询 (who)
 *   - 查询自己的汇报 (my)
 *   - 关键词搜索 (search)
 *   - 自然语言日期 (--when)
 */

const { getTenantAccessToken, queryReportRules, listAllTasks, getUserAccessTokenFromOpenClaw, listMyTasks } = require('./lib/api');
const { loadCredentials } = require('./lib/credentials');
const { parseDate, renderTask, fmtTime } = require('./lib/format');
const { parseDateExpression } = require('./lib/date-helper');

function parseArgs(argv) {
  const out = { _: [], flags: {} };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') {
      out.flags.help = true;
      continue;
    }
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true;
      out.flags[k] = v;
    } else {
      out._.push(a);
    }
  }
  return out;
}

function usage() {
  console.log(`feishu-report CLI v1.1.0 - 查询飞书汇报模块

用法:
  node index.js rules <规则名> [--include-deleted] [--json]
      模糊搜索汇报规则，返回 rule_id 和表单字段

  node index.js tasks [选项]
      查询时间范围内的汇报任务
      选项:
        --rule <ruleId>      汇报规则ID
        --user <open_id>     用户ID
        --days <N>           最近N天（默认14）
        --start YYYY-MM-DD   开始日期
        --end YYYY-MM-DD     结束日期
        --when <表达式>      自然语言日期（如"本周""最近7天"）
        --brief              摘要模式
        --json               输出原始JSON
        --page-size <N>      每页条数（最大20）

  node index.js who <部门名> <姓名|open_id> [选项]
      一键查询：部门名 → 汇报规则 → 人员汇报
      选项: --days / --when / --brief / --json

  node index.js my [选项]
      查询当前用户自己的汇报（优先使用 user_access_token）
      选项: --days / --when / --rule / --brief / --json / --user <open_id>

  node index.js search <关键词> [选项]
      在汇报内容中搜索关键词
      选项: --days / --when / --rule / --brief / --json / --page-size

  node index.js --help / -h
      显示帮助

日期表达式支持:
  --when "今天"     --when "昨天"     --when "本周"     --when "上周"
  --when "本月"     --when "上月"     --when "最近7天"   --when "2026-05-20"

示例:
  node index.js my --when "本周"
  node index.js who 融媒体部 王蕾 --when "上周"
  node index.js search 项目进度 --days 30
`);
}

async function cmdRules(args) {
  const ruleName = args._[1];
  if (!ruleName) {
    console.error('用法：node index.js rules <ruleName>');
    process.exit(2);
  }
  const cred = loadCredentials();
  const token = await getTenantAccessToken(cred.appId, cred.appSecret);
  const rules = await queryReportRules(token, ruleName, args.flags['include-deleted'] ? 1 : 0);
  
  if (args.flags.json) {
    console.log(JSON.stringify(rules, null, 2));
    return;
  }
  
  if (!rules.length) {
    console.log(`未找到名称包含「${ruleName}」的汇报规则。`);
    return;
  }
  
  console.log(`🔎 找到 ${rules.length} 条规则（凭证来源: ${cred.source}）`);
  for (const r of rules) {
    const fields = (r.form_schema || []).map((f) => f.name || f.field_name).join(' / ');
    console.log(`  • ${r.name}    rule_id=${r.rule_id}` + (fields ? `\n      字段: ${fields}` : ''));
  }
}

function resolveTimeRange(flags) {
  const now = Math.floor(Date.now() / 1000);
  
  // 优先使用 --when 自然语言
  if (flags.when) {
    const parsed = parseDateExpression(flags.when);
    if (parsed) {
      console.log(`📅 解析时间: ${parsed.description} (${fmtTime(parsed.startTime)} ~ ${fmtTime(parsed.endTime)})`);
      return { startTime: parsed.startTime, endTime: parsed.endTime };
    }
    console.log(`⚠️ 无法解析日期表达式: ${flags.when}，使用默认最近14天`);
  }
  
  if (flags.start || flags.end) {
    const startTime = flags.start ? parseDate(flags.start) : now - 14 * 86400;
    const endTime = (flags.end ? parseDate(flags.end) : now) + (flags.end ? 86399 : 0);
    return { startTime, endTime };
  }
  const days = Number(flags.days || 14);
  return { startTime: now - days * 86400, endTime: now };
}

function outputTasks(items, startTime, endTime, brief) {
  if (!items.length) {
    console.log(`未找到汇报记录（${fmtTime(startTime)} ~ ${fmtTime(endTime)}）。`);
    return;
  }
  
  console.log(`📊 共 ${items.length} 条（${fmtTime(startTime)} ~ ${fmtTime(endTime)}）\n`);
  items
    .sort((a, b) => Number(a.commit_time) - Number(b.commit_time))
    .forEach((t, i) => {
      console.log(`────────── #${i + 1} ──────────`);
      console.log(renderTask(t, { brief }));
      console.log();
    });
}

async function cmdTasks(args) {
  const cred = loadCredentials();
  const token = await getTenantAccessToken(cred.appId, cred.appSecret);
  const { startTime, endTime } = resolveTimeRange(args.flags);

  const items = await listAllTasks(token, {
    startTime,
    endTime,
    ruleId: args.flags.rule,
    userId: args.flags.user,
    pageSize: Number(args.flags['page-size'] || 20)
  });

  if (args.flags.json) {
    console.log(JSON.stringify(items, null, 2));
    return;
  }

  outputTasks(items, startTime, endTime, !!args.flags.brief);
}

function fuzzyMatchByName(items, targetName) {
  const exactMatches = items.filter((t) => t.from_user_name === targetName);
  if (exactMatches.length > 0) {
    return { matches: exactMatches, isExact: true };
  }
  
  if (targetName.length >= 2) {
    const fuzzyMatches = items.filter((t) => t.from_user_name && t.from_user_name.includes(targetName));
    if (fuzzyMatches.length > 0) {
      return { matches: fuzzyMatches, isExact: false };
    }
  }
  
  return { matches: [], isExact: false };
}

async function cmdWho(args) {
  const ruleName = args._[1];
  const who = args._[2];
  if (!ruleName || !who) {
    console.error('用法：node index.js who <部门名/规则名> <姓名|open_id> [--days 14]');
    process.exit(2);
  }
  const cred = loadCredentials();
  const token = await getTenantAccessToken(cred.appId, cred.appSecret);

  const rules = await queryReportRules(token, ruleName, 0);
  if (!rules.length) {
    console.error(`❌ 未找到与「${ruleName}」匹配的汇报规则。`);
    console.error('   提示：飞书汇报规则名通常就是部门名（如「融媒体部」「交付运维事业部」）。');
    process.exit(1);
  }
  const rule = rules[0];
  console.log(`✅ 命中规则: ${rule.name}  (rule_id=${rule.rule_id})`);
  if (rules.length > 1) {
    console.log(`   还有其他匹配: ${rules.slice(1).map((r) => r.name).join(', ')}`);
  }

  const { startTime, endTime } = resolveTimeRange(args.flags);
  const isOpenId = who.startsWith('ou_');
  
  let items;
  if (isOpenId) {
    items = await listAllTasks(token, {
      startTime,
      endTime,
      ruleId: rule.rule_id,
      userId: who,
      pageSize: 20
    });
  } else {
    items = await listAllTasks(token, {
      startTime,
      endTime,
      ruleId: rule.rule_id,
      pageSize: 20
    });
  }

  let filtered, isExactMatch;
  if (isOpenId) {
    filtered = items;
    isExactMatch = true;
  } else {
    const { matches, isExact } = fuzzyMatchByName(items, who);
    filtered = matches;
    isExactMatch = isExact;
  }

  if (args.flags.json) {
    console.log(JSON.stringify(filtered, null, 2));
    return;
  }

  if (!filtered.length) {
    console.log(`未找到「${who}」在该规则下的汇报（${fmtTime(startTime)} ~ ${fmtTime(endTime)}）。`);
    if (!isOpenId && items.length) {
      const names = Array.from(new Set(items.map((t) => t.from_user_name))).filter(Boolean);
      console.log(`该时间段内提交过的人员: ${names.join(', ')}`);
    }
    return;
  }

  if (!isExactMatch && !isOpenId) {
    console.log(`⚠️ 未找到完全匹配「${who}」的人员，使用模糊匹配结果。建议使用 open_id 精确查询。`);
    const matchedNames = Array.from(new Set(filtered.map((t) => t.from_user_name)));
    console.log(`   匹配到: ${matchedNames.join(', ')}\n`);
  }

  const brief = !!args.flags.brief;
  console.log(`📊 ${who} · 共 ${filtered.length} 条（${fmtTime(startTime)} ~ ${fmtTime(endTime)}）\n`);
  filtered
    .sort((a, b) => Number(a.commit_time) - Number(b.commit_time))
    .forEach((t, i) => {
      console.log(`────────── #${i + 1} ──────────`);
      console.log(renderTask(t, { brief }));
      console.log();
    });
}

async function cmdMy(args) {
  let userToken = await getUserAccessTokenFromOpenClaw();
  
  if (!userToken) {
    console.log('⚠️ 未找到 user_access_token，尝试使用应用身份查询...');
    const cred = loadCredentials();
    const token = await getTenantAccessToken(cred.appId, cred.appSecret);
    
    const myOpenId = args.flags.user || process.env.FEISHU_MY_OPEN_ID;
    if (!myOpenId) {
      console.error('❌ 无法确定当前用户，请设置 --user <open_id> 或环境变量 FEISHU_MY_OPEN_ID');
      process.exit(1);
    }
    
    const { startTime, endTime } = resolveTimeRange(args.flags);
    const items = await listAllTasks(token, {
      startTime,
      endTime,
      ruleId: args.flags.rule,
      userId: myOpenId,
      pageSize: Number(args.flags['page-size'] || 20)
    });
    
    if (args.flags.json) {
      console.log(JSON.stringify(items, null, 2));
      return;
    }
    
    outputTasks(items, startTime, endTime, !!args.flags.brief);
    return;
  }
  
  const { startTime, endTime } = resolveTimeRange(args.flags);
  const items = await listMyTasks(userToken, {
    startTime,
    endTime,
    ruleId: args.flags.rule,
    pageSize: Number(args.flags['page-size'] || 20)
  });
  
  if (args.flags.json) {
    console.log(JSON.stringify(items, null, 2));
    return;
  }
  
  outputTasks(items, startTime, endTime, !!args.flags.brief);
}

async function cmdSearch(args) {
  const keyword = args._[1];
  if (!keyword) {
    console.error('用法：node index.js search <关键词> [--days 30] [--rule <ruleId>] [--brief]');
    process.exit(2);
  }
  
  const cred = loadCredentials();
  const token = await getTenantAccessToken(cred.appId, cred.appSecret);
  const { startTime, endTime } = resolveTimeRange(args.flags);
  
  console.log(`🔍 搜索关键词: "${keyword}" (${fmtTime(startTime)} ~ ${fmtTime(endTime)})`);
  
  const items = await listAllTasks(token, {
    startTime,
    endTime,
    ruleId: args.flags.rule,
    pageSize: Number(args.flags['page-size'] || 50)
  });
  
  const matched = items.filter(task => {
    if (!task.form_contents) return false;
    return task.form_contents.some(field => {
      const value = field.field_value || '';
      return value.toLowerCase().includes(keyword.toLowerCase());
    });
  });
  
  if (args.flags.json) {
    console.log(JSON.stringify(matched, null, 2));
    return;
  }
  
  if (!matched.length) {
    console.log(`未找到包含「${keyword}」的汇报记录。`);
    return;
  }
  
  console.log(`🎯 找到 ${matched.length} 条包含「${keyword}」的汇报\n`);
  matched
    .sort((a, b) => Number(b.commit_time) - Number(a.commit_time))
    .forEach((t, i) => {
      const relevantFields = t.form_contents.filter(f => 
        (f.field_value || '').toLowerCase().includes(keyword.toLowerCase())
      );
      console.log(`────────── #${i + 1} ──────────`);
      console.log(`📅 ${fmtTime(t.commit_time)}  ·  ${t.from_user_name || '-'} · ${t.rule_name || '-'}`);
      relevantFields.forEach(f => {
        const val = f.field_value || '';
        const lowerVal = val.toLowerCase();
        const idx = lowerVal.indexOf(keyword.toLowerCase());
        let preview;
        if (idx > 30) {
          preview = '...' + val.slice(idx - 30, idx + 30 + keyword.length) + '...';
        } else {
          preview = val.slice(0, 100);
        }
        console.log(`  🔍 【${f.field_name}】: ${preview}`);
      });
      console.log();
    });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];

  if (args.flags.help || (!cmd && args.flags.help)) {
    usage();
    return;
  }

  try {
    if (cmd === 'rules') return await cmdRules(args);
    if (cmd === 'tasks') return await cmdTasks(args);
    if (cmd === 'who') return await cmdWho(args);
    if (cmd === 'my') return await cmdMy(args);
    if (cmd === 'search') return await cmdSearch(args);
    usage();
    process.exit(cmd ? 2 : 0);
  } catch (e) {
    console.error(`❌ ${e.message}`);
    process.exit(1);
  }
}

main();