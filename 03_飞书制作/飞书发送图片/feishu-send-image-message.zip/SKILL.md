---
name: feishu-send-image-message
description: Upload a local image file to Feishu and send it as an image message into the current Feishu conversation.
read_when:
  - The user asks to send a local image into Feishu
  - The user asks to upload an image file and post it into the current chat
  - You need to deliver an already-existing local image as a Feishu image message
metadata:
  {
    "openclaw": {
      "emoji": "🖼️",
      "requires": { "bins": ["curl", "jq"] }
    }
  }
---

# Feishu Send Image Message

Upload a local image file to Feishu and send it into the current Feishu conversation as an image message.

## Purpose

Use this skill when the user already has a local image file and wants it sent into the active Feishu chat.

## What this skill does

1. Read Feishu app credentials from `~/.openclaw/openclaw.json`
2. Request a `tenant_access_token`
3. Upload the local image to Feishu to obtain an `image_key`
4. Send the image message to the current chat

## When to use

- Send a local screenshot into Feishu
- Upload an existing image file and post it to the current conversation
- Deliver a local image as a Feishu image message

## Requirements

- `curl`
- `jq`
- Feishu app configuration in `~/.openclaw/openclaw.json`
- Feishu app permission: `im:resource`

## Inputs

- Local image file path
- Current Feishu recipient/chat context

## Outputs

- Feishu `image_key`
- Feishu `message_id`
- Confirmation that the image was sent

## Preconditions

- The current conversation is handled by OpenClaw in Feishu
- The Feishu app credentials already exist in `~/.openclaw/openclaw.json`
- The current Feishu app has permission to upload images and send messages
- The input image file exists locally and is readable

## Recommended workflow

### 1) Read Feishu credentials

Read `~/.openclaw/openclaw.json` and extract:

- `channels.feishu.appId`
- `channels.feishu.appSecret`

### 2) Get a tenant access token

```bash
curl -s -X POST \
  "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d '{
    "app_id": "<appId>",
    "app_secret": "<appSecret>"
  }'
```

Use the returned `tenant_access_token` for subsequent requests.

### 3) Upload the image

```bash
curl -s -X POST \
  "https://open.feishu.cn/open-apis/im/v1/images" \
  -H "Authorization: Bearer <tenant_access_token>" \
  -F "image_type=message" \
  -F "image=@/path/to/image.png"
```

Extract `data.image_key` from the response.

### 4) Send the image message

```bash
curl -s -X POST \
  "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id" \
  -H "Authorization: Bearer <tenant_access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "receive_id": "<current_open_id>",
    "msg_type": "image",
    "content": "{\"image_key\":\"<image_key>\"}"
  }'
```

## Implementation notes

- The image upload API requires `image_type=message`
- The message payload must use `msg_type=image`
- The `content` field must be a JSON string that contains `image_key`
- Use the correct `receive_id_type` for the current conversation
- Keep the local image file until the upload succeeds

## Error handling

- If Feishu credentials are missing, report that `~/.openclaw/openclaw.json` is not configured
- If the image file is missing or unreadable, report the file path problem
- If the upload fails, surface the Feishu error code and message
- If the send fails, verify the `receive_id_type` and target recipient ID

## Safety

- Only upload files that the user explicitly asked to send
- Do not modify the image contents unless the user requested editing
- If the file path is ambiguous, confirm the exact local file before uploading

## Success report

When successful, report:

- image file path
- uploaded `image_key`
- Feishu `message_id`
- confirmation that the image was sent to the current chat

## Example end-to-end sketch

```bash
APP_ID="<appId>"
APP_SECRET="<appSecret>"
TOKEN=$(curl -s -X POST \
  "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d '{"app_id":"'"$APP_ID"'","app_secret":"'"$APP_SECRET"'"}' | jq -r '.tenant_access_token')

IMAGE_KEY=$(curl -s -X POST \
  "https://open.feishu.cn/open-apis/im/v1/images" \
  -H "Authorization: Bearer $TOKEN" \
  -F "image_type=message" \
  -F "image=@/path/to/image.png" | jq -r '.data.image_key')

curl -s -X POST \
  "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"receive_id":"<current_open_id>","msg_type":"image","content":"{\"image_key\":\"'"$IMAGE_KEY"'\"}"}'
```
