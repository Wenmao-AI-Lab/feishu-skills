#!/usr/bin/env python3

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = SKILL_DIR / "scripts"
HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def run_python(name: str, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPTS_DIR / name), *args],
        capture_output=True,
        text=True,
        check=False,
    )


@unittest.skipUnless(HAS_FFMPEG, "ffmpeg and ffprobe are required")
class MediaToolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def make_video(self, size: str, name: str) -> Path:
        output = self.root / name
        result = subprocess.run(
            [
                "ffmpeg",
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                f"color=c=black:s={size}:r=24:d=1",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=440:duration=1",
                "-shortest",
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                str(output),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return output

    def test_low_resolution_is_a_hard_failure(self) -> None:
        video = self.make_video("640x360", "low.mp4")
        result = run_python(
            "verify_media.py",
            str(video),
            "--kind",
            "video",
            "--expected-duration-seconds",
            "1",
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("short side", result.stderr)

    def test_duration_milliseconds_are_normalized(self) -> None:
        video = self.make_video("1280x720", "hd.mp4")
        result = run_python(
            "verify_media.py",
            str(video),
            "--kind",
            "video",
            "--expected-duration-ms",
            "1000",
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_soft_subtitle_mux_and_readback(self) -> None:
        video = self.make_video("1280x720", "source video.mp4")
        subtitles = self.root / "字幕 sample.srt"
        subtitles.write_text(
            "1\n00:00:00,000 --> 00:00:00,800\n测试字幕\n",
            encoding="utf-8",
        )
        output = self.root / "subtitled video.mp4"
        mux = subprocess.run(
            [
                "bash",
                str(SCRIPTS_DIR / "mux_subtitles.sh"),
                str(video),
                str(subtitles),
                str(output),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(mux.returncode, 0, mux.stderr)
        verify = run_python(
            "verify_media.py",
            str(output),
            "--kind",
            "video",
            "--expected-duration-seconds",
            "1",
            "--require-subtitle-track",
        )
        self.assertEqual(verify.returncode, 0, verify.stderr)

    def test_burn_in_subtitles_with_spaced_path(self) -> None:
        video = self.make_video("1280x720", "burn source.mp4")
        subtitles = self.root / "烧录 字幕.srt"
        subtitles.write_text(
            "1\n00:00:00,000 --> 00:00:00,800\n烧录测试\n",
            encoding="utf-8",
        )
        output = self.root / "burned output.mp4"
        result = subprocess.run(
            [
                "bash",
                str(SCRIPTS_DIR / "mux_subtitles.sh"),
                str(video),
                str(subtitles),
                str(output),
                "--burn-in",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        filters = subprocess.run(
            ["ffmpeg", "-hide_banner", "-filters"],
            capture_output=True,
            text=True,
            check=False,
        )
        if " subtitles " not in f" {filters.stdout} ":
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("subtitles/libass filter", result.stderr)
            return
        self.assertEqual(result.returncode, 0, result.stderr)
        verify = run_python(
            "verify_media.py",
            str(output),
            "--kind",
            "video",
            "--expected-duration-seconds",
            "1",
        )
        self.assertEqual(verify.returncode, 0, verify.stderr)

    def test_minutes_subtitle_json_converts_to_srt(self) -> None:
        raw = self.root / "raw.json"
        output = self.root / "out.srt"
        raw.write_text(
            json.dumps(
                {
                    "subtitles": {
                        "paragraphs": [
                            {
                                "pid": "p1",
                                "sentences": [
                                    {
                                        "contents": [
                                            {
                                                "content": "你好，",
                                                "start_time": "0",
                                                "stop_time": "500",
                                            },
                                            {
                                                "content": "这是测试。",
                                                "start_time": "500",
                                                "stop_time": "1400",
                                            },
                                        ]
                                    }
                                ],
                            }
                        ]
                    }
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        result = run_python(
            "subtitles_json_to_srt.py",
            str(raw),
            str(output),
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        text = output.read_text(encoding="utf-8")
        self.assertIn("00:00:00,000 --> 00:00:01,400", text)
        self.assertIn("你好，这是测试。", text)


if __name__ == "__main__":
    unittest.main()
