#!/usr/bin/env python3

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
VERIFIER = SKILL_DIR / "scripts/verify_document.py"


def run_verifier(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(VERIFIER), *args],
        capture_output=True,
        text=True,
        check=False,
    )


class DocumentVerifierTests(unittest.TestCase):
    def write_json(self, root: Path, name: str, value: dict) -> Path:
        path = root / name
        path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
        return path

    def fixtures(self, root: Path, *, preview: bool = True, include_old: bool = False):
        new_token = "obcnnewtoken123456789012"
        old_token = "obcnoldtoken123456789012"
        content = (
            "<title>纪要</title><h2>高清视频妙记</h2>"
            f'<iframe url="https://tenant.feishu.cn/minutes/{new_token}"/>'
        )
        if include_old:
            content += f"<p>{old_token}</p>"
        fetch = self.write_json(
            root,
            "fetch.json",
            {"ok": True, "data": {"document": {"content": content}}},
        )
        block = {
            "block_id": "blk-preview",
            "block_type": 26 if preview else 2,
            "iframe": {"url": f"https://tenant.feishu.cn/minutes/{new_token}"}
            if preview
            else None,
            "text": None
            if preview
            else {"elements": [{"text_run": {"content": new_token}}]},
        }
        blocks = self.write_json(
            root,
            "blocks.json",
            {"ok": True, "data": {"items": [block]}},
        )
        return fetch, blocks, new_token, old_token

    def test_exact_new_token_preview_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fetch, blocks, new_token, old_token = self.fixtures(Path(tmp))
            result = run_verifier(
                "--fetch-json",
                str(fetch),
                "--blocks-json",
                str(blocks),
                "--new-minute-token",
                new_token,
                "--forbidden-token",
                old_token,
                "--require-preview",
            )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_bare_link_does_not_count_as_preview(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fetch, blocks, new_token, _ = self.fixtures(Path(tmp), preview=False)
            result = run_verifier(
                "--fetch-json",
                str(fetch),
                "--blocks-json",
                str(blocks),
                "--new-minute-token",
                new_token,
                "--require-preview",
            )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("preview block", result.stderr)

    def test_original_token_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fetch, blocks, new_token, old_token = self.fixtures(
                Path(tmp),
                include_old=True,
            )
            result = run_verifier(
                "--fetch-json",
                str(fetch),
                "--blocks-json",
                str(blocks),
                "--new-minute-token",
                new_token,
                "--forbidden-token",
                old_token,
            )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("forbidden token", result.stderr)


if __name__ == "__main__":
    unittest.main()
