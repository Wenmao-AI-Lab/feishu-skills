#!/usr/bin/env python3

import json
import shutil
import subprocess
import unittest
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
HUB_ROOT = SKILL_DIR.parents[1]


class SkillContractTests(unittest.TestCase):
    def test_skill_metadata_and_workflow_contract(self) -> None:
        text = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("name: feishu-minutes-video-doc", text)
        for phrase in (
            "妙记链接",
            "音频",
            "minutes +download",
            "drive +upload",
            "minutes +upload",
            "minutes +detail",
            "docs +create",
            "逐字稿",
            "预览视图",
            "原始妙记",
        ):
            self.assertIn(phrase, text)
        for stale in ("--markdown", "--mode append", "/Users/", "~/.claude/skills"):
            self.assertNotIn(stale, text)

    def test_references_and_scripts_are_present(self) -> None:
        for relative in (
            "agents/openai.yaml",
            "references/document-quality.md",
            "references/media-extraction.md",
            "references/preview-card.md",
            "scripts/mux_subtitles.sh",
            "scripts/subtitles_json_to_srt.py",
            "scripts/verify_document.py",
            "scripts/verify_media.py",
        ):
            self.assertTrue((SKILL_DIR / relative).is_file(), relative)

    def test_only_canonical_skill_is_registered(self) -> None:
        conf = json.loads((HUB_ROOT / "hub.json").read_text(encoding="utf-8"))
        skills = conf["skills"]
        self.assertIn("feishu-minutes-video-doc", skills)
        self.assertNotIn("feishu-minutes-video-clone", skills)
        self.assertNotIn("lark-minutes-video-doc", skills)
        self.assertFalse((HUB_ROOT / "skills/feishu-minutes-video-clone").exists())
        self.assertFalse((HUB_ROOT / "skills/lark-minutes-video-doc").exists())

    @unittest.skipUnless(shutil.which("lark-cli"), "lark-cli is not installed")
    def test_current_lark_cli_contract(self) -> None:
        expectations = (
            (("minutes", "+download", "--help"), ("--minute-tokens", "--output-dir")),
            (("minutes", "+upload", "--help"), ("--file-token",)),
            (("minutes", "+detail", "--help"), ("--transcript", "--summary")),
            (("docs", "+create", "--help"), ("--content", "--doc-format")),
            (("docs", "+update", "--help"), ("--command", "--content")),
        )
        for args, required in expectations:
            result = subprocess.run(
                ["lark-cli", *args],
                capture_output=True,
                text=True,
                check=False,
            )
            output = result.stdout + result.stderr
            self.assertEqual(result.returncode, 0, output)
            for flag in required:
                self.assertIn(flag, output, f"{' '.join(args)} missing {flag}")


if __name__ == "__main__":
    unittest.main()
