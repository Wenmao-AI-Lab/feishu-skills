# 妙记预览视图

在文档已经包含新妙记裸链接、需要切换为预览卡片时读取本文件。

## 前置条件

- 已取得新生成的 `NEW_TOKEN`，且妙记可以正常打开。
- 文档中不存在原始妙记 token。
- 文末章节只包含 `高清视频妙记` 或 `高清音频妙记` 标题与新妙记链接。
- 当前浏览器工具可以复用用户登录态并看到飞书文档。

## UI 操作

1. 打开目标飞书文档并滚动到文末。
2. 精确定位 `href` 包含 `NEW_TOKEN` 的链接，不选择页面中的其他妙记链接。
3. 点击或打开链接菜单。
4. 选择 `链接视图`。
5. 选择 `预览视图`。
6. 等待预览内容加载，并确认文档显示已保存或云端同步完成。

若普通点击直接打开妙记，使用当前浏览器工具提供的右键、上下文菜单或 DOM 定位能力。优先按可见文字 `链接视图`、`预览视图` 定位，不依赖长期不变的 CSS class。

## 浏览器验收

截图必须同时显示：

- 文末章节标题。
- 新妙记预览卡片的标题或播放器区域。
- 不是单独一行裸 URL。
- 文档已保存。

不要在截图说明中重复原始妙记链接。

## API 验收

读取最终文档与 block：

```bash
lark-cli docs +fetch \
  --api-version v2 \
  --as user \
  --doc "$DOC_URL" \
  --detail full \
  --doc-format xml \
  > "$WORKDIR/final-doc.json"

lark-cli api GET "/open-apis/docx/v1/documents/$DOC_ID/blocks" \
  --as user \
  --params '{"page_size":500,"document_revision_id":-1}' \
  > "$WORKDIR/final-blocks.json"
```

执行 token 绑定验收：

```bash
python3 scripts/verify_document.py \
  --fetch-json "$WORKDIR/final-doc.json" \
  --blocks-json "$WORKDIR/final-blocks.json" \
  --new-minute-token "$NEW_TOKEN" \
  --forbidden-token "$SOURCE_TOKEN" \
  --section-heading "高清视频妙记" \
  --require-preview
```

`block_type=26` 或 iframe 类字段只能作为预览证据之一。必须确认同一个 block 包含 `NEW_TOKEN`；文档里存在其他 iframe 不能算通过。

## 失败处理

- 找不到新 token 链接：重新读回文档，确认写入是否成功。
- 菜单没有预览视图：确认链接是飞书妙记 URL，并尝试浏览器可见文字定位。
- 预览已显示但 API 未读回：等待保存后重新 fetch，不立即宣称完成。
- API 通过但截图仍是裸链接：以可见结果为准，继续修复 UI 状态。
- 妙记仍在处理：等待新妙记就绪，不把处理说明写入文档。
