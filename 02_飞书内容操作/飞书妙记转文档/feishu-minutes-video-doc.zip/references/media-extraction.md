# 媒体与字幕提取

只有官方 `minutes +download` 或现成字幕资源无法满足任务时才读取本文件。

## 目录

- 官方接口优先
- 浏览器工具选择
- 查找媒体资源
- 提取时间戳字幕
- 安全边界

## 官方接口优先

先执行：

```bash
lark-cli minutes +download \
  --as user \
  --minute-tokens "$SOURCE_TOKEN" \
  --output-dir "$WORKDIR" \
  --overwrite
```

缺少权限时按 `lark-shared` 进行最小范围授权。不要因为浏览器已经登录就跳过官方接口。

官方接口失败后，记录失败类别：

- 妙记仍在处理。
- 用户对妙记或媒体没有导出权限。
- 租户未开放对应接口。
- 返回文件与页面实际高清媒体不一致。

只有用户本身有访问权限时，才复用其登录浏览器。

## 浏览器工具选择

读取当前平台提供的 Browser、Chrome、Playwright、Computer Use 或 web-access Skill，选择能够：

1. 复用用户现有飞书登录态。
2. 打开目标妙记页面。
3. 执行页面 JavaScript 或观察网络资源。
4. 必要时设置本地文件到上传控件。

不要硬编码某个 Agent 的 Skill 目录、CDP 端口或浏览器用户目录。

## 查找媒体资源

在妙记页面播放数秒后执行：

```javascript
(() => ({
  videos: [...document.querySelectorAll("video")].map((video) => ({
    src: video.currentSrc || video.src,
    duration: video.duration,
    width: video.videoWidth,
    height: video.videoHeight,
    readyState: video.readyState,
  })),
  tracks: [...document.querySelectorAll("track")].map((track) => ({
    kind: track.kind,
    label: track.label,
    language: track.srclang,
    src: track.src,
  })),
  resources: performance
    .getEntriesByType("resource")
    .map((entry) => entry.name)
    .filter((url) =>
      /mp4|m3u8|m4s|vtt|srt|subtitle|caption|stream|download/i.test(url),
    )
    .slice(-300),
}))()
```

优先选择原始下载流，不使用缩略图、低清 preview 流或片段。受保护 URL 只能在本地执行过程中使用，不要输出到聊天、文档或共享日志。

下载完成后必须运行 `scripts/verify_media.py`。浏览器成功播放不等于已下载完整文件。

## 提取时间戳字幕

在目标妙记页面的已登录上下文中执行以下函数，把返回值保存为 `subtitles.raw.json`：

```javascript
async (minuteToken) => {
  const idsResponse = await fetch(
    `/minutes/api/subtitles/paragraph-ids?page_size=10000&page_num=0&object_token=${encodeURIComponent(minuteToken)}&language=zh_cn`,
    { credentials: "include" },
  );
  const idsJson = await idsResponse.json();
  if (idsJson.code !== 0) {
    throw new Error(`paragraph ids failed: ${idsJson.code}`);
  }

  const paragraphIds = idsJson.data?.list || [];
  const firstPid = paragraphIds[0]?.pid;
  if (!firstPid) {
    throw new Error("no timestamped subtitle paragraphs");
  }

  const subtitlesResponse = await fetch(
    `/minutes/api/subtitles_v2?paragraph_id=${encodeURIComponent(firstPid)}&size=10000&translate_lang=default&is_fluent=false&filter_speaker=true&object_token=${encodeURIComponent(minuteToken)}&language=zh_cn`,
    { credentials: "include" },
  );
  const subtitlesJson = await subtitlesResponse.json();
  if (subtitlesJson.code !== 0) {
    throw new Error(`subtitles failed: ${subtitlesJson.code}`);
  }

  return {
    minuteToken,
    paragraphIds,
    subtitles: subtitlesJson.data,
  };
}
```

再转换：

```bash
python3 scripts/subtitles_json_to_srt.py \
  subtitles.raw.json \
  zh-CN.srt
```

页面接口属于登录态下的内部实现，可能变化。若路径或返回结构漂移，先检查当前页面网络请求，再做最小调整；不要猜造时间轴。

## 安全边界

- 不输出 cookie、Authorization、tenant token 或 signed URL。
- 临时 URL 过期不影响最终交付；不要把它写入文档。
- 不绕过用户权限或租户访问控制。
- 不把浏览器里可播放误认为已取得原始清晰度。
- 下载后验证时长、短边分辨率、音轨和文件可解码性。
