#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


STRONG_PUNCTUATION = re.compile(r"[。！？!?；;]$")
SOFT_PUNCTUATION = re.compile(r"[，、,]$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert timestamped Feishu Minutes subtitle JSON to SRT."
    )
    parser.add_argument("input_json", type=Path)
    parser.add_argument("output_srt", type=Path)
    return parser.parse_args()


def fail(message: str) -> int:
    print(f"[error] {message}", file=sys.stderr)
    return 1


def normalize_text(value: str) -> str:
    text = value.replace("\u200b", "")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([，。！？；：、,.!?;:])", r"\1", text)
    text = re.sub(r"([（【《])\s+", r"\1", text)
    text = re.sub(r"\s+([）】》])", r"\1", text)
    return text.strip()


def visual_length(text: str) -> int:
    return len(re.sub(r"\s+", "", text))


def format_time(milliseconds: float) -> str:
    value = max(0, round(milliseconds))
    hours, remainder = divmod(value, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"


def find_paragraphs(value: Any) -> list[dict]:
    if isinstance(value, dict):
        paragraphs = value.get("paragraphs")
        if isinstance(paragraphs, list) and paragraphs:
            return [item for item in paragraphs if isinstance(item, dict)]
        for nested in value.values():
            found = find_paragraphs(nested)
            if found:
                return found
    elif isinstance(value, list):
        for nested in value:
            found = find_paragraphs(nested)
            if found:
                return found
    return []


def token_times(token: dict) -> tuple[float, float] | None:
    start = token.get("start_time", token.get("startTime"))
    stop = token.get("stop_time", token.get("end_time", token.get("stopTime")))
    try:
        start_value = float(start)
        stop_value = float(stop)
    except (TypeError, ValueError):
        return None
    if stop_value <= start_value:
        return None
    return start_value, stop_value


def sentence_tokens(sentence: dict) -> list[dict]:
    contents = sentence.get("contents")
    if isinstance(contents, list):
        tokens = [
            item
            for item in contents
            if isinstance(item, dict)
            and normalize_text(str(item.get("content", item.get("text", ""))))
            and token_times(item)
        ]
        return sorted(tokens, key=lambda item: token_times(item)[0])

    text = normalize_text(str(sentence.get("content", sentence.get("text", ""))))
    times = token_times(sentence)
    if text and times:
        return [
            {
                "content": text,
                "start_time": times[0],
                "stop_time": times[1],
            }
        ]
    return []


def wrap_text(text: str) -> str:
    clean = normalize_text(text)
    if visual_length(clean) <= 22:
        return clean
    target = len(clean) // 2
    candidates = [
        index + 1
        for index, char in enumerate(clean)
        if 4 <= index < len(clean) - 4 and (char.isspace() or char in "，、；：,.")
    ]
    split = min(candidates, key=lambda index: abs(index - target)) if candidates else target
    return f"{normalize_text(clean[:split])}\n{normalize_text(clean[split:])}"


def build_captions(paragraphs: list[dict]) -> list[dict]:
    captions: list[dict] = []
    seen_paragraphs: set[str] = set()

    for paragraph in paragraphs:
        paragraph_id = str(paragraph.get("pid", paragraph.get("id", "")))
        if paragraph_id and paragraph_id in seen_paragraphs:
            continue
        if paragraph_id:
            seen_paragraphs.add(paragraph_id)

        sentences = paragraph.get("sentences")
        if not isinstance(sentences, list):
            sentences = [paragraph]

        for sentence in sentences:
            if not isinstance(sentence, dict):
                continue
            current: list[dict] = []
            start_ms: float | None = None
            stop_ms: float | None = None

            def flush() -> None:
                nonlocal current, start_ms, stop_ms
                text = normalize_text(
                    "".join(
                        str(item.get("content", item.get("text", "")))
                        for item in current
                    )
                )
                if text and start_ms is not None and stop_ms is not None:
                    captions.append(
                        {
                            "start": start_ms,
                            "end": stop_ms,
                            "text": wrap_text(text),
                        }
                    )
                current = []
                start_ms = None
                stop_ms = None

            for token in sentence_tokens(sentence):
                times = token_times(token)
                if not times:
                    continue
                if start_ms is None:
                    start_ms = times[0]
                stop_ms = times[1]
                current.append(token)
                text = normalize_text(
                    "".join(
                        str(item.get("content", item.get("text", "")))
                        for item in current
                    )
                )
                duration = stop_ms - start_ms
                last = normalize_text(str(token.get("content", token.get("text", ""))))
                should_flush = (
                    visual_length(text) >= 30
                    or (duration >= 5_000 and visual_length(text) >= 10)
                    or (STRONG_PUNCTUATION.search(last) and visual_length(text) >= 8)
                    or (SOFT_PUNCTUATION.search(last) and visual_length(text) >= 24)
                )
                if should_flush:
                    flush()
            if current:
                flush()

    captions.sort(key=lambda item: (item["start"], item["end"]))
    for index, caption in enumerate(captions):
        following = captions[index + 1] if index + 1 < len(captions) else None
        if caption["end"] - caption["start"] < 700:
            target_end = caption["start"] + 1_200
            if following:
                target_end = min(target_end, following["start"] - 80)
            caption["end"] = max(caption["start"] + 300, target_end)
        if following and caption["end"] >= following["start"]:
            caption["end"] = max(caption["start"] + 300, following["start"] - 80)
    return [item for item in captions if item["end"] > item["start"]]


def write_srt(path: Path, captions: list[dict]) -> None:
    blocks = []
    for index, caption in enumerate(captions, start=1):
        blocks.append(
            "\n".join(
                [
                    str(index),
                    f"{format_time(caption['start'])} --> {format_time(caption['end'])}",
                    caption["text"],
                ]
            )
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n\n".join(blocks) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    if not args.input_json.is_file():
        return fail(f"input JSON not found: {args.input_json}")
    try:
        data = json.loads(args.input_json.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return fail(f"could not read subtitle JSON: {exc}")

    paragraphs = find_paragraphs(data)
    if not paragraphs:
        return fail("no timestamped subtitle paragraphs found")
    captions = build_captions(paragraphs)
    if not captions:
        return fail("subtitle JSON contained no usable timed captions")
    write_srt(args.output_srt, captions)
    print(f"[ok] wrote {len(captions)} captions: {args.output_srt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
