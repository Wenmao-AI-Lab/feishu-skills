#!/usr/bin/env bash
set -euo pipefail

skill_dir=$(cd "$(dirname "$0")/.." && pwd)
export PYTHONDONTWRITEBYTECODE=1

python3 -m unittest discover -s "$skill_dir/tests" -p 'test_*.py' -v

validator="${CODEX_HOME:-$HOME/.codex}/skills/.system/skill-creator/scripts/quick_validate.py"
if [[ -f "$validator" ]]; then
  python3 "$validator" "$skill_dir"
fi

bash -n "$skill_dir/scripts/mux_subtitles.sh"
