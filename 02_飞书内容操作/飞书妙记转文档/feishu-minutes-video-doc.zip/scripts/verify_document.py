#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable


DEFAULT_FORBIDDEN_PHRASES = (
    "已将本地高清字幕版视频上传为新的飞书妙记",
    "妙记的字幕与智能纪要可能需要生成时间",
    "本文档基于本地录屏与转写整理",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Verify the final Feishu Minutes document by exact token."
    )
    parser.add_argument("--fetch-json", required=True, type=Path)
    parser.add_argument("--blocks-json", type=Path)
    parser.add_argument("--new-minute-token", required=True)
    parser.add_argument("--forbidden-token", action="append", default=[])
    parser.add_argument("--forbidden-phrase", action="append", default=[])
    parser.add_argument("--section-heading")
    parser.add_argument("--require-preview", action="store_true")
    return parser.parse_args()


def fail(message: str) -> int:
    print(f"[error] {message}", file=sys.stderr)
    return 1


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ValueError(f"could not read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: {exc}") from exc


def strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for nested in value.values():
            yield from strings(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from strings(nested)


def dicts(value: Any) -> Iterable[dict]:
    if isinstance(value, dict):
        yield value
        for nested in value.values():
            yield from dicts(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from dicts(nested)


def contains(value: Any, needle: str) -> bool:
    return any(needle in item for item in strings(value))


def is_preview_block(block: dict) -> bool:
    block_type = block.get("block_type")
    if block_type in (26, "26", "iframe", "link_preview", "embed"):
        return True
    for key in ("iframe", "link_preview", "embed"):
        value = block.get(key)
        if isinstance(value, dict) and value:
            return True
    return False


def main() -> int:
    args = parse_args()
    try:
        fetch_data = load_json(args.fetch_json)
        blocks_data = load_json(args.blocks_json) if args.blocks_json else None
    except ValueError as exc:
        return fail(str(exc))

    fetch_text = "\n".join(strings(fetch_data))
    combined_text = fetch_text
    if blocks_data is not None:
        combined_text += "\n" + "\n".join(strings(blocks_data))

    if args.new_minute_token not in fetch_text:
        return fail("new minute token is missing from fetched document")

    for token in args.forbidden_token:
        if token and token in combined_text:
            return fail("forbidden token is present in final document")

    for phrase in (*DEFAULT_FORBIDDEN_PHRASES, *args.forbidden_phrase):
        if phrase and phrase in fetch_text:
            return fail(f"forbidden process phrase is present: {phrase}")

    if args.section_heading:
        heading_index = fetch_text.rfind(args.section_heading)
        token_index = fetch_text.rfind(args.new_minute_token)
        if heading_index < 0:
            return fail(f"required section heading is missing: {args.section_heading}")
        if token_index < heading_index:
            return fail("new minute token is not inside the required final section")

    if args.require_preview:
        if blocks_data is None:
            return fail("--require-preview needs --blocks-json")
        candidates = [
            block
            for block in dicts(blocks_data)
            if (
                "block_type" in block
                or "block_id" in block
                or any(key in block for key in ("iframe", "link_preview", "embed"))
            )
            and contains(block, args.new_minute_token)
        ]
        if not any(is_preview_block(block) for block in candidates):
            return fail("exact new minute token is not inside a preview block")

    print("[ok] final document passed token, privacy, and preview verification")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
