#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  mux_subtitles.sh INPUT_VIDEO SUBTITLES OUTPUT.mp4 [--burn-in]

Default mode adds one default Chinese mov_text subtitle track without
re-encoding video or audio. --burn-in renders subtitles into the video.
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 3 || $# -gt 4 ]]; then
  usage >&2
  exit 2
fi

input=$1
subtitles=$2
output=$3
mode=${4:-}
script_dir=$(cd "$(dirname "$0")" && pwd)

if [[ ! -f "$input" ]]; then
  echo "[error] input video not found: $input" >&2
  exit 1
fi
if [[ ! -f "$subtitles" ]]; then
  echo "[error] subtitle file not found: $subtitles" >&2
  exit 1
fi
if [[ "$input" == "$output" ]]; then
  echo "[error] output must differ from input" >&2
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "[error] ffmpeg is required but was not found in PATH" >&2
  exit 1
fi

case "$mode" in
  "")
    ffmpeg -hide_banner -loglevel warning -y \
      -i "$input" \
      -i "$subtitles" \
      -map 0:v:0 \
      -map '0:a?' \
      -map 1:0 \
      -map_metadata 0 \
      -c:v copy \
      -c:a copy \
      -c:s mov_text \
      -metadata:s:s:0 language=zho \
      -metadata:s:s:0 title="Chinese subtitles" \
      -disposition:s:0 default \
      -movflags +faststart \
      "$output"
    python3 "$script_dir/verify_media.py" \
      "$output" \
      --kind video \
      --require-subtitle-track
    ;;
  "--burn-in")
    ffmpeg_filters=$(ffmpeg -hide_banner -filters 2>/dev/null || true)
    if ! grep -qE '(^|[[:space:]])subtitles[[:space:]]' <<<"$ffmpeg_filters"; then
      echo "[error] --burn-in requires an ffmpeg build with the subtitles/libass filter" >&2
      exit 1
    fi
    temporary_dir=$(mktemp -d "${TMPDIR:-/tmp}/feishu-minutes-subs.XXXXXX")
    temporary_srt="$temporary_dir/subtitles.srt"
    cleanup() {
      rm -f "$temporary_srt"
      rmdir "$temporary_dir" 2>/dev/null || true
    }
    trap cleanup EXIT
    ffmpeg -hide_banner -loglevel error -y \
      -i "$subtitles" \
      "$temporary_srt"
    ffmpeg -hide_banner -loglevel warning -y \
      -i "$input" \
      -map 0:v:0 \
      -map '0:a?' \
      -vf "subtitles=filename='${temporary_srt}':force_style='FontName=PingFang SC,FontSize=18,Outline=1,Shadow=0,MarginV=28'" \
      -c:v libx264 \
      -crf 18 \
      -preset medium \
      -c:a copy \
      -movflags +faststart \
      "$output"
    python3 "$script_dir/verify_media.py" "$output" --kind video
    ;;
  *)
    echo "[error] unknown option: $mode" >&2
    usage >&2
    exit 2
    ;;
esac
