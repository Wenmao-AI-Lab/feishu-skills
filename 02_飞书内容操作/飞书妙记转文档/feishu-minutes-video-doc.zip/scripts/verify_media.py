#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Strictly verify downloaded or subtitled Minutes media."
    )
    parser.add_argument("media", type=Path)
    parser.add_argument(
        "--kind",
        choices=("auto", "video", "audio"),
        default="auto",
        help="Required media kind. auto accepts audio or video.",
    )
    expected = parser.add_mutually_exclusive_group()
    expected.add_argument("--expected-duration-seconds", type=float)
    expected.add_argument("--expected-duration-ms", type=float)
    parser.add_argument(
        "--duration-tolerance",
        type=float,
        default=0.02,
        help="Relative duration tolerance (default: 0.02).",
    )
    parser.add_argument(
        "--min-short-side",
        type=int,
        default=720,
        help="Minimum video short side in pixels; 0 disables the quality gate.",
    )
    parser.add_argument("--require-subtitle-track", action="store_true")
    return parser.parse_args()


def fail(message: str) -> int:
    print(f"[error] {message}", file=sys.stderr)
    return 1


def probe(path: Path) -> dict:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError(result.stderr.strip() or "ffprobe could not decode the file")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError("ffprobe returned invalid JSON") from exc


def main() -> int:
    args = parse_args()
    if not args.media.is_file():
        return fail(f"file not found: {args.media}")
    if not shutil.which("ffprobe"):
        return fail("ffprobe is required but was not found in PATH")
    if args.duration_tolerance < 0:
        return fail("duration tolerance must be non-negative")
    if args.min_short_side < 0:
        return fail("minimum short side must be non-negative")

    try:
        data = probe(args.media)
    except ValueError as exc:
        return fail(str(exc))

    streams = data.get("streams") or []
    video_streams = [s for s in streams if s.get("codec_type") == "video"]
    audio_streams = [s for s in streams if s.get("codec_type") == "audio"]
    subtitle_streams = [s for s in streams if s.get("codec_type") == "subtitle"]

    if args.kind == "video" and not video_streams:
        return fail("no decodable video stream")
    if args.kind == "audio" and not audio_streams:
        return fail("no decodable audio stream")
    if args.kind == "auto" and not (video_streams or audio_streams):
        return fail("no decodable audio or video stream")

    resolution = "audio-only"
    if video_streams:
        primary = video_streams[0]
        width = int(primary.get("width") or 0)
        height = int(primary.get("height") or 0)
        if width <= 0 or height <= 0:
            return fail("video stream has invalid dimensions")
        resolution = f"{width}x{height}"
        short_side = min(width, height)
        if args.min_short_side and short_side < args.min_short_side:
            return fail(
                f"video short side {short_side}px is below required "
                f"{args.min_short_side}px ({resolution})"
            )

    try:
        duration = float((data.get("format") or {}).get("duration"))
    except (TypeError, ValueError):
        return fail("media duration is missing or invalid")
    if duration <= 0:
        return fail("media duration must be positive")

    expected = args.expected_duration_seconds
    if args.expected_duration_ms is not None:
        expected = args.expected_duration_ms / 1000.0
    if expected is not None:
        if expected <= 0:
            return fail("expected duration must be positive")
        allowed = max(1.0, expected * args.duration_tolerance)
        delta = abs(duration - expected)
        if delta > allowed:
            return fail(
                f"duration {duration:.3f}s differs from expected "
                f"{expected:.3f}s by {delta:.3f}s; allowed {allowed:.3f}s"
            )

    if args.require_subtitle_track:
        if not subtitle_streams:
            return fail("required subtitle track is missing")
        languages = {
            str((stream.get("tags") or {}).get("language", "")).lower()
            for stream in subtitle_streams
        }
        accepted = {"chi", "zho", "zh", "zh-cn", "cmn"}
        if languages and not (languages & accepted):
            return fail(
                "subtitle track exists but is not marked Chinese "
                f"(languages: {', '.join(sorted(languages)) or 'unknown'})"
            )

    print(
        "[ok] media verified: "
        f"duration={duration:.3f}s resolution={resolution} "
        f"audio={len(audio_streams)} subtitles={len(subtitle_streams)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
