---
slug: feishu-minutes-video-doc
displayName: 飞书妙记视频纪要
version: 1.0.3
summary: 一小时会议录像，散会十分钟变三样东西🎬 高清字幕视频+五分钟读完的结构化纪要+可回查逐字稿，妙记链接或本地录音丢过来就行
license: MIT
homepage: 
iconUrl: https://-1388575217.cos.accelerate.myqcloud.com/skill-icons/uploads/522425/feb0938bef0342c4bae0bf98922d4f10.png
name: feishu-minutes-video-doc
description: 飞书妙记视频/音频到高清字幕视频与可视化纪要文档的端到端工作流。Use when the user provides a Feishu/Lark Minutes URL、妙记链接或本地录音录像，并要求下载妙记、处理音频、添加中文字幕、提炼逐字稿、生成飞书纪要文档、上传高清媒体为新妙记，或把文档中的妙记链接切换为预览视图。Triggers include 飞书妙记、妙记处理、录屏、录音、音频文件、下载视频、中文字幕、视频纪要、可视化纪要、上传妙记、高清视频妙记、链接预览、预览视图。
---

# Feishu Minutes Video Doc · 飞书妙记视频纪要

## 这是什么

一小时的会议录像，散会后你想要的其实是三样东西：**能直接转发的高清字幕视频**、
**能五分钟读完的结构化纪要**、**能随时回查的逐字稿**。这个技能让 Agent 一条龙做完 🎬

**什么时候用我：**

- 丢一个妙记链接：「下载这个妙记，加中文字幕，出一份纪要文档」
- 丢一个本地录音/录屏：「转成飞书纪要 + 逐字稿」
- 「把这个视频重新上传成高清妙记，文档里给我预览入口」

**流水线全景：**

```text
妙记链接 / 本地音视频
   → 下载并校验媒体（ffprobe 实测，不凭文件名判断）
   → 音频处理 → 时间轴中文字幕（ffmpeg 压制）
   → 逐字稿提炼 → 结构化纪要（要点/待办/章节）
   → 写入飞书文档 + 上传高清媒体为新妙记
   → 文档末尾挂可直接预览的妙记入口
```

**三步上手**：① 安装本技能 → ② 装好 `lark-cli` 并登录你的飞书（媒体处理需本机有 `ffmpeg`）→
③ 对 Agent 说「处理这个妙记 <链接>」。

**边界明牌**：转写走飞书妙记原生能力，不引入第三方转写服务；只处理你有权限访问的
妙记与文档。真身与更新：

---

把飞书妙记或本地音视频整理成可交付成果：经过验证的本地媒体、时间轴字幕、基于逐字稿的结构化纪要、新生成的高清妙记，以及文档末尾可直接预览的妙记入口。

## 必读与工具

开始前读取当前环境中的 `lark-shared`、`lark-minutes`、`lark-drive`、`lark-doc`；需要会议产物边界时再读 `lark-vc`。执行 CLI 命令前优先读取与当前 `lark-cli` 同版本的说明：

```bash
lark-cli skills read lark-minutes
lark-cli skills read lark-minutes references/lark-minutes-download.md
lark-cli skills read lark-minutes references/lark-minutes-detail.md
lark-cli skills read lark-minutes references/lark-minutes-upload.md
lark-cli skills read lark-doc references/lark-doc-create.md
lark-cli skills read lark-doc references/lark-doc-update.md
```

使用：

- `lark-cli` 读取、下载和上传妙记，创建与读取飞书文档。
- `ffmpeg`、`ffprobe` 和本 Skill 的脚本处理、验证媒体。
- 当前平台可用且能复用用户登录态的 Browser、Chrome、Playwright 或 Computer Use 工具处理字幕页面接口和预览视图。不要硬编码某个 Agent 的安装路径或本地端口。

## 完成标准

只有同时满足适用项才算完成：

- 下载文件的时长与妙记元数据一致；视频短边默认不低于 720 像素。
- 视频任务存在有效中文字幕文件；软字幕成片必须读回字幕流。
- 音频任务走音频分支，不因缺少视频流而误报“不支持”。
- 纪要以逐字稿为主要证据，保留重要数字、时间点、决策、责任人与不确定项。
- 最终文档不含原始妙记 URL/token、临时 signed URL、cookie 或制作过程说明。
- 高清字幕视频或音频已上传为新的妙记，并读回新 token。
- 文末入口指向新妙记，已切换为预览视图；验收必须绑定新 token，不能只检查任意 iframe。
- 飞书文档已保存并通过 API 读回；预览卡片另有浏览器截图证据。

## 流程

### 1. 确认输入与分支

从 `https://.../minutes/<minute_token>?...` 的路径最后一段提取 token，忽略查询参数。默认使用用户身份。

区分三类输入：

- **已有妙记 URL**：读取元数据、逐字稿并下载原媒体。
- **本地视频**：若没有时间轴字幕，先上传源视频生成妙记，再取得带时间轴字幕；完成字幕视频后再上传为最终妙记。
- **本地音频**：上传音频生成妙记并取得逐字稿；跳过视频字幕封装，最终文档使用音频妙记预览入口。

源妙记链接属于权限敏感信息。不要把它写入最终文档、截图说明、共享文件名或最终回复。新生成的妙记链接可以作为交付入口。

### 2. 读取元数据与逐字稿

```bash
lark-cli minutes minutes get \
  --as user \
  --minute-token "$SOURCE_TOKEN"

lark-cli minutes +detail \
  --as user \
  --minute-tokens "$SOURCE_TOKEN" \
  --summary --todo --chapter --keyword --transcript \
  --output-dir "$WORKDIR" \
  --overwrite
```

妙记基础信息中的 `duration` 使用毫秒。验证媒体时传给 `--expected-duration-ms`，不要直接当秒数使用。

总结任务必须阅读完整逐字稿。AI summary、chapter、todo 只用于索引和交叉检查，不能替代逐字稿证据。文档质量规则见 `references/document-quality.md`。

### 3. 下载并验证媒体

优先使用官方接口：

```bash
lark-cli minutes +download \
  --as user \
  --minute-tokens "$SOURCE_TOKEN" \
  --output-dir "$WORKDIR" \
  --overwrite
```

视频：

```bash
python3 scripts/verify_media.py "$VIDEO" \
  --kind video \
  --expected-duration-ms "$DURATION_MS"
```

音频：

```bash
python3 scripts/verify_media.py "$AUDIO" \
  --kind audio \
  --expected-duration-ms "$DURATION_MS"
```

低于高清门槛必须停止，不得把警告当成功。只有用户明确接受源文件本身较低分辨率时，才可用 `--min-short-side 0` 放宽，并在交付说明中明确质量限制。

官方下载因权限、租户能力或接口限制失败后，才使用登录浏览器提取受保护媒体；见 `references/media-extraction.md`。不要在日志或回复中打印 cookie、tenant token 或临时媒体 URL。

### 4. 准备中文字幕

字幕来源优先级：

1. 妙记页面或用户提供的 `.srt` / `.vtt`。
2. 妙记页面返回的带毫秒时间戳字幕 JSON。
3. 只有无时间轴逐字稿时，先说明限制；未经用户确认，不要伪造精确时间。

把页面字幕 JSON 转成 SRT：

```bash
python3 scripts/subtitles_json_to_srt.py \
  "$WORKDIR/subtitles.raw.json" \
  "$WORKDIR/zh-CN.srt"
```

默认使用软字幕，避免重编码和清晰度损失：

```bash
bash scripts/mux_subtitles.sh \
  "$VIDEO" \
  "$WORKDIR/zh-CN.srt" \
  "$WORKDIR/video.中文字幕.mp4"
```

只有目标播放器无法显示软字幕时才使用 `--burn-in`：

```bash
bash scripts/mux_subtitles.sh \
  "$VIDEO" \
  "$WORKDIR/zh-CN.srt" \
  "$WORKDIR/video.烧录字幕.mp4" \
  --burn-in
```

烧录模式要求当前 `ffmpeg` 包含 `subtitles/libass` 滤镜；脚本会先检测，能力缺失时明确停止。不要在缺少滤镜时静默降级为无字幕视频，改用软字幕或安装带 libass 的 ffmpeg 构建。

软字幕成片再次验证：

```bash
python3 scripts/verify_media.py "$SUBTITLED_VIDEO" \
  --kind video \
  --expected-duration-ms "$DURATION_MS" \
  --require-subtitle-track
```

### 5. 生成结构化纪要

先按 `references/document-quality.md` 建立证据清单，再生成正文。默认结构按内容取舍：

- `Brief 简介`
- `一页结论`
- `关键议题与证据`
- `可视化总览`
- `行动清单 / 风险与待确认`
- `时间线速览`
- 视频任务：`高清视频妙记`
- 音频任务：`高清音频妙记`

可视化必须承载真实关系、流程、数字或时间线，不为装饰而添加。优先使用飞书原生表格、callout、grid 或画板。

创建文档时使用当前 v2 接口，默认 XML：

```bash
lark-cli docs +create \
  --api-version v2 \
  --as user \
  --title "$TITLE" \
  --content "@$WORKDIR/minutes-doc.xml"
```

编辑已有文档时使用 `--command` 与 `--content`，不要使用旧版参数：

```bash
lark-cli docs +update \
  --api-version v2 \
  --as user \
  --doc "$DOC_URL" \
  --command append \
  --content "@$WORKDIR/final-section.xml"
```

### 6. 上传为新的妙记

视频上传字幕成片；音频上传经过验证的原音频：

```bash
lark-cli drive +upload \
  --as user \
  --file "$FINAL_MEDIA"

lark-cli minutes +upload \
  --as user \
  --file-token "$FILE_TOKEN"
```

支持的音频包括 `wav`、`mp3`、`m4a`、`aac`、`ogg`、`wma`、`amr`；音视频不得超过当前平台限制。始终以当前 `lark-cli minutes +upload --help` 为准。

妙记生成是异步过程。当前命令支持时使用 `minutes +detail --wait-ready`；否则对 `2091003` 做有上限的间隔轮询。不要把“处理中”“稍后刷新”等制作说明写进文档。只有读回新 token、标题和产物状态后，才继续添加预览入口。

### 7. 放置并切换预览入口

文档末尾只放标题和新妙记链接，不添加制作过程描述：

```xml
<h2>高清视频妙记</h2>
<p><a href="https://tenant.feishu.cn/minutes/NEW_TOKEN">https://tenant.feishu.cn/minutes/NEW_TOKEN</a></p>
```

音频任务把标题改为 `高清音频妙记`。

打开文档，精确定位包含 `NEW_TOKEN` 的链接，选择 `链接视图` → `预览视图`，等待云端保存。具体步骤与验收见 `references/preview-card.md`。

### 8. 最终读回

```bash
lark-cli docs +fetch \
  --api-version v2 \
  --as user \
  --doc "$DOC_URL" \
  --detail full \
  --doc-format xml \
  > "$WORKDIR/final-doc.json"

lark-cli api GET "/open-apis/docx/v1/documents/$DOC_ID/blocks" \
  --as user \
  --params '{"page_size":500,"document_revision_id":-1}' \
  > "$WORKDIR/final-blocks.json"

python3 scripts/verify_document.py \
  --fetch-json "$WORKDIR/final-doc.json" \
  --blocks-json "$WORKDIR/final-blocks.json" \
  --new-minute-token "$NEW_TOKEN" \
  --forbidden-token "$SOURCE_TOKEN" \
  --section-heading "高清视频妙记" \
  --require-preview
```

音频任务相应使用 `--section-heading "高清音频妙记"`。再检查浏览器截图中卡片已加载、链接不是裸链接、文档显示已保存。

最终回复提供文档 URL；新妙记 URL 仅在有助于交付时提供。不要重复原始妙记 URL。

## 资源

- `scripts/verify_media.py`：严格验证视频/音频、时长单位、高清门槛和字幕流。
- `scripts/subtitles_json_to_srt.py`：把妙记页面的时间戳字幕 JSON 转成 SRT。
- `scripts/mux_subtitles.sh`：封装软字幕或烧录字幕，并读回验证。
- `scripts/verify_document.py`：按新旧 token、禁用文案和预览 block 验收最终文档。
- `scripts/check.sh`：运行回归测试、CLI 合约检查和 Skill 格式校验。
- `references/media-extraction.md`：官方下载失败后的浏览器媒体与字幕提取。
- `references/document-quality.md`：逐字稿证据、可视化和文档内容标准。
- `references/preview-card.md`：新妙记预览视图切换与双重读回。
