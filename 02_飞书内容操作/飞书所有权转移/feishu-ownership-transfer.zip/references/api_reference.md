# 飞书权限转移 API 参考

## 1. 获取 Tenant Access Token

**接口** `POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal`

**请求头**
```json
{ "Content-Type": "application/json" }
```

**请求体**
```json
{
  "app_id": "cli_aa84d112a0f89cc9",
  "app_secret": "P2fclU2OC93Z45SUeaG3JehOET1IyNs6"
}
```

**响应**
```json
{
  "code": 0,
  "msg": "ok",
  "tenant_access_token": "t-xxx",
  "expire": 7200
}
```

> Token 有效期 7200 秒（2 小时），过期需重新获取。

---

## 2. 转移文档/表格所有权

**接口** `POST https://open.feishu.cn/open-apis/drive/v1/permissions/{docToken}/members/transfer_owner?type={type}`

**查询参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `need_notification` | bool | 否 | 是否通知新所有者，默认 `false` |
| `old_owner_perm` | string | 否 | 转让后原所有者权限，默认 `full_access` |
| `remove_old_owner` | bool | 否 | 是否移除原所有者，默认 `false` |
| `type` | string | **是** | 文档类型，见下方对照表 |

**请求头**
```json
{
  "Content-Type": "application/json",
  "Authorization": "Bearer {tenant_access_token}"
}
```

**请求体**
```json
{
  "member_id": "{user_open_id}",
  "member_type": "openid"
}
```

**响应（成功）**
```json
{
  "code": 0,
  "data": {},
  "msg": "Success"
}
```

**响应（失败）**
```json
{
  "code": 99991663,
  "msg": "Invalid access token for authorization."
}
```

---

## 3. 文档类型对照表（type 参数）

| type 值 | 说明 |
|---------|------|
| `docx` | 飞书文档（新版） |
| `doc` | 飞书文档（旧版） |
| `sheet` | 飞书电子表格 |
| `bitable` | 飞书多维表格 |
| `file` | 飞书云盘文件 |
| `wiki` | 飞书知识库节点 |
| `slides` | 飞书幻灯片 |
| `mindnote` | 飞书思维笔记 |
| `minutes` | 飞书妙记 |
| `folder` | 飞书云盘文件夹 |

---

## 4. 错误码

| 错误码 | 说明 | 处理 |
|--------|------|------|
| `0` | 成功 | — |
| `99991661` | 缺少 access token | 在请求头中加上 `Authorization` |
| `99991663` | access token 无效或过期 | 重新获取 token |
| `99991664` | access token 已过期 | 重新获取 token |

---

## 5. 完整调用示例（Python）

```python
import requests

# Step 1: 获取 token
token_resp = requests.post(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": "cli_aa84d112a0f89cc9", "app_secret": "P2fclU2OC93Z45SUeaG3JehOET1IyNs6"},
    headers={"Content-Type": "application/json"},
    timeout=10
)
token = token_resp.json()["tenant_access_token"]

# Step 2: 转移所有权
transfer_resp = requests.post(
    "https://open.feishu.cn/open-apis/drive/v1/permissions/Ih47dSeNPozWkfxkFaCcHb2enwh/members/transfer_owner",
    params={
        "need_notification": "false",
        "old_owner_perm": "full_access",
        "remove_old_owner": "false",
        "type": "docx"
    },
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}"
    },
    json={
        "member_id": "ou_71d7e2ee2288104c1c92bbba1f42b4c1",
        "member_type": "openid"
    },
    timeout=10
)
print(transfer_resp.json())
```
