#!/usr/bin/env python3
"""转移飞书文档/多维表格所有权（Mac / Windows 通用）

用法:
    python transfer_ownership.py <doc_token> [<member_id>] <doc_type> <token>

    member_id 可省略，会从 FEISHU_OPENID 环境变量读取

参数:
    doc_token  - 文档/表格的 token（来自创建返回值）
    member_id - 目标用户的 open_id（可选，支持环境变量 FEISHU_OPENID）
    doc_type   - 文档类型，如 docx / bitable / sheet
    token      - tenant_access_token（由 get_token.py 输出）
"""
import os
import requests
import sys
import json

def transfer_ownership(doc_token, member_id, doc_type, token):
    url = f"https://open.feishu.cn/open-apis/drive/v1/permissions/{doc_token}/members/transfer_owner"
    params = {
        "need_notification": "false",
        "old_owner_perm": "full_access",
        "remove_old_owner": "false",
        "type": doc_type
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}"
    }
    body = {
        "member_id": member_id,
        "member_type": "openid"
    }

    try:
        resp = requests.post(url, params=params, headers=headers, json=body, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return data.get("code") == 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    # 用法:
    # 4 个参数: python transfer_ownership.py <doc_token> <member_id> <doc_type> <token>
    # 3 个参数: python transfer_ownership.py <doc_token> <-/空> <doc_type> <token>  (member_id 从环境变量读取)
    
    if len(sys.argv) == 5:
        doc_token = sys.argv[1]
        member_id = sys.argv[2]
        doc_type = sys.argv[3]
        token = sys.argv[4]
    elif len(sys.argv) == 4:
        doc_token = sys.argv[1]
        # 第2个参数为占位符，表示从环境变量读取
        doc_type = sys.argv[2]
        token = sys.argv[3]
        
        # 从环境变量或 .env 文件读取 member_id
        member_id = os.environ.get("FEISHU_OPENID")
        if not member_id:
            try:
                env_path = os.path.join(os.path.dirname(__file__), "..", ".env")
                if os.path.exists(env_path):
                    with open(env_path, encoding="utf-8") as f:
                        for line in f:
                            if line.startswith("FEISHU_OPENID="):
                                member_id = line.split("=", 1)[1].strip()
                                break
            except:
                pass
        if not member_id:
            print("ERROR: member_id 未提供，请设置 FEISHU_OPENID 环境变量或在 .env 中配置", file=sys.stderr)
            sys.exit(1)
    else:
        print(__doc__)
        sys.exit(1)

    success = transfer_ownership(doc_token, member_id, doc_type, token)
    sys.exit(0 if success else 1)
