#!/usr/bin/env python3
"""获取飞书 tenant_access_token（Mac / Windows 通用）"""
import requests
import sys
import os
from pathlib import Path

def find_env_file():
    """查找 .env 文件（从脚本目录向上搜索）"""
    script_dir = Path(__file__).resolve().parent
    # 向上搜索3层目录
    for parent in [script_dir] + list(script_dir.parents)[:3]:
        env_path = parent / '.env'
        if env_path.exists():
            return env_path
    return None

def parse_env_file(env_path):
    """解析 .env 文件"""
    env_vars = {}
    with open(env_path, 'r', encoding='utf-8-sig') as f:  # utf-8-sig 自动处理 BOM
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                env_vars[key.strip()] = value.strip()
    return env_vars

# 读取配置
env_path = find_env_file()
if env_path:
    env = parse_env_file(env_path)
    APP_ID = env.get('FEISHU_APP_ID', '')
    APP_SECRET = env.get('FEISHU_APP_SECRET', '')
    if not APP_ID or not APP_SECRET:
        print("ERROR: FEISHU_APP_ID 或 FEISHU_APP_SECRET 未在 .env 文件中配置", file=sys.stderr)
        print(f"请参考 .env.template 文件配置: {env_path.parent / '.env.template'}", file=sys.stderr)
        sys.exit(1)
else:
    print("ERROR: 未找到 .env 文件", file=sys.stderr)
    print("请在技能根目录创建 .env 文件，参考 .env.template", file=sys.stderr)
    sys.exit(1)

url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
headers = {"Content-Type": "application/json"}
body = {"app_id": APP_ID, "app_secret": APP_SECRET}

try:
    resp = requests.post(url, headers=headers, json=body, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if data.get("code") == 0:
        print(data["tenant_access_token"])
    else:
        print(f"ERROR: {data}", file=sys.stderr)
        sys.exit(1)
except Exception as e:
    print(f"ERROR: {e}", file=sys.stderr)
    sys.exit(1)
