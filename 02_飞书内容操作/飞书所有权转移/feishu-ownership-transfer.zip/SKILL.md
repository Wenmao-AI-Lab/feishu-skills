---
name: feishu-ownership-transfer
description: 转移飞书文档/多维表格的所有权给指定用户。触发场景：(1) 使用 feishu_doc 创建文档后自动转移所有权；(2) 用户说"把权限给我"或要求转移文档所有权时；(3) 使用 feishu_bitable_create_app 创建多维表格后。支持 docx / bitable / sheet / doc / file / wiki / slides 等所有飞书文档类型。
---

# Feishu Ownership Transfer

## 概述

飞书文档/多维表格创建后，默认所有者是机器人应用，本技能将所有权转移给请求用户。

## 安装配置

1. 在技能根目录找到 `.env.template` 文件
2. 复制为 `.env`：
   ```bash
   cp .env.template .env
   ```
3. 编辑 `.env`，填入你的飞书应用凭证：
   ```
   FEISHU_APP_ID=你的_app_id
   FEISHU_APP_SECRET=你的_app_secret
   ```
4. 保存后即可使用（脚本会自动读取 `.env` 文件）

> 💡 其他用户拿到技能后，只需修改 `.env` 文件即可，无需改动脚本代码。

## 参数说明

### 静态参数（写死在脚本里，无需传入）

| 参数 | 值 |
|------|-----|
| `member_type` | `openid` |
| `need_notification` | `false` |
| `old_owner_perm` | `full_access` |
| `remove_old_owner` | `false` |

### 动态参数（每次调用需传入）

| 参数 | 来源 | 说明 |
|------|------|------|
| `doc_token` | `feishu_doc create` 或 `feishu_bitable_create_app` 的返回值 | 文档/表格的 token |
| `member_id` | 请求者的 `open_id`（从 inbound context 获取） | 目标用户 ID |
| `type` | 根据创建的文档类型确定 | `docx` / `bitable` / `sheet` 等，见下方对照表 |
| `tenant_access_token` | 动态获取，有效期 2 小时 | 访问令牌 |

**文档类型对照表（type 参数）**

| type 值 | 说明 |
|---------|------|
| `docx` | 飞书文档（新版） |
| `doc` | 飞书文档（旧版） |
| `sheet` | 飞书电子表格 |
| `bitable` | 飞书多维表格 |
| `file` | 飞书云盘文件 |
| `wiki` | 飞书知识库节点 |
| `slides` | 飞书幻灯片 |

## 执行流程

### Step 1：获取 tenant_access_token

```bash
python scripts/get_token.py
```

输出即为 token 字符串，例如：`t-g1045mjWWISWX34URFVSZTJNYO62IMZLWKR7NX`

> ⚠️ 关键：在同一个命令块内获取 token 并立即使用，不要分两次执行，否则 token 在变量传递过程中可能被截断。

### Step 2：转移所有权

```bash
python scripts/transfer_ownership.py <doc_token> <member_id> <type> <token>
```

示例：
```bash
python scripts/transfer_ownership.py \
  Ih47dSeNPozWkfxkFaCcHb2enwh \
  ou_71d7e2ee2288104c1c92bbba1f42b4c1 \
  docx \
  t-g1045mjWWISWX34URFVSZTJNYO62IMZLWKR7NX
```

成功响应：
```json
{ "code": 0, "data": {}, "msg": "Success" }
```

### Step 3：错误处理

| 错误码 | 说明 | 处理 |
|--------|------|------|
| `99991663` | token 无效 | 重新获取 token，并确保同一命令块内使用 |
| `99991664` | token 过期 | 重新获取 token |

## 脚本说明

- **`scripts/get_token.py`** — 获取 `tenant_access_token`，Mac/Windows 通用，依赖 `requests`
- **`scripts/transfer_ownership.py`** — 转移所有权，接受 4 个命令行参数

## 详细 API 文档

参见 `references/api_reference.md`，包含完整的接口说明、请求/响应示例和错误码处理。
