---
name: lark-whiteboard-sticky
slug: lark-whiteboard-sticky-johnliu
displayName: 飞书画板便签墙
version: 1.0.0
summary: 在飞书画板批量创建便签网格（用户旅程地图/看板/矩阵），内置便签字号自动缩放规避与 user_id 必填修复
license: MIT
description: 在飞书画板中批量创建/更新便签（stickyNote）内容，专长便签网格类图表：用户旅程地图（阶段×维度矩阵）、看板、对比矩阵、头脑风暴便签墙。当用户要求把结构化内容写成飞书画板便签、创建用户旅程图/体验地图/便签墙/看板，或在飞书画板中大量使用便签时使用。基于 lark-whiteboard 的 DSL 流程，内置两个官方文档未覆盖的坑的修复：便签文字自动缩放的布局规避、上传时 sticky_note.user_id 必填（否则报 2890002）。一般性画板图表（流程图/架构图等）仍走 lark-whiteboard skill。
---

# 飞书画板便签墙

## 前置条件

- `lark-cli` 已登录 user 身份且 scope 含 `board:whiteboard:node:create`（认证问题走 lark-shared skill）
- `npx -y @larksuite/whiteboard-cli@^0.2.12 -v` 可用
- 画板 DSL 语法、配色、布局通用规则仍参考 lark-whiteboard skill 的 `elements/`，本 skill 只补充便签特有的部分

## Workflow

1. **获取 board_token**
   - 已有画板：从文档 `docs +fetch` 的 `<whiteboard token="xxx"/>` 提取
   - 新建：创建文档时内嵌 `<whiteboard type="blank"></whiteboard>`，或对已有文档 `docs +update --command append --content '<whiteboard type="blank"></whiteboard>'`，取返回 `new_blocks` 中 `block_type == "whiteboard"` 的 `block_token`

2. **写 DSL（diagram.json）**
   - **必读 [references/sticky-font-rules.md](references/sticky-font-rules.md)**：便签字号自动缩放的触发规律和网格布局范式（统一窄列宽 216、纵向叠放、9 色配色）
   - 便签多的网格建议写 `.cjs` 生成脚本产出 JSON，便于调整

3. **本地渲染预览（可选）**：`npx -y @larksuite/whiteboard-cli@^0.2.12 -i diagram.json -o diagram.png`
   - 注意：预览图的便签字号可能与真实画板不一致（预览也模拟 auto font），布局检查可用，字号以真实画板为准

4. **上传**（脚本自动完成：转换 OpenAPI → 注入 sticky_note.user_id → 调用 lark-cli +update）：

   ```bash
   python3 <本skill目录>/scripts/wb_sticky_upload.py diagram.json \
     --board <board_token> --overwrite
   # 多 profile 时加 --profile <名>；--dry-run 只验证 payload 不上传
   ```

   - 全新画板可省略 `--overwrite`；整体重画必须带 `--overwrite`，否则新旧内容重叠
   - 手动上传（不推荐）：若不用脚本，必须先把每个 sticky_note 节点的 `user_id` 设为当前用户 open_id（`lark-cli auth status --json` 查），否则报 2890002 "sticky note user id is empty"

5. **验证**：导出真实画板图片检查
   `lark-cli whiteboard +query --whiteboard-token <token> --output_as image --output ./board.png --as user`
   检查：内容完整无截断、便签无重叠、行列对齐、字号基本一致

## 排错速查

| 症状 | 原因 | 处理 |
|---|---|---|
| 2890002 `invalid resource props [@from@]` / `sticky note user id is empty` | sticky_note.user_id 为空 | 用脚本上传，或手动填当前用户 open_id |
| 部分便签字号异常大 | auto font 触发 | 见 references/sticky-font-rules.md 坑 1，收窄宽度、纵向叠放 |
| 新旧内容重叠 | 未加 --overwrite | 加 --overwrite 重传 |
| 预览图与画板字号不一致 | 预览引擎模拟 auto font | 以画板导出图为准，属正常 |
