# 飞书便签（stickyNote）实战经验规则

> 本文是实测总结（whiteboard-cli 0.2.13 + lark-cli 1.0.66），官方文档未覆盖。写 DSL 前必读。

## 坑 1：便签文字自动缩放（auto font）

stickyNote 的文字字号**不完全受 DSL `fontSize` 控制**。引擎会在便签有富余空间时放大文字去"填满"便签。实测触发规律：

| 场景 | 结果 |
|---|---|
| 固定宽度 ≤ ~250px，height fit-content | 不缩放，字号正常 |
| 固定宽度 440px，所在 flex 行被其他内容撑高 | 短文字放大 ~1.5-2x |
| 宽度 `fill-container` | 放大（宽度被拉宽即触发） |
| height 被 stretch 拉高（父容器 alignItems: stretch 的直接子节点） | 严重放大（2-4x） |
| 同一行内长文字便签 vs 短文字便签，同宽 | 短文字放大更多（富余空间更多） |

**稳定做法（便签网格必守）：**

1. 所有便签统一**固定窄宽度 200-240px**（推荐 216），高度一律 `fit-content`
2. 单元格内容多（如早/晚两个场景）时**纵向叠放两张窄便签**，不要加宽单张便签
3. 便签不要用 `fill-container` 宽度
4. 便签不要作为 `alignItems: 'stretch'` 容器的直接子节点；外面套一层 `alignItems: 'start'` 的 frame
5. 即便如此，内容极短（<10 字）的便签在被撑高的行里仍可能略大 —— 同宽便签的差异在可接受范围，属飞书原生行为，不要继续死磕

## 坑 1 的终极解法：等高网格改用 rect 卡片 + 全绝对定位（推荐）

当网格要求**卡片等高等宽 + 字号完全统一**（如阶段×维度旅程地图），便签的 auto font 无法同时满足两者（等高必触发短文字放大）。此时放弃 stickyNote，改用 rect：

- **rect 文字永不自动缩放**，可自由设固定宽高
- 两阶段构建（脚本化）：
  1. 先输出全部卡片为顶层 `width: 卡片宽, height: 'fit-content'` 的 rect，用 `whiteboard-cli -i measure.json -o m.png -l coords.json` 测得每张卡自然高度（coords.json 是按 id 键控的 dict，含 absX/absY/width/height）
  2. 按"子行高 = 行内最大自然高度 + padding"计算全网格坐标，所有节点（背景网格、表头、行标签、单元格白底、卡片、SVG 标签）全部以顶层 x/y 绝对定位输出
- 卡片阴影：卡片下层垫一个偏移 (1,2)、`opacity: 0.09`、同色圆角 rect
- 右向箭头标签（如「晚」）：SVG `polygon` 五边形（`preserveAspectRatio="none"`）+ `opacity: 0` 的透明 rect 承载文字
- 网格线：底层铺灰色大 rect，白色单元格 rect 之间留 2px 缝隙露出底色
- 代价：失去便签的纸张质感；节点无 id 时**不要输出 `id: null`**（校验会报 Expected string）

## 坑 2：OpenAPI 上传必填 user_id

`whiteboard-cli --to openapi` 转换出的 sticky_note 节点 `user_id` 为空字符串，直接上传报错：

```
code 2890002: sticky note user id is empty
（首报可能是模板未替换的乱码：invalid resource props [@from@] arg error）
```

**修复**：上传前把每个 sticky_note 节点的 `user_id` 设为当前登录用户的 open_id（`lark-cli auth status --json` 的 `identities.user.openId`），并把 `show_author_info` 设为 `false`（否则每张便签挂作者头像，很吵）。`scripts/wb_sticky_upload.py` 已自动处理。

## 便签网格（旅程地图/看板/矩阵）布局范式

```
root frame (vertical, 固定宽, padding 24, gap 12, 浅色底)
├── header row frame (horizontal, gap 12, alignItems stretch)
│   ├── corner rect (96 宽)
│   └── 每列一个表头 rect (216 宽, 深色底白字)
└── 每个维度一个 row frame (horizontal, gap 12, alignItems stretch)
    ├── 行标签 rect (96 宽, height fill-container)
    └── 每列一个 cell frame (vertical, 216 宽, gap 8, alignItems start)
        └── 1~2 张 stickyNote (216 宽, fit-content 高)
```

- 行按维度配色区分（便签仅支持 9 色）：`#FEF1CE` 黄 `#F5D1A7` 橙 `#DFF5E5` 绿 `#CDF7CC` 浅绿 `#C9E8EF` 蓝 `#D6DCF3` 靛 `#D3CCEE` 紫 `#F1C5E7` 粉 `#F6C8C8` 红
- 便签内用 WBTextRun 实现首行加粗标签（如 `【早】`），正文 fontSize 12，textAlign left + verticalAlign top
- 表头/行标签用 rect（不是便签），文字不会自动缩放
- 内容多的单元格拆多张便签叠放，每张便签一个主题块

## 上传流程

```bash
python3 scripts/wb_sticky_upload.py diagram.json --board <board_token> \
  --overwrite --preview diagram.png
# --dry-run 只转换+修补不上传，用于验证 payload
```

预览 PNG 的便签字号可能与真实画板不同（预览引擎也模拟 auto font），**以画板导出图为准**：
`lark-cli whiteboard +query --whiteboard-token <token> --output_as image --output ./out.png --as user`
