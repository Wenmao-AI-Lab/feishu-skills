#!/usr/bin/env python3
"""Upload a whiteboard-cli DSL file to a Feishu whiteboard as real nodes.

Wraps `whiteboard-cli` (DSL -> OpenAPI conversion) and `lark-cli whiteboard +update`,
working around two known pitfalls:

1. sticky_note.user_id must be the creator's open_id, otherwise the API fails with
   2890002 "sticky note user id is empty". The open_id is auto-resolved from
   `lark-cli auth status` (current user identity).
2. whiteboard-cli emits an envelope {code, data:{result:{nodes}}}; lark-cli +update
   accepts a plain {"nodes": [...]} payload via stdin.

Usage:
  python3 wb_sticky_upload.py diagram.json --board <whiteboard_token> [--overwrite]
      [--profile <lark-cli profile>] [--preview preview.png] [--dry-run]
"""
import argparse
import json
import os
import subprocess
import sys
import time

WB_CLI_PKG = "@larksuite/whiteboard-cli@^0.2.12"
CLI_ENV = {
    **os.environ,
    "LARKSUITE_CLI_NO_UPDATE_NOTIFIER": "1",
    "LARKSUITE_CLI_NO_SKILLS_NOTIFIER": "1",
}


def run(cmd, stdin_text=None):
    proc = subprocess.run(
        cmd,
        input=stdin_text,
        capture_output=True,
        text=True,
        env=CLI_ENV,
    )
    return proc


def resolve_user_open_id(profile=None):
    cmd = ["lark-cli"]
    if profile:
        cmd += ["--profile", profile]
    cmd += ["auth", "status", "--json"]
    proc = run(cmd)
    if proc.returncode != 0:
        sys.exit(f"error: lark-cli auth status failed: {proc.stderr.strip()}")
    data = json.loads(proc.stdout)
    open_id = data.get("identities", {}).get("user", {}).get("openId")
    if not open_id:
        sys.exit("error: no user identity logged in; run `lark-cli auth login` first")
    return open_id


def convert_dsl(dsl_path):
    proc = run([
        "npx", "-y", WB_CLI_PKG, "-i", dsl_path,
        "--to", "openapi", "--format", "json",
    ])
    if proc.returncode != 0:
        sys.exit(f"error: whiteboard-cli conversion failed: {proc.stderr.strip()}")
    envelope = json.loads(proc.stdout)
    return envelope["data"]["result"]["nodes"]


def render_preview(dsl_path, png_path):
    proc = run(["npx", "-y", WB_CLI_PKG, "-i", dsl_path, "-o", png_path])
    if proc.returncode != 0:
        print(f"warn: preview render failed: {proc.stderr.strip()}", file=sys.stderr)
    else:
        print(f"preview written to {png_path}")


def patch_sticky_notes(nodes, open_id, show_author=False):
    sticky_count = 0
    for node in nodes:
        if "sticky_note" in node:
            node["sticky_note"]["user_id"] = open_id
            node["sticky_note"]["show_author_info"] = show_author
            sticky_count += 1
    return sticky_count


def upload(board_token, nodes, profile=None, overwrite=False):
    idem = f"{int(time.time())}-sticky-upload"
    cmd = ["lark-cli"]
    if profile:
        cmd += ["--profile", profile]
    cmd += [
        "whiteboard", "+update",
        "--whiteboard-token", board_token,
        "--source", "-",
        "--input_format", "raw",
        "--idempotent-token", idem,
        "--as", "user",
    ]
    if overwrite:
        cmd.append("--overwrite")
    payload = json.dumps({"nodes": nodes}, ensure_ascii=False)
    proc = run(cmd, stdin_text=payload)
    if proc.returncode != 0:
        sys.exit(f"error: upload failed: {proc.stderr.strip()}")
    result = json.loads(proc.stdout)
    created = result.get("data", {}).get("created_node_ids", "")
    n_created = len([x for x in created.split(",") if x]) if created else 0
    print(f"upload ok: {n_created} nodes created on whiteboard {board_token}")


def main():
    ap = argparse.ArgumentParser(description="Upload DSL sticky-note diagram to Feishu whiteboard")
    ap.add_argument("dsl", help="whiteboard-cli DSL JSON file")
    ap.add_argument("--board", required=True, help="whiteboard token (wbcnXXX or board block_token)")
    ap.add_argument("--profile", help="lark-cli profile name (default: current)")
    ap.add_argument("--overwrite", action="store_true", help="delete existing content before writing")
    ap.add_argument("--show-author", action="store_true", help="show author avatar on sticky notes")
    ap.add_argument("--preview", metavar="PNG", help="also render a local preview PNG")
    ap.add_argument("--dry-run", action="store_true", help="convert and patch only, do not upload")
    args = ap.parse_args()

    if args.preview:
        render_preview(args.dsl, args.preview)

    nodes = convert_dsl(args.dsl)
    open_id = resolve_user_open_id(args.profile)
    sticky_count = patch_sticky_notes(nodes, open_id, args.show_author)
    print(f"converted {len(nodes)} nodes ({sticky_count} sticky notes), user_id={open_id}")

    if args.dry_run:
        print("dry-run: skipping upload")
        return
    upload(args.board, nodes, args.profile, args.overwrite)


if __name__ == "__main__":
    main()
