# 用户确认的飞书画板格式模板（客服全链路项目专用，非全局强制）

> ⚠️ 这是 Amy（陈红）在「客服全链路」项目画板上多次迭代后手动定稿的样式，**仅适用于该画板**。
> 其他主题/其他画板不要套用本模板，格式以用户当次要求为准。
> 基准画板：token `Tj1Cw1IMJh45iQbRhxqcLGDRnId`（文档 https://lxpsvydtpzv.feishu.cn/wiki/YTPnwjqYji0ZyMkiGjAclpWnnDf）

## 结构：三级竖向树（top-down）

```
品牌客诉接入（根）
├── 一级：独立站 | 平台（SC / TK / WALMART）
│   ├── 二级：独立站 → 三级：邮件 / 联系表单 / 社媒邮箱转发 / 电话
│   └── 二级：平台 → 展开为 3 个子节点
│       ├── 二级：SC      → 三级：站内信 / 电话 / A-Z索赔 / 平台申请退货退款
│       ├── 二级：TK      → 三级：站内信 / 电话 / 平台申请退货退款
│       └── 二级：WALMART → 三级：站内信 / 电话 / 平台申请退货退款
```

- 一级 = 大分类（独立站 vs 平台）
- 二级 = 具体来源（独立站 + 3 个平台，共 4 个节点）
- 三级 = 每个来源对应的细节渠道/操作
- 非品牌后续用**完全相同**的三级格式接在下方

## 视觉规则

| 元素 | 规范 |
|------|------|
| 标题文字 | horizontal_align=center, vertical_align=top, font_weight=bold |
| 根字号 | 32px |
| 一级字号 | 24px（如 US/CA/EU/UK、独立站、WALMART、平台） |
| 二级字号 | 26px（如 SC、TK） |
| 详情文字 | horizontal_align=left, vertical_align=top, font_weight=regular, font_size=19px |
| 框填充 | #ffffff（白底） |
| 框边框 | solid, border_color=#e2e8f0, 圆角矩形 |
| 框高度 | 62px（标题框 82px） |
| 框宽度 | **按文字长度自适应**（约 397–478px），不要固定死宽 |
| 色条 | 左侧贴框，6px 宽 × 62px 高 |
| 连线 | 无（不生成 connector / path） |
| 多行 | 详情行可用换行（\n） |

## 平台色条配色（固定映射）

| 平台 | 色值 | 说明 |
|------|------|------|
| 独立站 | `#d97706` | 橙 |
| SC (Amazon Seller Central) | `#db2777` | 粉 |
| TK (TikTok Shop) | `#6366f1` | 紫 |
| WALMART | `#059669` | 绿 |

新增其他来源时，为其指定一个不冲突的固定色并保持全局一致。

## 内容规则（用户自定义，关键）

每条**三级详情行**必须带 **Zendesk 接入状态标注**，格式：

```
渠道描述 → Zendesk已接入
渠道描述 → Zendesk暂未可接入
```

实际示例（来自基准画板）：

- `邮件：hello@ / support@ colamyhome.com → Zendesk已接入`
- `电话：+1 (888) 886-1743 → Zendesk已接入`
- `联系表单：Contact Us 页 → Zendesk已接入`
- `社媒私信 / 邮箱转发 → Zendesk已接入`
- `站内信 → Zendesk已接入`
- `A-Z 平台后台处理 → Zendesk暂未可接入`
- `平台申请退货退款处理 → Zendesk暂未可接入`
- `删除差评处理，平台后台 → Zendesk暂未可接入`

原则：**已接入 Zendesk 系统上回复的标"已接入"，尚未接入的标"暂未可接入"**。

## SVG 生成约定（供脚本参考）

- viewBox 与 width/height 同步（如 `0 0 2400 1000`）
- 用 `<style>` 定义字体族（PingFang SC / Microsoft YaHei 回退）
- 全局 `text { text-decoration: none !important; }`（去下划线）
- 节点用 `<rect>` + `<text>` 配对
- 文字定位：标题 `text-anchor="middle"`、x=框中心；详情 `text-anchor="start"`、x=框左+18
- 飞书解析后 vertical_align 一律变 top，生成时文字 y 取框顶部 + 文字垂直内边距即可
- 不要使用 filter / pattern / clipPath / mask

## 验证清单（交付前必须过）

- [ ] 根节点有文字且居中
- [ ] 4 个二级来源节点齐全（独立站/SC/TK/WALMART），各自带正确色条
- [ ] 每个三级详情行文字入框、无空框
- [ ] 每条详情行带 `→ Zendesk已接入/暂未可接入`
- [ ] 无重复节点（同一平台不应出现两行完全相同的文字）
- [ ] 无连线
- [ ] 导出 raw 复核节点数与文字条数
