#!/usr/bin/env python3
"""
gen_tree_svg.py - 生成符合用户确认格式的飞书画板三级树 SVG

用法:
  python3 gen_tree_svg.py --config tree.json --out tree.svg
  python3 gen_tree_svg.py --config tree.json --out subtree.svg --start-y 600 --board-h 1400

config.json 结构:
{
  "root": "品牌客诉接入",
  "branches": [
    {
      "level1": "独立站US/CA/EU/UK",
      "level2": [
        {"name": "独立站", "color": "#d97706", "items": [
          {"text": "邮件：hello@ / support@ colamyhome.com", "zendesk": "已接入"},
          {"text": "电话：+1 (888) 886-1743", "zendesk": "已接入"}
        ]}
      ]
    },
    {
      "level1": "平台（SC/TK/WALMART）",
      "level2": [
        {"name": "SC", "color": "#db2777", "items": [...]},
        {"name": "TK", "color": "#6366f1", "items": [...]},
        {"name": "WALMART", "color": "#059669", "items": [...]}
      ]
    }
  ]
}

每个 item 自动拼接 " → Zendesk已接入/暂未可接入"（text 已含 → 则不重复加）。
"""
import json
import sys
import math


# ---- 布局常量（与基准画板一致）----
ROW_H = 62          # 详情行高
GAP_Y = 14         # 行间距
L2_W = 460         # 二级框宽
L2_H = 62          # 二级框高
SECTION_H = 82     # 一级/根 框高
COL_GAP = 40       # 列间距
DETAIL_FONT = 19   # 详情字号
C_DETAIL_TXT = "#334155"
C_DARK = "#1e293b"
C_WHITE = "#ffffff"
C_BORDER = "#e2e8f0"
C_ROOT_BG = "#1e293b"
C_ROOT_TXT = "#ffffff"

# 估算文字像素宽度（粗略）：中文/全角≈font*1.0，英文/数字≈font*0.55
def text_w(s, font):
    w = 0.0
    for ch in s:
        if ord(ch) > 0x2E80:  # CJK 及全角标点
            w += font * 1.02
        else:
            w += font * 0.56
    return w


def box_w_for(text, font=DETAIL_FONT, pad=36):
    return max(460, math.ceil(text_w(text, font)) + pad)


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--start-y", type=int, default=0, help="子树片段起始 y（增量拼接用）")
    p.add_argument("--board-w", type=int, default=2400)
    p.add_argument("--board-h", type=int, default=1000)
    args = p.parse_args()

    with open(args.config, encoding="utf-8") as f:
        cfg = json.load(f)

    svg = []
    svg.append(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {args.board_w} {args.board_h}">')
    svg.append('<style>text{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;text-decoration:none!important;}</style>')

    def rect(x, y, w, h, fill, stroke=C_BORDER, sw=1.5, radius=6):
        svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" ry="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

    def bar(x, y, h, color):
        svg.append(f'<rect x="{x}" y="{y}" width="6" height="{h}" rx="3" fill="{color}"/>')

    def t_center(x, y, text, size, color, bold=False):
        fw = "bold" if bold else "normal"
        # 飞书解析后 vertical_align=top，文字 y 取框顶 + 文字高内边距
        svg.append(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="middle" font-size="{size}" font-weight="{fw}" fill="{color}">{text}</text>')

    def t_left(x, y, text, size, color):
        svg.append(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="start" font-size="{size}" fill="{color}">{text}</text>')

    Y_ROOT = args.start_y + 40
    Y_L1 = Y_ROOT + SECTION_H + 40
    Y_L2 = Y_L1 + SECTION_H + 40
    Y_DET = Y_L2 + L2_H + 40

    root = cfg.get("root", "根")
    # 根节点居中（按画板宽）
    RW = 440
    rect(args.board_w // 2 - RW // 2, Y_ROOT, RW, SECTION_H, C_ROOT_BG)
    t_center(args.board_w // 2, Y_ROOT + SECTION_H / 2, root, 32, C_ROOT_TXT, True)

    # 计算每个二级来源列宽，自动排布
    x = 60
    for br in cfg.get("branches", []):
        l1 = br["level1"]
        l2s = br["level2"]
        # 一级标题框宽度 = 列总宽
        col_x = x
        col_w = 0
        col_children = []
        for l2 in l2s:
            items = l2.get("items", [])
            w = L2_W
            max_text = ""
            for it in items:
                t = build_item_text(it)
                tw = box_w_for(t)
                if tw > w:
                    w = tw
                if len(t) > len(max_text):
                    max_text = t
            col_children.append((l2, w, len(items)))
            col_w = max(col_w, w)
        # 一级标题（框横跨整列宽度，文字居中）
        rect(col_x, Y_L1, col_w, SECTION_H, C_WHITE)
        t_center(col_x + col_w // 2, Y_L1 + SECTION_H / 2, l1, 24, C_DARK, True)

        # 二级 + 三级
        cx = col_x
        for l2, w, n_items in col_children:
            # 二级标题
            rect(cx, Y_L2, w, L2_H, C_WHITE)
            bar(cx, Y_L2, L2_H, l2["color"])
            t_center(cx + w / 2, Y_L2 + L2_H / 2, l2["name"], 26, C_DARK, True)
            # 三级详情
            for i, it in enumerate(l2.get("items", [])):
                t = build_item_text(it)
                ry = Y_DET + i * (ROW_H + GAP_Y)
                rect(cx, ry, w, ROW_H, C_WHITE)
                bar(cx, ry, ROW_H, l2["color"])
                t_left(cx + 18, ry + ROW_H / 2, t, DETAIL_FONT, C_DETAIL_TXT)
            cx += w + COL_GAP
        # 整列推进
        x = col_x + col_w + COL_GAP * 2

    svg.append("</svg>")
    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(svg))
    print(f"OK -> {args.out}  (branches={len(cfg.get('branches', []))})")


def build_item_text(it):
    """拼接 Zendesk 状态标注，已含 → 则不重复加。"""
    if isinstance(it, str):
        return it
    text = it.get("text", "")
    if "→" in text or "->" in text:
        return text
    z = it.get("zendesk", "已接入")
    return f"{text} → Zendesk{z}"


if __name__ == "__main__":
    main()
