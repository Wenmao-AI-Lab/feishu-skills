---
name: feishu-whiteboard-editor
description: 在飞书文档中创建与编辑可编辑的结构图/思维导图画板（whiteboard block）。当用户要求"在飞书文档里画一张结构图/架构图/思维导图/流程图/组织图/任一类关系图"，或要对已有飞书画板做增量修改（加分支、改文字、去连线、套用格式）时使用本技能。封装了 lark-cli 命令、画板节点结构、SVG round-trip 有损坑、增量修改铁律，以及一个项目内已确认的格式模板（三级竖向树 + 平台色条 + Zendesk 状态标注，仅作同项目复用参考，非全局强制）。适用于任意主题、任意层级的结构图，不限于客诉/客服场景。
agent_created: true
---

# 飞书可编辑画板编辑技能

## 适用场景

- 在飞书云文档里插入一张**可编辑**的图（双击进入可改节点）：结构图、架构图、思维导图、流程图、组织图、关系图……**任意主题、任意层级、任意布局**都支持。
- 对已有飞书画板做增量修改：加分支、改文字、删连线、套用统一格式。
- 不要预设图的形态——竖向树、横向树、网格、自由连线均可行，以用户当次要求为准。

## 核心命令（lark-cli，用户身份已绑定陈红）

参数名用横线（`--whiteboard-token`，非下划线）：

- **导出当前画板节点**（先看现状，必做）：
  `lark-cli whiteboard +export --whiteboard-token <TOKEN> --output-type raw > wb.json`
  - `raw` 返回所有 native 节点（composite_shape / text_shape / connector），用于增量分析与改写
  - `preview` 导出 jpg 预览图（有缓存，验证时优先用 raw 而非 preview）
  - `svg` / `source` 在画板已解析为 native 节点后通常不可用（"no code blocks found"）

- **写入 SVG（覆盖）**：
  `lark-cli whiteboard +update --whiteboard-token <TOKEN> --input_format svg --source @tree.svg --overwrite`

- **读取文档结构、定位画板 block**：
  `lark-cli docs +fetch --doc "<文档URL或token>" --detail with-ids --scope full --format json`
  - 从 XML 里找 `<whiteboard id="..." token="Tj1...">` 拿到画板 token

- **创建大尺寸画板 block**（默认 600×400 字太小，需扩）：
  `lark-cli api POST /docx/v1/documents/<DOC_ID>/blocks/<DOC_ID>/children`
  body：`{"index":-1,"children":[{"block_type":43,"board":{"align":2,"width":2400,"height":1000}}]}`
  - 返回的 board_token 即为新画板 token

- **删除旧画板 block**（合并/重建后清理）：
  `lark-cli docs +update --doc "<DOC_ID>" --command block_delete --block-id <OLD_BLOCK_ID>`

## 画板节点结构

飞书把 SVG 解析为 native 节点：

- `composite_shape`：矩形框。
  - 宽框（width > 50）→ 文字框（标题/详情容器）
  - 窄条（width ≤ 50，如 6px 宽）→ **色条**（左侧装饰条）
- `text_shape`：独立文字节点（飞书渲染时文字就在节点里，不在 composite_shape.text 内）
- `connector` / `path`：连线（用户不想要时**不要生成**）

坐标系：x/y 是节点**左上角**。font_size 决定文字视觉高度。

## ⚠️ SVG round-trip 有损坑（最重要）

- SVG 导入飞书后变 native 节点；**反向（raw JSON 直编）会被飞书校验拦截**，必须走 SVG 路径改图。
- **不要从空白模板重建整张图**——会覆盖用户在树区域的手动修改。
- 色条必须保持为矢量 `<rect>`，不要让它变成 `<image>`（image 的 src 在后续 round-trip 会丢失，导致节点消失）。
- 避免 `<filter>`/`<pattern>`/`<clipPath>`/`<mask>`，画板不支持，会降级为内嵌图片（不可编辑）。

## ⚠️ 增量修改铁律（用户明确反对覆盖）

每次动画板前：

1. `whiteboard +export --output-type raw > wb.json` 导出**当前全部节点**（含用户所有手动改动）
2. 解析 -> **只做增量 delta**（删某个节点 / 改某个文字 / 加一个分支）
3. 把完整（修改后的）节点拼回一个 SVG
4. `whiteboard +update --input_format svg --overwrite` 带全部内容回去

核心：**保留用户手动内容，任何结构改动基于当前节点 delta，绝不丢旧建新堆叠。**

## 用户已确认的一个格式模板（示例，非全局强制）

> ⚠️ 下面的格式**只属于 Amy 的「客服全链路」项目画板**，是该项目多次迭代后手动定稿的样式。
> **它不适用于其他主题/其他画板**——画一张新的图时，结构、配色、字号一律以用户当次要求为准，不要套用此模板。
> skill 真正通用的是上方「核心命令 / 节点结构 / SVG 有损坑 / 增量铁律」，与图的内容无关。

该模板详细规范见 `references/format-spec.md`，仅供同项目复用例参考，要点：

- 三级竖向树：根（品牌客诉接入）居顶 → 一级（独立站 | 平台）→ 二级（独立站/SC/TK/WALMART）→ 三级（细节行）
- 标题文字居中+顶部对齐、bold；根 32px / L1 24px / L2 26px
- 详情文字左对齐+顶部对齐、regular、19px
- 框白底、浅灰边、圆角、高 62px（标题 82px）
- 左侧 6px 色条，按平台固定配色：独立站橙 `#d97706` / SC粉 `#db2777` / TK紫 `#6366f1` / WALMART绿 `#059669`
- 每条详情行带 **Zendesk 状态标注**：`渠道描述 → Zendesk已接入` 或 `→ Zendesk暂未可接入`
- 无连线

**如果用户在别的画板里给了新格式**：以那次为准，必要时把新格式追加进 `references/`（命名如 `format-spec-<主题>.md`）作为该主题模板，不要覆盖本模板。

## 辅助脚本

- `scripts/gen_tree_svg.py`：输入结构化数据（根/一级/二级/三级 + 平台色条色），输出符合规范的完整 SVG。用于全新画板，或生成「新增分支」的 SVG 片段由 AI 拼接到现有画板。

## 典型工作流

**A. 全新画板**：写 SVG（用脚本或手写，遵循 format-spec）→ 创建大尺寸 board block → `+update --overwrite` 写入。

**B. 增量改现有画板**：
1. 导出 raw
2. 用 Python 解析节点、定位要改/删/加的目标
3. 生成增量后的完整 SVG（保留全部其他节点）
4. `+update --overwrite` 上传
5. 再导出 raw 验证节点数与文字完整性

**C. 加新分支（同主题画板）**：导出 raw → 用脚本生成新分支 SVG 片段（保持与该画板既有格式一致）→ 拼到现有 SVG 末尾（平移坐标避开冲突）→ overwrite。
