# Structured Rebuild Workflow

Read this reference only after native copy is unavailable. Use the current
`lark-cli` bundled `lark-doc`, `lark-drive`, `lark-wiki`, and `lark-shared`
guidance first; current schemas override examples here.

## Contents

- [1. Create a Private Run Directory](#1-create-a-private-run-directory)
- [2. Fetch Replay and Audit Views](#2-fetch-replay-and-audit-views)
- [3. Dry-Run and Create Once](#3-dry-run-and-create-once)
- [4. Repair Media Selectively](#4-repair-media-selectively)
- [5. Handle Large Content](#5-handle-large-content)
- [6. Validate and Classify](#6-validate-and-classify)

## 1. Create a Private Run Directory

Use a task-specific directory outside the repository. Keep a small `run.json`
with the source, resolved destination, created IDs, media mappings, and
validation decisions. Do not place signed URLs, access tokens, cookies, or
base64 media in the run log.

Change into the run directory before using `@file` arguments because the
current CLI accepts relative `@file` paths.

## 2. Fetch Replay and Audit Views

```bash
lark-cli docs +fetch --as user --doc "<source>" \
  --doc-format xml --detail simple --format json > source.replay.json

lark-cli docs +fetch --as user --doc "<source>" \
  --doc-format xml --detail full --format json > source.full.json

jq -r '.data.document.content' source.replay.json > source.xml
jq '.data.document.reference_map // {}' source.replay.json > reference-map.json
```

Reject empty or missing `data.document.content`. Run the media plan before
writing:

```bash
python3 /path/to/feishu-doc-clone/scripts/extract_plan.py \
  --fetch-json source.replay.json \
  --out clone-plan.json
```

The plan is an audit surface. Any file, whiteboard, sheet, bitable, iframe, or
unsupported block must have a final disposition.

## 3. Dry-Run and Create Once

Use the exact parent resolved earlier:

```bash
lark-cli docs +create --as user \
  --doc-format xml \
  --content @source.xml \
  --reference-map @reference-map.json \
  --parent-token "<folder_or_wiki_parent_token>" \
  --dry-run
```

If no destination was specified, use `--parent-position my_library` instead.
Review the dry-run body, then run the same command without `--dry-run`.

Read `data.document.document_id` and `data.document.url` from the result. If a
background task or partial result is returned, resolve the final token before
continuing. Never identify the result only by title when duplicate titles
exist.

## 4. Repair Media Selectively

First inspect create warnings and re-fetch the result. Do not rebuild every
image merely because the source contains images.

For each missing image:

1. Use the source `<img url>` or Markdown image URL while it remains valid.
2. Try `docs +media-preview`, then `docs +media-download`.
3. Use `browser-image-extraction.md` only when the authenticated browser can
   render media that the API cannot return.
4. Upload the recovered local file to the target document.
5. Record `source_key`, `file_token`, returned block ID, dimensions, and hash.

Build fallback content only after the complete explicit token map exists:

```bash
python3 /path/to/feishu-doc-clone/scripts/assemble_markdown.py \
  --plan clone-plan.json \
  --token-map token-map.json \
  --out replay-with-media.xml
```

The assembler emits current `<img>` tags. It refuses missing image and
whiteboard mappings rather than pairing uploads by position.

## 5. Handle Large Content

Prefer one create call. If the current API returns a proven request-size
failure, split only the fallback content:

```bash
python3 /path/to/feishu-doc-clone/scripts/split_markdown.py \
  --in replay-with-media.xml \
  --out-dir chunks
```

Inspect `oversize_chunks`; do not submit one blindly. Append chunks serially
with the current `docs +update --command append` interface and re-fetch after
each append. A mismatch stops the run.

## 6. Validate and Classify

```bash
lark-cli docs +fetch --as user --doc "<final_doc_id>" \
  --doc-format xml --detail full --format json > final.full.json

python3 /path/to/feishu-doc-clone/scripts/compare_clone.py \
  --source source.full.json \
  --final final.full.json
```

Use `--allow-kind-loss` only for conversions already recorded in `run.json`.
For example, a whiteboard snapshot normally needs both
`--expect-images <source_images_plus_snapshots>` and
`--allow-kind-loss whiteboard`.

Finally, read back the target parent and reconcile the paginated source/final
block inventories. Return the final URL plus a concise degradation list. Do
not expose the run directory or signed media URLs to the user.
