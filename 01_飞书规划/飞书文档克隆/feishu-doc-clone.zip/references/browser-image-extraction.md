# Browser Image Extraction

Use this reference only when native copy, structured replay, direct image URLs,
`docs +media-preview`, and `docs +media-download` have failed, while the
authenticated browser still renders the source image.

## Safety

- Use the user's existing logged-in Feishu session.
- Work only with images already visible to that user.
- Store bytes in the private run directory with restrictive permissions.
- Do not print cookies, signed URLs, auth headers, or base64 image data in chat
  or ordinary logs.
- Match images by source token or source URL, never by visual order alone.

## Browser Flow

1. Open the source document and wait for its editor/viewer to finish loading.
2. Scroll the document container gradually so lazy media mounts.
3. Collect image metadata before downloading:

```js
async () => {
  const scroller =
    document.querySelector(".bear-web-x-container") ||
    document.scrollingElement;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const records = new Map();

  for (
    let y = 0;
    y <= scroller.scrollHeight - scroller.clientHeight + 400;
    y += 450
  ) {
    scroller.scrollTop = y;
    await wait(700);
    for (const img of document.querySelectorAll("img.docx-image, img")) {
      const src = img.currentSrc || img.src || "";
      if (!src || img.naturalWidth < 2 || img.naturalHeight < 2) continue;
      const holder = img.closest("[data-token], [data-file-token]");
      const token =
        holder?.getAttribute("data-token") ||
        holder?.getAttribute("data-file-token") ||
        "";
      const key = token || src;
      if (!records.has(key)) {
        records.set(key, {
          key,
          token,
          src,
          width: img.naturalWidth,
          height: img.naturalHeight,
          alt: img.alt || "",
        });
      }
    }
  }
  return [...records.values()];
}
```

4. Compare collected keys with `clone-plan.json`. Scroll directly to each
   missing token or image block and retry. Do not accept a partial set without
   recording the missing keys.
5. Download bytes inside the authenticated browser context or through the
   browser automation's download/network API. Verify that the response is an
   image, has nontrivial size, and decodes to the recorded dimensions.
6. Hash each local file and store a mapping such as:

```json
[
  {
    "source_key": "source-token-or-url",
    "local_file": "assets/source-token.png",
    "sha256": "hex-digest",
    "width": 1280,
    "height": 720
  }
]
```

7. Upload each recovered image and extend the mapping with its returned
   `file_token` and block ID. Re-fetch the final document and verify count,
   dimensions, alignment, and order.

The browser fallback is complete only when every planned image is recovered or
the unrecoverable keys are listed in the final degradation report.
