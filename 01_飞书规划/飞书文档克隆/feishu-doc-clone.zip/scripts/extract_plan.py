#!/usr/bin/env python3
"""Build a deterministic media and degradation plan from Feishu fetch JSON."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from content_utils import iter_media, load_document


MIGRATION = {
    "image": "reupload",
    "whiteboard": "snapshot",
    "iframe": "passthrough",
    "file": "append",
    "sheet": "unsupported",
    "bitable": "unsupported",
}


def build_plan(raw: dict) -> dict:
    document = load_document(raw)
    content = document["content"]
    parts: list[str] = []
    media: list[dict] = []
    last = 0

    for record in iter_media(content):
        kind = record["kind"]
        migration = MIGRATION.get(kind, "unsupported")
        parts.append(content[last : record["start"]])
        media.append(
            {
                "index": len(media),
                "kind": kind,
                "migration": migration,
                "syntax": record["syntax"],
                "tag": record["tag"],
                "token": record["token"],
                "source_key": record["source_key"],
                "attrs": record["attrs"],
            }
        )
        last = record["end"]
    parts.append(content[last:])

    counts: dict[str, int] = {}
    for item in media:
        counts[item["kind"]] = counts.get(item["kind"], 0) + 1

    gaps = [
        {
            "index": item["index"],
            "kind": item["kind"],
            "token": item["token"],
            "name": item["attrs"].get("name", ""),
            "migration": item["migration"],
        }
        for item in media
        if item["migration"] in ("append", "unsupported")
    ]

    return {
        "title": document["title"],
        "doc_id": document["doc_id"],
        "content_format": document["content_format"],
        "parts": parts,
        "media": media,
        "counts": dict(sorted(counts.items())),
        "gaps": gaps,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch-json", required=True, help="Current or legacy docs +fetch JSON")
    parser.add_argument("--out", required=True, help="Plan JSON to write")
    args = parser.parse_args()

    raw = json.loads(Path(args.fetch_json).read_text(encoding="utf-8"))
    try:
        plan = build_plan(raw)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    Path(args.out).write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    upload_items = [
        {"index": item["index"], "kind": item["kind"]}
        for item in plan["media"]
        if item["migration"] in ("reupload", "snapshot") and item["source_key"]
    ]
    print(
        json.dumps(
            {
                "title": plan["title"],
                "doc_id": plan["doc_id"],
                "content_format": plan["content_format"],
                "parts": len(plan["parts"]),
                "media": len(plan["media"]),
                "counts": plan["counts"],
                "upload_count": len(upload_items),
                "upload_items": upload_items,
                "gaps": plan["gaps"],
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
