#!/usr/bin/env python3
"""Strictly compare source and final Feishu fetch JSON for clone drift."""

from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path
from typing import Any

from content_utils import image_layouts, kind_counts, load_document, strip_media


FENCED_CODE_RE = re.compile(r"```([^\n]*)\n([\s\S]*?)```")
XML_CODE_RE = re.compile(
    r"<(?P<tag>code|code-block)\b[^<>]*>(?P<body>[\s\S]*?)</(?P=tag)>",
    re.IGNORECASE,
)
GENERATED_ID_RE = re.compile(r'\s+id="[^"]*"')
STYLE_TAG_RE = re.compile(r"<callout\b[^<>]*>", re.IGNORECASE)


def load_content(path: str) -> str:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    try:
        return load_document(raw)["content"]
    except ValueError as exc:
        raise SystemExit(f"{path}: {exc}") from exc


def code_blocks(content: str) -> list[dict[str, str]]:
    blocks = [
        {"lang": match.group(1), "body": match.group(2)}
        for match in FENCED_CODE_RE.finditer(content)
    ]
    blocks.extend(
        {
            "lang": "",
            "body": html.unescape(re.sub(r"<[^<>]+>", "", match.group("body"))),
        }
        for match in XML_CODE_RE.finditer(content)
    )
    return blocks


def normalized_text(content: str) -> str:
    text = strip_media(content).replace("\r\n", "\n")
    text = GENERATED_ID_RE.sub("", text)
    text = STYLE_TAG_RE.sub("<callout>", text)
    text = re.sub(r">\s+<", "><", text)
    return re.sub(r"\s+", " ", text).strip()


def style_diffs(source: str, final: str) -> list[dict[str, str]]:
    src_tags = [GENERATED_ID_RE.sub("", match.group(0)) for match in STYLE_TAG_RE.finditer(source)]
    dst_tags = [GENERATED_ID_RE.sub("", match.group(0)) for match in STYLE_TAG_RE.finditer(final)]
    diffs = []
    for index, (src, dst) in enumerate(zip(src_tags, dst_tags), start=1):
        if src != dst:
            diffs.append({"index": index, "source": src, "final": dst})
    if len(src_tags) != len(dst_tags):
        diffs.append({"source_count": len(src_tags), "final_count": len(dst_tags)})
    return diffs


def first_divergence(source: str, final: str) -> dict[str, Any]:
    limit = min(len(source), len(final))
    position = next((index for index in range(limit) if source[index] != final[index]), limit)
    if position == limit and len(source) == len(final):
        return {}
    result: dict[str, Any] = {
        "position": position,
        "source_context": source[max(0, position - 60) : position + 60],
        "final_context": final[max(0, position - 60) : position + 60],
    }
    if position == limit and len(final) < len(source):
        result["truncated"] = f"final text ends at char {len(final)} of {len(source)}"
    return result


def image_layout_diffs(source: str, final: str) -> list[dict[str, Any]]:
    source_layouts = image_layouts(source)
    final_layouts = image_layouts(final)
    diffs = []
    for index, (src, dst) in enumerate(zip(source_layouts, final_layouts), start=1):
        fields = {
            key: {"source": src[key], "final": dst[key]}
            for key in ("width", "height", "align")
            if src[key] and src[key] != dst[key]
        }
        if fields:
            diffs.append({"index": index, "fields": fields})
    return diffs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, help="Source docs +fetch JSON")
    parser.add_argument("--final", required=True, help="Final docs +fetch JSON")
    parser.add_argument(
        "--expect-images",
        type=int,
        default=None,
        help="Expected final image count; increase when whiteboards become snapshots",
    )
    parser.add_argument(
        "--allow-kind-loss",
        default="",
        help="Comma-separated media kinds intentionally degraded or omitted",
    )
    parser.add_argument(
        "--allow-layout-drift",
        action="store_true",
        help="Do not fail on image width, height, or alignment drift",
    )
    parser.add_argument(
        "--allow-style-drift",
        action="store_true",
        help="Do not fail on callout style-attribute drift",
    )
    parser.add_argument(
        "--strict-media",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--fills",
        help="Fills JSON used during assembly; intentional added text is excluded",
    )
    args = parser.parse_args()

    source = load_content(args.source)
    final = load_content(args.final)
    source_blocks = code_blocks(source)
    final_blocks = code_blocks(final)

    code_mismatches = []
    for index, (src, dst) in enumerate(zip(source_blocks, final_blocks), start=1):
        if src != dst:
            code_mismatches.append(
                {
                    "index": index,
                    "source_lang": src["lang"],
                    "final_lang": dst["lang"],
                    "source_tail": src["body"][-120:],
                    "final_tail": dst["body"][-120:],
                }
            )

    source_counts = kind_counts(source)
    final_counts = kind_counts(final)
    source_text = normalized_text(source)
    final_text = normalized_text(final)

    if args.fills:
        for item in json.loads(Path(args.fills).read_text(encoding="utf-8")):
            fill_text = normalized_text(item["markdown"])
            link_label = normalized_text(
                re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", item["markdown"])
            )
            for candidate in (fill_text, link_label):
                if candidate and candidate in final_text:
                    final_text = final_text.replace(candidate, "", 1)
                    break

    expected_images = (
        args.expect_images
        if args.expect_images is not None
        else source_counts.get("image", 0)
    )
    images_ok = final_counts.get("image", 0) >= expected_images
    code_ok = len(source_blocks) == len(final_blocks) and not code_mismatches
    text_ok = source_text == final_text

    allowed_kind_loss = {
        value.strip()
        for value in args.allow_kind_loss.split(",")
        if value.strip()
    }
    media_gaps = [
        {
            "kind": kind,
            "source": count,
            "final": final_counts.get(kind, 0),
            "allowed": kind in allowed_kind_loss,
        }
        for kind, count in sorted(source_counts.items())
        if kind != "image" and final_counts.get(kind, 0) < count
    ]
    media_ok = all(gap["allowed"] for gap in media_gaps)

    layout_diffs = image_layout_diffs(source, final)
    layout_ok = not layout_diffs or args.allow_layout_drift
    callout_style_diffs = style_diffs(source, final)
    style_ok = not callout_style_diffs or args.allow_style_drift
    result = {
        "ok": code_ok and text_ok and images_ok and media_ok and layout_ok and style_ok,
        "code_blocks_equal": code_ok,
        "text_equal": text_ok,
        "images_ok": images_ok,
        "image_layout_ok": layout_ok,
        "style_ok": style_ok,
        "expected_images": expected_images,
        "source_counts": source_counts,
        "final_counts": final_counts,
        "source_code_blocks": len(source_blocks),
        "final_code_blocks": len(final_blocks),
        "media_gaps": media_gaps,
        "image_layout_diffs": layout_diffs[:20],
        "style_diffs": callout_style_diffs[:20],
        "code_mismatches": code_mismatches[:20],
    }
    if not text_ok:
        result["divergence"] = first_divergence(source_text, final_text)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["ok"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
