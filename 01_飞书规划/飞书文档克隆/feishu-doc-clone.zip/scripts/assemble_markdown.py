#!/usr/bin/env python3
"""Assemble fallback replay content from a plan and explicit media token map."""

from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path


EMOJI_NAMES = {
    "bulb": "💡",
    "white_check_mark": "✅",
    "pushpin": "📌",
    "warning": "⚠️",
    "x": "❌",
    "information_source": "ℹ️",
    "rocket": "🚀",
    "eyes": "👀",
    "dart": "🎯",
}
CALLOUT_EMOJI_RE = re.compile(
    r'(<callout\b[^<>]*?)\s*emoji="([A-Za-z0-9_+\-]+)"',
    re.IGNORECASE,
)
CALLOUT_BORDER_RE = re.compile(
    r'(<callout\b[^<>]*?border-color=")light-([a-z]+")',
    re.IGNORECASE,
)


def fix_legacy_callouts(content: str) -> str:
    def replace_emoji(match: re.Match) -> str:
        emoji = EMOJI_NAMES.get(match.group(2).lower())
        return f'{match.group(1)} emoji="{emoji}"' if emoji else match.group(1)

    content = CALLOUT_EMOJI_RE.sub(replace_emoji, content)
    return CALLOUT_BORDER_RE.sub(r"\1\2", content)


def load_token_map(path: str) -> dict[str, str]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(raw, dict):
        return {
            str(key): value
            for key, value in raw.items()
            if isinstance(value, str) and value
        }
    if isinstance(raw, list):
        mapping = {}
        for item in raw:
            if not isinstance(item, dict):
                continue
            source = (
                item.get("source_key")
                or item.get("source_token")
                or item.get("token")
                or item.get("url")
                or ""
            )
            uploaded = item.get("file_token") or item.get("uploaded") or ""
            if source and uploaded:
                mapping[source] = uploaded
        return mapping
    raise SystemExit("--token-map must be a JSON object or list")


def image_tag(token: str, attrs: dict[str, str]) -> str:
    values = [f'token="{html.escape(token, quote=True)}"']
    for key in ("width", "height", "align", "alt"):
        value = attrs.get(key)
        if value:
            values.append(f'{key}="{html.escape(value, quote=True)}"')
    return f"<img {' '.join(values)}/>"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True, help="Plan JSON from extract_plan.py")
    parser.add_argument("--token-map", required=True, help="JSON source key -> uploaded token")
    parser.add_argument(
        "--fills",
        help="JSON list of {index, markdown} replacements for intentional degradations",
    )
    parser.add_argument("--out", required=True, help="Replay content file to write")
    args = parser.parse_args()

    fills: dict[int, str] = {}
    if args.fills:
        for item in json.loads(Path(args.fills).read_text(encoding="utf-8")):
            fills[int(item["index"])] = item["markdown"]

    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    parts = plan["parts"]
    media = plan["media"]
    token_map = load_token_map(args.token_map)
    if len(parts) != len(media) + 1:
        raise SystemExit(f"bad plan: {len(parts)} parts for {len(media)} media items")

    missing = []
    for item in media:
        if item["migration"] not in ("reupload", "snapshot"):
            continue
        source_key = item.get("source_key") or item.get("token") or ""
        if not source_key or source_key not in token_map:
            missing.append(source_key or f"media-index-{item['index']}")
    if missing:
        raise SystemExit("token map is missing uploads for: " + ", ".join(missing))

    output = [parts[0]]
    emitted_images = 0
    gaps = []
    for item, next_part in zip(media, parts[1:]):
        migration = item["migration"]
        source_key = item.get("source_key") or item.get("token") or ""
        if migration in ("reupload", "snapshot"):
            output.append(image_tag(token_map[source_key], item["attrs"]))
            emitted_images += 1
        elif migration == "passthrough":
            output.append(item["tag"])
        elif item["index"] in fills:
            output.append(fills[item["index"]])
        else:
            gaps.append(
                {
                    "index": item["index"],
                    "kind": item["kind"],
                    "token": item.get("token", ""),
                    "name": item["attrs"].get("name", ""),
                    "reason": (
                        "re-insert after document creation"
                        if migration == "append"
                        else "not migratable"
                    ),
                }
            )
        output.append(next_part)

    content = "".join(output)
    if plan.get("content_format") == "legacy-markdown":
        content = fix_legacy_callouts(content)
    Path(args.out).write_text(content, encoding="utf-8")
    print(
        json.dumps(
            {
                "images": emitted_images,
                "gaps": gaps,
                "content_format": plan.get("content_format", ""),
                "out": args.out,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
