#!/usr/bin/env python3
"""Shared parsing helpers for Feishu docs +fetch v2 and legacy exports."""

from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from typing import Any, Iterator


XML_MEDIA_RE = re.compile(
    r"<(?P<tag>img|image|source|file|whiteboard|sheet|bitable|iframe)\b"
    r"(?P<attrs>[^<>]*?)(?:/?>)",
    re.IGNORECASE,
)
MARKDOWN_IMAGE_RE = re.compile(r"!\[(?P<alt>[^\]]*)\]\((?P<url>[^)\s]+)(?:\s+\"[^\"]*\")?\)")
MARKDOWN_FENCE_RE = re.compile(
    r"(?:```[^\n]*\n[\s\S]*?```|~~~[^\n]*\n[\s\S]*?~~~)",
    re.MULTILINE,
)
UNSUPPORTED_RE = re.compile(r"<!--\s*Unsupported block type: (?P<type>\d+)\s*-->", re.IGNORECASE)
ATTR_RE = re.compile(r'([\w-]+)="([^"]*)"')
TITLE_XML_RE = re.compile(r"<title\b[^<>]*>(?P<title>[\s\S]*?)</title>", re.IGNORECASE)
TITLE_MD_RE = re.compile(r"^\s*#\s+(?P<title>.+?)\s*$", re.MULTILINE)
TAG_NAME_MAP = {
    "img": "image",
    "image": "image",
    "source": "file",
    "file": "file",
    "whiteboard": "whiteboard",
    "sheet": "sheet",
    "bitable": "bitable",
    "iframe": "iframe",
}


def load_document(raw: dict[str, Any]) -> dict[str, Any]:
    """Return a stable document envelope for current and legacy fetch JSON."""
    data = raw.get("data", raw)
    document = data.get("document") if isinstance(data, dict) else None
    if isinstance(document, dict):
        content = document.get("content")
        if not isinstance(content, str):
            raise ValueError("fetch JSON does not contain data.document.content")
        return {
            "content": content,
            "content_format": detect_content_format(content),
            "doc_id": document.get("document_id") or "",
            "title": document.get("title") or extract_title(content),
            "reference_map": document.get("reference_map") or {},
        }

    if not isinstance(data, dict):
        raise ValueError("fetch JSON data must be an object")
    content = data.get("markdown")
    if not isinstance(content, str):
        content = data.get("content")
    if not isinstance(content, str):
        raise ValueError("fetch JSON does not contain document content")
    return {
        "content": content,
        "content_format": "legacy-markdown" if "markdown" in data else detect_content_format(content),
        "doc_id": data.get("doc_id") or data.get("document_id") or "",
        "title": data.get("title") or extract_title(content),
        "reference_map": data.get("reference_map") or {},
    }


def detect_content_format(content: str) -> str:
    if re.search(r"<(?:title|p|h[1-9]|table|callout|grid)\b", content, re.IGNORECASE):
        return "xml"
    return "markdown"


def extract_title(content: str) -> str:
    xml_match = TITLE_XML_RE.search(content)
    if xml_match:
        return html.unescape(re.sub(r"<[^<>]+>", "", xml_match.group("title"))).strip()
    markdown_match = TITLE_MD_RE.search(content)
    return markdown_match.group("title").strip() if markdown_match else ""


def parse_xml_attrs(tag_text: str) -> dict[str, str]:
    candidate = tag_text if tag_text.rstrip().endswith("/>") else tag_text.rstrip()[:-1] + "/>"
    try:
        return dict(ET.fromstring(candidate).attrib)
    except ET.ParseError:
        return dict(ATTR_RE.findall(tag_text))


def iter_media(content: str) -> Iterator[dict[str, Any]]:
    matches: list[tuple[int, int, dict[str, Any]]] = []
    fenced_ranges = [(match.start(), match.end()) for match in MARKDOWN_FENCE_RE.finditer(content)]

    def inside_fence(position: int) -> bool:
        return any(start <= position < end for start, end in fenced_ranges)

    for match in XML_MEDIA_RE.finditer(content):
        if inside_fence(match.start()):
            continue
        tag_name = match.group("tag").lower()
        attrs = parse_xml_attrs(match.group(0))
        kind = TAG_NAME_MAP[tag_name]
        token = attrs.get("token", "")
        url = attrs.get("url") or attrs.get("href") or ""
        matches.append(
            (
                match.start(),
                match.end(),
                {
                    "kind": kind,
                    "syntax": "xml" if tag_name in {"img", "source"} else "legacy-xml",
                    "tag_name": tag_name,
                    "tag": match.group(0),
                    "token": token,
                    "source_key": token or url,
                    "attrs": attrs,
                },
            )
        )

    for match in MARKDOWN_IMAGE_RE.finditer(content):
        if inside_fence(match.start()):
            continue
        url = html.unescape(match.group("url"))
        matches.append(
            (
                match.start(),
                match.end(),
                {
                    "kind": "image",
                    "syntax": "markdown",
                    "tag_name": "markdown-image",
                    "tag": match.group(0),
                    "token": "",
                    "source_key": url,
                    "attrs": {"alt": match.group("alt"), "url": url},
                },
            )
        )

    for match in UNSUPPORTED_RE.finditer(content):
        kind = f"unsupported_block_{match.group('type')}"
        matches.append(
            (
                match.start(),
                match.end(),
                {
                    "kind": kind,
                    "syntax": "comment",
                    "tag_name": "unsupported",
                    "tag": match.group(0),
                    "token": "",
                    "source_key": kind,
                    "attrs": {},
                },
            )
        )

    last_end = -1
    for start, end, item in sorted(matches, key=lambda record: (record[0], record[1])):
        if start < last_end:
            continue
        item["start"] = start
        item["end"] = end
        last_end = end
        yield item


def kind_counts(content: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in iter_media(content):
        kind = item["kind"]
        counts[kind] = counts.get(kind, 0) + 1
    return dict(sorted(counts.items()))


def strip_media(content: str) -> str:
    pieces: list[str] = []
    last = 0
    for item in iter_media(content):
        pieces.append(content[last : item["start"]])
        last = item["end"]
    pieces.append(content[last:])
    return "".join(pieces)


def image_layouts(content: str) -> list[dict[str, str]]:
    layouts = []
    for item in iter_media(content):
        if item["kind"] != "image":
            continue
        attrs = item["attrs"]
        layouts.append({key: attrs.get(key, "") for key in ("width", "height", "align")})
    return layouts
