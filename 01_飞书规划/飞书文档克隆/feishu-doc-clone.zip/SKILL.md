---
slug: feishu-doc-clone
displayName: 飞书文档高保真克隆
version: 1.0.3
summary: 好文档想存进自己空间，一复制格式全碎？📋 原生克隆+结构化重放双通道，正文/代码块/图片/附件逐项校验，降级明说不静默丢内容
license: MIT
homepage: 
iconUrl: https://-1388575217.cos.accelerate.myqcloud.com/skill-icons/uploads/522425/9d448f7387364c46bc458f1cbcc41fc9.png
name: feishu-doc-clone
description: 高保真复制 Feishu/飞书/Lark 云文档或知识库页面到用户自己的飞书空间，不摘要、不改写，并验证正文、代码块、图片、附件、嵌入资源和目标位置。Use when the user asks to copy, clone, duplicate, back up, migrate, rebuild, or create an editable copy of a Feishu/Lark docx or wiki document, including “原封不动复制”“复制到我的知识库”“无复制权限”“保留图片/代码块/附件” and browser-visible image fallback requests.
---

# Feishu Doc Clone · 飞书文档高保真克隆

## 这是什么

看到一篇好文档想存进自己的知识库，手动复制粘贴——格式碎了、图片裂了、代码块糊了；
右上角还没有"创建副本"权限？这个技能让 AI Agent 替你完成**原封不动的克隆** 📋

**什么时候用我：**

- 「把这篇飞书文档原封不动复制到我的空间」
- 「没有复制权限，但我能看，帮我存一份」
- 「迁移这个知识库页面，图片、代码块、附件都要在」

**它怎么工作：**

```text
源文档（docx / wiki）
   ├─ 有原生复制权限 → 直接原生克隆（保真度 100%）
   └─ 只有阅读权限   → 结构化重放：逐块读取→逐块重建
                        正文 / 代码块 / 图片 / 附件 / 嵌入资源
   → 逐项回读校验 → 明确报告哪些块有降级（绝不静默丢内容）
```

**三步上手**：① 安装本技能 → ② 装好 `lark-cli` 并登录你的飞书 →
③ 对你的 Agent 说「把 <文档链接> 复制到我的知识库」。

**边界明牌**：只克隆你有权限**看到**的内容；转换降级会明确告知，不假装完美；
不绕过任何飞书权限体系。真身与更新：

---

## Contract

Create the highest-fidelity editable copy that current permissions and Feishu APIs allow.

- Preserve source meaning and structure. Do not summarize, rewrite, embellish, or silently omit blocks.
- Prefer native copy. Use structured replay only when native copy is unavailable.
- Treat every conversion as an explicit degradation, not an exact clone.
- Do not report success until the final remote document and destination have been read back.

## Read Version-Matched Lark Guidance

Before running Lark commands, read the current CLI-bundled skills and relevant references:

```bash
lark-cli skills read lark-shared
lark-cli skills read lark-drive
lark-cli skills read lark-doc
lark-cli skills read lark-wiki
```

For document fetch/create/update operations, also read the exact references required by the current `lark-doc` skill. Treat current CLI guidance and `--help` output as authoritative when examples in this skill differ.

Use `--as user` by default. Request only the missing scopes reported by the current command, then verify them with `lark-cli auth check`.

## Workflow

### 1. Resolve Source and Destination

Inspect the source instead of guessing token type:

```bash
lark-cli drive +inspect --as user --url "<source_url>" --format json
```

- Continue here only for `doc` or `docx`. Route sheets, Base, slides, files, and mindnotes to their matching skills.
- For a wiki source, record the wiki node, underlying document token, title, parent, and `has_child`.
- If the user asks for related child documents, enumerate the wiki tree before writing and preserve the hierarchy.
- Resolve the destination to an exact folder token, wiki parent token, or `my_library`. Never infer a destination from a display name alone.

### 2. Inventory Before Writing

Fetch source content twice when rebuilding:

```bash
lark-cli docs +fetch --as user --doc "<source>" \
  --doc-format xml --detail simple --format json
lark-cli docs +fetch --as user --doc "<source>" \
  --doc-format xml --detail full --format json
```

Use the simple response for replay and the full response for validation. Fetch every page of the source block list and run `scripts/inventory_blocks.py` over all page files. Record images, files, whiteboards, sheets, bitables, iframes, synced references, unknown blocks, and source image layout.

### 3. Try Native Copy First

Inspect the live schema before calling native copy:

```bash
lark-cli schema drive.files.copy --format json
```

- Use `drive files copy` for Drive destinations.
- Use the current wiki node-copy workflow for wiki destinations.
- Treat the returned token as provisional. Fetch the new document and verify its parent/destination before accepting it.
- If the API returns a permission boundary such as `forbidden` or `1061004`, continue to structured replay. Do not retry the same request indefinitely.

### 4. Structured Replay

Read [references/rebuild-workflow.md](references/rebuild-workflow.md) before rebuilding.

Use current v2 content fields: `data.document.content` and its `reference_map`. Replay XML in one create call whenever possible:

```bash
lark-cli docs +create --as user \
  --doc-format xml \
  --content @source.xml \
  --reference-map @reference-map.json \
  --parent-position my_library
```

Use `--parent-token` instead when the user specified a concrete folder or wiki parent. Avoid repeated writes because they can change code-block whitespace and container structure.

If a proven request-size limit requires chunking, use `scripts/split_markdown.py`, append serially with `docs +update --command append`, and re-fetch after every chunk. Stop on the first mismatch.

### 5. Repair Media Only When Needed

Run `scripts/extract_plan.py` against the v2 fetch JSON to produce a media/degradation manifest.

Use this fallback order:

1. Replay the current `<img url>` or Markdown image URL directly.
2. Use current `docs +media-preview` or `docs +media-download`.
3. Use the logged-in browser flow in [references/browser-image-extraction.md](references/browser-image-extraction.md).
4. Upload recovered files with `docs +media-insert` and record an explicit `source_key -> file_token` map.
5. Rebuild fallback content with `scripts/assemble_markdown.py`.

Never map media by upload order. A retry must not shift images into the wrong positions.

Handle non-image blocks explicitly:

- Whiteboard: preserve natively when possible; otherwise insert a trimmed snapshot and allow `whiteboard` loss only during validation.
- File: reinsert the downloaded attachment, preserving its name; report position changes.
- Sheet/Base: preserve the resource block when replay works. Otherwise report it as unresolved; do not replace it with invented content.
- Bookmark or unsupported block: degrade to a verified title and URL only when the source can be inspected.

### 6. Validate Strictly

Fetch the final document using `--doc-format xml --detail full`, then run:

```bash
python3 scripts/compare_clone.py \
  --source source.full.json \
  --final final.full.json
```

The default is strict: missing text, code, images, files, whiteboards, sheets,
bitables, iframes, image layout, or callout styles fails validation. Use
`--allow-layout-drift` or `--allow-style-drift` only for a reviewed,
user-visible normalization.

Allow only deliberate, user-visible conversions:

```bash
python3 scripts/compare_clone.py \
  --source source.full.json \
  --final final.full.json \
  --expect-images 6 \
  --allow-kind-loss whiteboard
```

Also verify:

- The final URL opens and belongs to the intended folder or wiki parent.
- Source and final block inventories reconcile.
- Image count, width, height, alignment, and order are preserved unless explicitly reported.
- No empty image/file tokens remain.
- Every `attention` or unknown source block has a final disposition.

## Completion Labels

Use one truthful outcome:

- `native_clone`: native copy succeeded and remote readback passed.
- `high_fidelity_rebuild`: strict replay validation passed.
- `degraded_rebuild`: validation passed only with explicitly listed conversions.
- `blocked`: required content remains inaccessible or validation still fails.

Never call a degraded or blocked result “原封不动”.

## Guardrails

- Keep a run manifest containing source token, destination, created document IDs, media mappings, validation output, and intentional degradations.
- Do not print access tokens, signed media URLs, browser cookies, or source media as base64 in chat.
- Store temporary source exports and media in a private task directory; do not commit them.
- Avoid staging documents. If one is unavoidable, record its ID and do not delete any remote document without confirming it was created by this run and cleanup is authorized.
- Do not mutate the source document.
- Do not continue after a failed strict comparison without repairing the discrepancy or reporting it.

## Bundled Resources

- `scripts/extract_plan.py`: parse current v2 or legacy fetch JSON into a media manifest.
- `scripts/assemble_markdown.py`: rebuild fallback content using explicit media mappings.
- `scripts/compare_clone.py`: strict source/final validation with explicit degradation flags.
- `scripts/inventory_blocks.py`: inventory paginated block-list responses.
- `scripts/split_markdown.py`: split fallback content without cutting protected containers.
- `scripts/trim_snapshot.py`: crop whiteboard snapshot whitespace.
- `scripts/repair_styles.py`: legacy-only style repair after a reproduced callout importer defect.
- `scripts/check.sh`: run the local regression harness and Skill validator.
