#!/usr/bin/env python3

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = SKILL_DIR / "scripts"


def run_script(name: str, *args: str) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(SCRIPTS_DIR / name), *args],
        capture_output=True,
        text=True,
        env=env,
    )


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


def v2_fetch(content: str, document_id: str = "docx_source") -> dict:
    return {
        "ok": True,
        "data": {
            "document": {
                "document_id": document_id,
                "revision_id": 1,
                "content": content,
            }
        },
    }


class ExtractPlanTests(unittest.TestCase):
    def test_v2_xml_media_inventory(self) -> None:
        content = (
            '<title>Demo</title><p>Before</p>'
            '<img token="img1" width="640" height="360" align="center"/>'
            '<source token="file1" name="brief.pdf"/>'
            '<whiteboard token="board1"/>'
            '<iframe url="https://example.com/embed"/>'
            '<sheet token="sheet1"/><bitable token="base1"/>'
        )
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            plan_path = Path(tmp) / "plan.json"
            write_json(source, v2_fetch(content))
            result = run_script(
                "extract_plan.py",
                "--fetch-json",
                str(source),
                "--out",
                str(plan_path),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertNotIn("example.com", result.stdout)
            plan = json.loads(plan_path.read_text(encoding="utf-8"))

        self.assertEqual(plan["title"], "Demo")
        self.assertEqual(plan["doc_id"], "docx_source")
        self.assertEqual(
            plan["counts"],
            {
                "bitable": 1,
                "file": 1,
                "iframe": 1,
                "image": 1,
                "sheet": 1,
                "whiteboard": 1,
            },
        )
        image = next(item for item in plan["media"] if item["kind"] == "image")
        self.assertEqual(image["token"], "img1")
        self.assertEqual(image["attrs"]["align"], "center")

    def test_v2_markdown_image_is_counted(self) -> None:
        content = "# Demo\n\n![Architecture](https://example.com/diagram.png)\n"
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            plan_path = Path(tmp) / "plan.json"
            write_json(source, v2_fetch(content))
            result = run_script(
                "extract_plan.py",
                "--fetch-json",
                str(source),
                "--out",
                str(plan_path),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            plan = json.loads(plan_path.read_text(encoding="utf-8"))

        self.assertEqual(plan["counts"], {"image": 1})
        self.assertEqual(plan["media"][0]["syntax"], "markdown")

    def test_markdown_image_literal_inside_code_is_not_media(self) -> None:
        content = (
            "# Demo\n\n"
            "```markdown\n"
            "![literal](https://example.com/not-media.png)\n"
            '<img token="also-not-media"/>\n'
            "```\n\n"
            "![real](https://example.com/real.png)\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            plan_path = Path(tmp) / "plan.json"
            write_json(source, v2_fetch(content))
            result = run_script(
                "extract_plan.py",
                "--fetch-json",
                str(source),
                "--out",
                str(plan_path),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            plan = json.loads(plan_path.read_text(encoding="utf-8"))

        self.assertEqual(plan["counts"], {"image": 1})
        self.assertEqual(plan["media"][0]["attrs"]["alt"], "real")


class AssembleContentTests(unittest.TestCase):
    def test_explicit_source_keys_rebuild_current_image_tags(self) -> None:
        content = (
            '<title>Demo</title>'
            '<img token="img1" width="640" height="360" align="center"/>'
            '<whiteboard token="board1"/>'
        )
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            plan_path = Path(tmp) / "plan.json"
            token_map = Path(tmp) / "tokens.json"
            output = Path(tmp) / "output.xml"
            write_json(source, v2_fetch(content))
            extract = run_script(
                "extract_plan.py",
                "--fetch-json",
                str(source),
                "--out",
                str(plan_path),
            )
            self.assertEqual(extract.returncode, 0, extract.stderr)
            write_json(token_map, {"img1": "new-img", "board1": "new-board"})
            assemble = run_script(
                "assemble_markdown.py",
                "--plan",
                str(plan_path),
                "--token-map",
                str(token_map),
                "--out",
                str(output),
            )
            self.assertEqual(assemble.returncode, 0, assemble.stderr)
            replay = output.read_text(encoding="utf-8")

        self.assertIn(
            '<img token="new-img" width="640" height="360" align="center"/>',
            replay,
        )
        self.assertIn('<img token="new-board"/>', replay)
        self.assertNotIn("img1", replay)
        self.assertNotIn("board1", replay)

    def test_missing_mapping_is_a_hard_failure(self) -> None:
        content = '<title>Demo</title><img token="img1"/>'
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            plan_path = Path(tmp) / "plan.json"
            token_map = Path(tmp) / "tokens.json"
            output = Path(tmp) / "output.xml"
            write_json(source, v2_fetch(content))
            extract = run_script(
                "extract_plan.py",
                "--fetch-json",
                str(source),
                "--out",
                str(plan_path),
            )
            self.assertEqual(extract.returncode, 0, extract.stderr)
            write_json(token_map, {})
            assemble = run_script(
                "assemble_markdown.py",
                "--plan",
                str(plan_path),
                "--token-map",
                str(token_map),
                "--out",
                str(output),
            )

        self.assertNotEqual(assemble.returncode, 0)
        self.assertIn("missing uploads", assemble.stderr)


class CompareCloneTests(unittest.TestCase):
    def run_compare(self, source_content: str, final_content: str, *extra: str):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.json"
            final = Path(tmp) / "final.json"
            write_json(source, v2_fetch(source_content, "source"))
            write_json(final, v2_fetch(final_content, "final"))
            return run_script(
                "compare_clone.py",
                "--source",
                str(source),
                "--final",
                str(final),
                *extra,
            )

    def test_generated_block_ids_do_not_fail_equal_content(self) -> None:
        result = self.run_compare(
            '<title id="source">Demo</title><p id="p1">Same text</p>',
            '<title id="final">Demo</title><p id="p9">Same text</p>',
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_missing_file_fails_by_default(self) -> None:
        result = self.run_compare(
            '<title>Demo</title><source token="f1" name="brief.pdf"/>',
            "<title>Demo</title>",
        )
        self.assertNotEqual(result.returncode, 0, result.stdout)

    def test_explicit_file_degradation_can_be_allowed(self) -> None:
        result = self.run_compare(
            '<title>Demo</title><source token="f1" name="brief.pdf"/>',
            "<title>Demo</title>",
            "--allow-kind-loss",
            "file",
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_image_layout_drift_fails_by_default(self) -> None:
        result = self.run_compare(
            '<title>Demo</title><img token="i1" width="640" height="360" align="center"/>',
            '<title>Demo</title><img token="i2" width="320" height="180" align="left"/>',
        )
        self.assertNotEqual(result.returncode, 0, result.stdout)

    def test_meaningful_space_loss_fails(self) -> None:
        result = self.run_compare(
            "<title>Demo</title><p>New York office</p>",
            "<title>Demo</title><p>NewYork office</p>",
        )
        self.assertNotEqual(result.returncode, 0, result.stdout)

    def test_callout_style_drift_requires_explicit_allowance(self) -> None:
        source = '<title>Demo</title><callout border-color="red"><p>Notice</p></callout>'
        final = '<title>Demo</title><callout border-color="blue"><p>Notice</p></callout>'
        strict = self.run_compare(source, final)
        allowed = self.run_compare(source, final, "--allow-style-drift")
        self.assertNotEqual(strict.returncode, 0, strict.stdout)
        self.assertEqual(allowed.returncode, 0, allowed.stdout + allowed.stderr)


class SplitMarkdownTests(unittest.TestCase):
    def test_callout_is_one_indivisible_unit(self) -> None:
        path = SCRIPTS_DIR / "split_markdown.py"
        spec = importlib.util.spec_from_file_location("split_markdown", path)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        content = "<callout>\nfirst\n\nsecond\n</callout>\n\noutside"
        units = module.split_units(content)
        callout_units = [unit for unit in units if "<callout>" in unit]
        self.assertEqual(len(callout_units), 1)
        self.assertIn("</callout>", callout_units[0])


class SkillPackageTests(unittest.TestCase):
    def test_skill_uses_current_cli_v2_flags(self) -> None:
        text = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
        for legacy_flag in ("--markdown", "--wiki-space", "--mode append"):
            self.assertNotIn(legacy_flag, text)
        self.assertIn("--doc-format xml", text)
        self.assertIn("--command", text)

    def test_openai_metadata_names_canonical_skill(self) -> None:
        text = (SKILL_DIR / "agents" / "openai.yaml").read_text(encoding="utf-8")
        self.assertIn("Feishu Doc Clone", text)
        self.assertIn("$feishu-doc-clone", text)


if __name__ == "__main__":
    unittest.main()
