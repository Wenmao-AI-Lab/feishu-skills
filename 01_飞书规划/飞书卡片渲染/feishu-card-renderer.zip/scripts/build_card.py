#!/usr/bin/env python3
"""
飞书卡片渲染引擎 — 核心构建脚本

用法:
  python build_card.py --template dashboard --data '{"title":"...","rows":[...]}'
  python build_card.py --template notice --data-file ./data.json
  echo '{"title":"...","rows":[...]}' | python build_card.py --template dashboard

输出: 合法的飞书消息卡片 JSON (schema 2.0)，stdout
"""

import json
import sys
import argparse
from pathlib import Path

# Force UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Add skill root to path so we can import templates
SKILL_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_DIR))

from templates import dashboard, comparison, text_analysis, notice

TEMPLATES = {
    "dashboard": dashboard,
    "comparison": comparison,
    "text_analysis": text_analysis,
    "notice": notice,
}


def _read_json_file(path: str) -> dict:
    """Read JSON file, auto-handling BOM (UTF-8 / UTF-16 LE / UTF-16 BE)."""
    raw = Path(path).read_bytes()
    if raw.startswith(b'\xef\xbb\xbf'):
        raw = raw[3:]
    elif raw.startswith(b'\xff\xfe'):
        raw = raw[2:].decode('utf-16-le').encode('utf-8')
    elif raw.startswith(b'\xfe\xff'):
        raw = raw[2:].decode('utf-16-be').encode('utf-8')
    return json.loads(raw.decode('utf-8'))


def main():
    parser = argparse.ArgumentParser(
        description="飞书卡片渲染引擎 — 模板 + 数据 → 卡片 JSON"
    )
    parser.add_argument(
        "--template", "-t",
        required=True,
        choices=list(TEMPLATES.keys()),
        help="模板名称"
    )
    parser.add_argument(
        "--data", "-d",
        help="数据 JSON 字符串（适合简单场景）"
    )
    parser.add_argument(
        "--data-file", "-f",
        help="数据 JSON 文件路径（推荐，避免 shell 转义问题）"
    )
    parser.add_argument(
        "--pretty", "-p",
        action="store_true",
        help="格式化输出 JSON"
    )
    args = parser.parse_args()

    # Load data
    if args.data_file:
        data = _read_json_file(args.data_file)
    elif args.data:
        data = json.loads(args.data)
    else:
        data = json.load(sys.stdin)

    # Render
    template_mod = TEMPLATES[args.template]
    try:
        card = template_mod.render(data)
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"模板渲染失败: {e}"
        }, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)

    # Quick structural validation
    errors = _quick_validate(card)
    if errors:
        print(json.dumps({
            "status": "error",
            "errors": errors
        }, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)

    # Output
    indent = 2 if args.pretty else None
    print(json.dumps(card, ensure_ascii=False, indent=indent))


def _quick_validate(card: dict) -> list:
    """Quick structural validation before output."""
    errors = []
    if card.get("schema") != "2.0":
        errors.append("顶层 schema 必须为 '2.0'")
    if "header" not in card:
        errors.append("缺少 header")
    elif "title" not in card.get("header", {}):
        errors.append("header 缺少 title")
    if "body" not in card:
        errors.append("缺少 body")
    elif "elements" not in card.get("body", {}):
        errors.append("body 缺少 elements")
    return errors


if __name__ == "__main__":
    main()
