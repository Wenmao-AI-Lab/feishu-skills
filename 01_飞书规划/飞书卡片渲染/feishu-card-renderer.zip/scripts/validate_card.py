#!/usr/bin/env python3
"""
飞书卡片 JSON 校验器

用法:
  python validate_card.py --card '{"schema":"2.0",...}'
  python validate_card.py --card-file ./card.json
  cat card.json | python validate_card.py

校验规则（来自实测踩坑）:
  - schema 必须为 "2.0"
  - header.title 必须存在
  - body.elements 必须存在
  - table: page_size 1-10, columns 必含 name/display_name/data_type
  - options 列: 值必须是 [{color, text}] 格式, color ∈ {red,green,blue,orange,grey}
  - note 标签: schema 2.0 不兼容，用 markdown 替代
  - markdown 块: 不开头用 #（飞书卡片不支持 heading）
  - 日期列: 不能用 date data_type（会 400）
"""

import json
import sys
import argparse
from pathlib import Path

# Force UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


VALID_DATA_TYPES = {"text", "options"}
VALID_TAGS = {"column_set", "table", "markdown", "hr"}
VALID_COLORS = {"red", "green", "blue", "orange", "grey"}
MAX_PAGE_SIZE = 10
MIN_PAGE_SIZE = 1


def _read_json_file(path: str) -> dict:
    """Read JSON file, auto-handling BOM (UTF-8 / UTF-16 LE / UTF-16 BE)."""
    raw = Path(path).read_bytes()
    if raw.startswith(b'\xef\xbb\xbf'):
        raw = raw[3:]
    elif raw.startswith(b'\xff\xfe'):
        raw = raw[2:].decode('utf-16-le').encode('utf-8')
    elif raw.startswith(b'\xfe\xff'):
        raw = raw[2:].decode('utf-16-be').encode('utf-8')
    return json.loads(raw.decode('utf-8'))


def validate(card: dict) -> dict:
    """Validate a feishu card JSON against schema 2.0 constraints.

    Returns {"valid": bool, "errors": [...], "warnings": [...]}
    """
    errors = []
    warnings = []

    if not isinstance(card, dict):
        return {"valid": False, "errors": ["卡片必须是 JSON 对象"], "warnings": []}

    if card.get("schema") != "2.0":
        errors.append("schema 必须为 '2.0'")

    # -- Header --
    if "header" not in card:
        errors.append("缺少 header")
    else:
        header = card["header"]
        if not isinstance(header, dict):
            errors.append("header 必须是对象")
        elif "title" not in header:
            errors.append("header 缺少 title")
        elif not isinstance(header["title"], dict):
            errors.append("header.title 必须是对象")
        elif header["title"].get("tag") != "plain_text":
            errors.append("header.title.tag 必须为 'plain_text'")
        elif not header["title"].get("content"):
            warnings.append("header.title.content 为空")

    # -- Body --
    if "body" not in card:
        errors.append("缺少 body")
    else:
        body = card["body"]
        if not isinstance(body, dict):
            errors.append("body 必须是对象")
        elif "elements" not in body:
            errors.append("body 缺少 elements")
        else:
            elements = body["elements"]
            if not isinstance(elements, list):
                errors.append("body.elements 必须是数组")
            elif len(elements) == 0:
                warnings.append("body.elements 为空数组，卡片无内容")
            else:
                for i, el in enumerate(elements):
                    _validate_element(el, i, errors, warnings)

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }


def _validate_element(el: dict, idx: int, errors: list, warnings: list):
    if not isinstance(el, dict):
        errors.append(f"body.elements[{idx}]: 必须是对象")
        return

    tag = el.get("tag", "")
    prefix = f"body.elements[{idx}]"

    if tag not in VALID_TAGS:
        if tag == "note":
            errors.append(
                f"{prefix}: 'note' 标签在 schema 2.0 不兼容，请用 markdown 替代"
            )
        elif tag == "header":
            errors.append(
                f"{prefix}: 'header' 不能作为 body 元素，请放在顶层"
            )
        else:
            errors.append(f"{prefix}: 未知标签 '{tag}'")
        return

    if tag == "table":
        _validate_table(el, prefix, errors, warnings)
    elif tag == "column_set":
        _validate_column_set(el, prefix, errors, warnings)
    elif tag == "markdown":
        _validate_markdown(el, prefix, errors, warnings)


def _validate_table(el: dict, prefix: str, errors: list, warnings: list):
    ps = el.get("page_size")
    if ps is not None:
        if not isinstance(ps, int) or ps < MIN_PAGE_SIZE or ps > MAX_PAGE_SIZE:
            errors.append(
                f"{prefix}: page_size 必须为 {MIN_PAGE_SIZE}~{MAX_PAGE_SIZE}，"
                f"当前值 {ps}"
            )

    columns = el.get("columns", [])
    if not columns:
        errors.append(f"{prefix}: 缺少 columns")
        return

    if not isinstance(columns, list):
        errors.append(f"{prefix}: columns 必须是数组")
        return

    col_names = set()
    for j, col in enumerate(columns):
        if not isinstance(col, dict):
            errors.append(f"{prefix}.columns[{j}]: 必须是对象")
            continue

        dt = col.get("data_type", "")
        if dt not in VALID_DATA_TYPES:
            if dt == "date":
                errors.append(
                    f"{prefix}.columns[{j}]: data_type 'date' 不支持，"
                    "实测会 400 错误，请用 'text' 替代"
                )
            else:
                errors.append(
                    f"{prefix}.columns[{j}]: data_type '{dt}' 无效，"
                    f"仅支持 {VALID_DATA_TYPES}"
                )

        name = col.get("name", "")
        if not name:
            errors.append(f"{prefix}.columns[{j}]: 缺少 name")
        elif name in col_names:
            errors.append(f"{prefix}.columns[{j}]: name '{name}' 重复")
        col_names.add(name)

        if "display_name" not in col:
            warnings.append(
                f"{prefix}.columns[{j}]: 建议设置 display_name"
            )

    rows = el.get("rows", [])
    if not isinstance(rows, list):
        errors.append(f"{prefix}: rows 必须是数组")
        return

    for j, row in enumerate(rows):
        if not isinstance(row, dict):
            errors.append(f"{prefix}.rows[{j}]: 必须是对象")
            continue

        for col in columns:
            col_name = col.get("name", "")
            if not col_name:
                continue

            if col.get("data_type") == "options":
                val = row.get(col_name)
                if val is None:
                    continue
                if not isinstance(val, list):
                    errors.append(
                        f"{prefix}.rows[{j}].{col_name}: options 列的值"
                        "必须是数组，格式 [{{color, text}}]"
                    )
                    continue
                for k, opt in enumerate(val):
                    if not isinstance(opt, dict):
                        errors.append(
                            f"{prefix}.rows[{j}].{col_name}[{k}]: "
                            "必须是对象"
                        )
                        continue
                    color = opt.get("color", "")
                    if color not in VALID_COLORS:
                        errors.append(
                            f"{prefix}.rows[{j}].{col_name}[{k}]: "
                            f"color '{color}' 无效，可选 {VALID_COLORS}"
                        )
                    if "text" not in opt:
                        errors.append(
                            f"{prefix}.rows[{j}].{col_name}[{k}]: "
                            "缺少 text"
                        )


def _validate_column_set(el: dict, prefix: str, errors: list, warnings: list):
    columns = el.get("columns", [])
    if not isinstance(columns, list):
        errors.append(f"{prefix}: columns 必须是数组")
        return

    for j, col in enumerate(columns):
        if not isinstance(col, dict):
            errors.append(f"{prefix}.columns[{j}]: 必须是对象")
            continue

        col_elements = col.get("elements", [])
        if not isinstance(col_elements, list):
            errors.append(f"{prefix}.columns[{j}]: elements 必须是数组")
            continue

        for k, cel in enumerate(col_elements):
            if isinstance(cel, dict) and cel.get("tag") == "table":
                warnings.append(
                    f"{prefix}.columns[{j}].elements[{k}]: "
                    "column_set 内不建议用 table，"
                    "markdown 表格管道符会原样显示"
                )


def _validate_markdown(el: dict, prefix: str, errors: list, warnings: list):
    content = el.get("content", "")
    if not isinstance(content, str):
        errors.append(f"{prefix}: content 必须是字符串")
        return

    if content.lstrip().startswith("#"):
        warnings.append(
            f"{prefix}: markdown 块以 '#' 开头，"
            "飞书卡片不支持 heading 语法，请用 **粗体** 替代"
        )


def main():
    parser = argparse.ArgumentParser(description="飞书卡片 JSON 校验器")
    parser.add_argument("--card", "-c", help="卡片 JSON 字符串")
    parser.add_argument("--card-file", "-f", help="卡片 JSON 文件路径")
    args = parser.parse_args()

    if args.card_file:
        card = _read_json_file(args.card_file)
    elif args.card:
        card = json.loads(args.card)
    else:
        card = json.load(sys.stdin)

    result = validate(card)
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if not result["valid"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
