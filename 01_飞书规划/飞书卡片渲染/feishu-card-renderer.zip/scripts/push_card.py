#!/usr/bin/env python3
"""
飞书卡片推送封装

用法:
  python push_card.py --chat-id oc_xxx --card '{"schema":"2.0",...}'
  python push_card.py --chat-id oc_xxx --card-file ./card.json
  cat card.json | python push_card.py --chat-id oc_xxx

输出: message 工具调用参数 JSON（stdout），直接传给 message 工具即可

设计意图:
  封装 chat_id 格式化 + card 完整性校验，减少 AI 手动拼参数的出错概率。
  推送本身仍由 AI 调用 message 工具完成（因为需要 OpenClaw 的会话上下文）。
"""

import json
import sys
import argparse
from pathlib import Path

# Force UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def _read_json_file(path: str) -> dict:
    """Read JSON file, auto-handling BOM (UTF-8 / UTF-16 LE / UTF-16 BE)."""
    raw = Path(path).read_bytes()
    if raw.startswith(b'\xef\xbb\xbf'):
        raw = raw[3:]
    elif raw.startswith(b'\xff\xfe'):
        raw = raw[2:].decode('utf-16-le').encode('utf-8')
    elif raw.startswith(b'\xfe\xff'):
        raw = raw[2:].decode('utf-16-be').encode('utf-8')
    return json.loads(raw.decode('utf-8'))


def main():
    parser = argparse.ArgumentParser(
        description="飞书卡片推送封装 — 输出 message 工具调用参数"
    )
    parser.add_argument(
        "--chat-id", "-c",
        required=True,
        help="目标群 chat_id（如 oc_a48a53d3294b1d821287202ada93e7a0）"
    )
    parser.add_argument(
        "--card",
        help="卡片 JSON 字符串"
    )
    parser.add_argument(
        "--card-file", "-f",
        help="卡片 JSON 文件路径"
    )
    args = parser.parse_args()

    # Load card
    if args.card_file:
        card = _read_json_file(args.card_file)
    elif args.card:
        card = json.loads(args.card)
    else:
        card = json.load(sys.stdin)

    # Normalize chat_id
    chat_id = args.chat_id.strip()
    if not chat_id.startswith("oc_"):
        chat_id = f"oc_{chat_id}"

    # Build message tool params
    output = {
        "action": "send",
        "channel": "feishu",
        "target": f"chat:{chat_id}",
        "card": card
    }

    print(json.dumps(output, ensure_ascii=False))


if __name__ == "__main__":
    main()
