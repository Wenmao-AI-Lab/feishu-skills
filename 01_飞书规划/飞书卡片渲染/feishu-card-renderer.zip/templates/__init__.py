"""
飞书卡片模板库

模板选型原则：
- 有明确行列、≥3 条同构记录 → dashboard (A)
- 两组或多组对照 → comparison (B)
- 长文本、无表格 → text_analysis (C)
- 纯文字通知 → notice (D)
"""

from . import dashboard, comparison, text_analysis, notice

TEMPLATES = {
    "dashboard": dashboard,
    "comparison": comparison,
    "text_analysis": text_analysis,
    "notice": notice,
}

__all__ = ["dashboard", "comparison", "text_analysis", "notice", "TEMPLATES"]
