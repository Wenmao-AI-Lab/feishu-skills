"""
Template C: 文本分析 (Text Analysis)
适用：散文、报告、议论文等无表格的长文

骨架：
  header(title) → markdown(核心提炼) → hr → 中间区(对比/段落) → hr → markdown(引用) → hr → markdown(意图)
"""


def render(data: dict) -> dict:
    """
    Render a text analysis card (Template C).

    Expected data structure:
    {
        "title": "分析标题",
        "summary": "核心提炼 2-3 句",     // optional
        "body_sections": [                // optional
            {"type": "markdown", "content": "段落内容"},
            {"type": "table", "columns": [...], "rows": [...]}
        ],
        "quote": "关键引用/佐证",          // optional
        "intent": "作者意图一句话"         // optional
    }

    Returns a valid feishu message card JSON dict (schema 2.0).
    """
    title = data.get("title", "文本分析")
    summary = data.get("summary", "")
    body_sections = data.get("body_sections", [])
    quote = data.get("quote", "")
    intent = data.get("intent", "")

    elements = []

    if summary:
        elements.append({"tag": "markdown", "content": summary})
        elements.append({"tag": "hr"})

    for section in body_sections:
        stype = section.get("type", "markdown")
        if stype == "table":
            tbl_rows = section.get("rows", [])
            elements.append({
                "tag": "table",
                "page_size": min(len(tbl_rows), 10),
                "columns": section.get("columns", []),
                "rows": tbl_rows
            })
        else:
            elements.append({
                "tag": "markdown",
                "content": section.get("content", "")
            })

    if quote:
        elements.append({"tag": "hr"})
        elements.append({"tag": "markdown", "content": quote})

    if intent:
        elements.append({"tag": "hr"})
        elements.append({"tag": "markdown", "content": intent})

    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": title}},
        "body": {"elements": elements}
    }
