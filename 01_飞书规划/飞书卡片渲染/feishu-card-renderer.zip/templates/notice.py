"""
Template D: 简讯/通知 (Notice)
适用：纯文字消息、公告、提醒

骨架：
  header(title) → markdown(正文) → markdown(补充/行动指引)
"""


def render(data: dict) -> dict:
    """
    Render a notice card (Template D).

    Expected data structure:
    {
        "title": "通知标题",
        "body": "正文内容",
        "footer": "补充信息 / 行动指引"  // optional
    }

    Returns a valid feishu message card JSON dict (schema 2.0).
    """
    title = data.get("title", "通知")
    body = data.get("body", "")
    footer = data.get("footer", "")

    elements = []

    if body:
        elements.append({"tag": "markdown", "content": body})

    if footer:
        elements.append({"tag": "markdown", "content": footer})

    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": title}},
        "body": {"elements": elements}
    }
