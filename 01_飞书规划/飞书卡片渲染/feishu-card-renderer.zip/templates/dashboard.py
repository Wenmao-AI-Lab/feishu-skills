"""
Template A: 数据看板 (Dashboard)
适用：多维表、任务表、统计表等有明确行列的数据

骨架：
  header(title) → column_set(概览指标) → hr → table(明细) → hr → markdown(结论)
"""

STATUS_COLORS = {
    "已完成": "green",
    "完成": "green",
    "正常": "green",
    "进行中": "blue",
    "处理中": "blue",
    "待处理": "grey",
    "未开始": "grey",
    "已暂停": "orange",
    "等待中": "orange",
    "已阻塞": "red",
    "失败": "red",
    "已取消": "red",
}


def _color_for_status(status: str) -> str:
    """Map status text to color tag."""
    return STATUS_COLORS.get(status, "grey")


def render(data: dict) -> dict:
    """
    Render a dashboard card (Template A).

    Expected data structure:
    {
        "title": "卡片标题",
        "overview": {"总数": 10, "已完成": 5, "待办": 3},  // optional
        "columns": [
            {"data_type": "text",    "display_name": "任务",   "name": "task"},
            {"data_type": "options", "display_name": "状态",   "name": "status"},
            {"data_type": "text",    "display_name": "负责人", "name": "owner"}
        ],
        "rows": [
            {"task": "任务A", "status": "已完成", "owner": "张三"},
            {"task": "任务B", "status": "进行中", "owner": "李四"}
        ],
        "conclusion": "一句话结论"  // optional
    }

    Returns a valid feishu message card JSON dict (schema 2.0).
    """
    title = data.get("title", "数据看板")
    overview = data.get("overview", {})
    columns = data.get("columns", [])
    rows = data.get("rows", [])
    conclusion = data.get("conclusion", "")

    elements = []

    # ---- Overview: column_set ----
    if overview:
        col_elements = []
        for label, value in overview.items():
            col_elements.append({
                "tag": "column",
                "width": "weighted",
                "elements": [
                    {"tag": "markdown", "content": f"**{value}**\n{label}"}
                ]
            })
        elements.append({
            "tag": "column_set",
            "flex_mode": "bisect",
            "columns": col_elements
        })
        elements.append({"tag": "hr"})

    # ---- Detail: table ----
    if columns and rows:
        processed_rows = []
        for row in rows:
            processed = {}
            for col_def in columns:
                col_name = col_def["name"]
                col_type = col_def.get("data_type", "text")
                value = row.get(col_name, "")
                if col_type == "options" and isinstance(value, str):
                    processed[col_name] = [
                        {"color": _color_for_status(value), "text": value}
                    ]
                else:
                    processed[col_name] = value
            processed_rows.append(processed)

        elements.append({
            "tag": "table",
            "page_size": min(len(rows), 10),
            "columns": columns,
            "rows": processed_rows
        })
        elements.append({"tag": "hr"})

    # ---- Conclusion ----
    if conclusion:
        elements.append({"tag": "markdown", "content": conclusion})

    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": title}
        },
        "body": {"elements": elements}
    }
