"""
Template B: 对比分析 (Comparison)
适用：两组或多组数据对比、前后变化、差异分析

骨架：
  header(title) → markdown(背景) → hr → table(对比明细) → hr → markdown(结论)
"""


def render(data: dict) -> dict:
    """
    Render a comparison card (Template B).

    Expected data structure:
    {
        "title": "对比标题",
        "context": "背景一句话",       // optional
        "columns": [
            {"data_type": "text", "display_name": "维度", "name": "dim"},
            {"data_type": "text", "display_name": "A组",  "name": "group_a"},
            {"data_type": "text", "display_name": "B组",  "name": "group_b"}
        ],
        "rows": [
            {"dim": "指标1", "group_a": "100", "group_b": "120"}
        ],
        "conclusion": "结论"            // optional
    }

    Returns a valid feishu message card JSON dict (schema 2.0).
    """
    title = data.get("title", "对比分析")
    context = data.get("context", "")
    columns = data.get("columns", [])
    rows = data.get("rows", [])
    conclusion = data.get("conclusion", "")

    elements = []

    if context:
        elements.append({"tag": "markdown", "content": context})
        elements.append({"tag": "hr"})

    if columns and rows:
        elements.append({
            "tag": "table",
            "page_size": min(len(rows), 10),
            "columns": columns,
            "rows": rows
        })
        elements.append({"tag": "hr"})

    if conclusion:
        elements.append({"tag": "markdown", "content": conclusion})

    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": title}},
        "body": {"elements": elements}
    }
